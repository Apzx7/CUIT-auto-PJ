#!/usr/bin/env bash
set -e

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "============================================"
echo "Traffic Detection System - Startup"
echo "============================================"

echo "[1/2] Starting backend..."
(python backend/main.py) &
BACK_PID=$!
sleep 1
echo "Backend started (pid: ${BACK_PID})."

echo "[2/2] Starting frontend..."
if [ ! -d "${ROOT_DIR}/frontend/node_modules" ]; then
	echo "Installing frontend dependencies..."
	(cd "${ROOT_DIR}/frontend" && npm install)
fi
(cd "${ROOT_DIR}/frontend" && npm run dev) &
FRONT_PID=$!
sleep 1
echo "Frontend started (pid: ${FRONT_PID})."

echo "============================================"
echo "All services launched. Keep this terminal open."
echo "============================================"
