const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8080";

function buildUrl(path) {
  if (path.startsWith("http")) return path;
  const base = API_BASE.endsWith("/") ? API_BASE.slice(0, -1) : API_BASE;
  const suffix = path.startsWith("/") ? path : `/${path}`;
  return `${base}${suffix}`;
}

async function request(path, options = {}) {
  const url = buildUrl(path);
  const res = await fetch(url, options);
  const contentType = res.headers.get("content-type") || "";
  let data = null;
  if (contentType.includes("application/json")) {
    data = await res.json();
  } else {
    data = await res.text();
  }
  if (!res.ok) {
    const message = data?.message || `请求失败：${res.status}`;
    throw new Error(message);
  }
  return data;
}

export function apiGet(path) {
  return request(path, { method: "GET" });
}

export function apiPost(path, body) {
  return request(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
}

export function apiPostForm(path, formData) {
  return request(path, {
    method: "POST",
    body: formData
  });
}

export function downloadFile(fileId) {
  const url = buildUrl(`/download/${fileId}`);
  window.open(url, "_blank", "noopener,noreferrer");
}

export function getApiBase() {
  return API_BASE;
}
