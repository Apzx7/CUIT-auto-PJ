import React, { useState } from "react";
import { apiGet } from "../api/client.js";

export default function Detection() {
  const [fileId, setFileId] = useState("");
  const [status, setStatus] = useState("");
  const [result, setResult] = useState(null);

  const runDetect = async () => {
    if (!fileId) {
      setStatus("请输入文件 ID。");
      return;
    }
    try {
      const res = await apiGet(`/detect/file/${fileId}`);
      setStatus(res.message || "检测已开始。");
    } catch (err) {
      setStatus(err.message);
    }
  };

  const fetchResult = async () => {
    if (!fileId) {
      setStatus("请输入文件 ID。");
      return;
    }
    try {
      const res = await apiGet(`/detect/result/search/${fileId}`);
      setResult(res.data || null);
      setStatus("结果已加载。");
    } catch (err) {
      setStatus(err.message);
    }
  };

  return (
    <div className="grid grid-2">
      <div className="card">
        <h2>文件检测</h2>
        <div className="form">
          <label>文件 ID</label>
          <input value={fileId} onChange={(e) => setFileId(e.target.value)} placeholder="请输入 UUID" />
          <div className="button-row">
            <button className="btn-primary" onClick={runDetect}>执行检测</button>
            <button className="btn-light" onClick={fetchResult}>加载结果</button>
          </div>
        </div>
        {status && <div className="status">{status}</div>}
      </div>

      <div className="card">
        <h2>最新结果</h2>
        {result ? (
          <pre className="code-block">{JSON.stringify(result, null, 2)}</pre>
        ) : (
          <div className="status">暂无已加载结果。</div>
        )}
      </div>
    </div>
  );
}
