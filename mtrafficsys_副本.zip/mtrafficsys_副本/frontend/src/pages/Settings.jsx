import React from "react";
import { getApiBase } from "../api/client.js";

export default function Help() {
  return (
    <div className="grid">
      <div className="card">
        <h2>帮助</h2>
        <div className="status">本系统用于流量文件的上传、特征提取、规则检测、AI 分析与报告导出。</div>
      </div>

      <div className="card">
        <h2>快速开始</h2>
        <div className="status">1）在“文件管理”上传流量文件。</div>
        <div className="status">2）点击“提取”生成流量特征。</div>
        <div className="status">3）点击“检测”执行 YARA + AI 联合分析。</div>
        <div className="status">4）在“查看结果”中查看命中与 AI 判定。</div>
        <div className="status">5）导出 JSON 或 PDF 报告。</div>
      </div>

      <div className="card">
        <h2>主要页面说明</h2>
        <div className="status">仪表盘：查看文件、规则、协议特征等总体统计。</div>
        <div className="status">文件管理：上传文件、提取特征、检测、查看结果、导出报告。</div>
        <div className="status">规则管理：IP/域名规则转换、规则查询与筛选。</div>
        <div className="status">流量特征：按协议和类型查询/导出特征数据。</div>
        <div className="status">日志：查询与导出系统日志、业务日志。</div>
        <div className="status">导出文件：下载与删除系统导出记录。</div>
      </div>

      <div className="card">
        <h2>运行与配置</h2>
        <div className="status">API 基础地址：{getApiBase()}</div>
        <div className="status">如需修改 API 地址，请更新前端目录中的 .env 文件后重启前端。</div>
      </div>
    </div>
  );
}
