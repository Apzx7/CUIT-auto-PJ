import React, { useEffect, useState } from "react";
import { apiGet, apiPost } from "../api/client.js";
import ActionDialog from "../components/ActionDialog.jsx";
import DataTable from "../components/DataTable.jsx";

export default function Logs() {
  const [systemParams, setSystemParams] = useState({
    level: "",
    start_time: "",
    end_time: "",
    page: 1,
    per_page: 50,
    sort_by: "created_at",
    desc_order: true
  });
  const [businessParams, setBusinessParams] = useState({
    task_status: "",
    start_time: "",
    end_time: "",
    page: 1,
    per_page: 50,
    sort_by: "created_at",
    desc_order: true
  });
  const [systemOptions, setSystemOptions] = useState([]);
  const [businessOptions, setBusinessOptions] = useState([]);
  const [actionDialog, setActionDialog] = useState({ open: false, message: "", tone: "success" });
  const [resultRows, setResultRows] = useState([]);
  const [resultMeta, setResultMeta] = useState({ total: 0, page: 1, per_page: 50, source: "" });
  const toDayStart = (dateText) => (dateText ? `${dateText} 00:00:00` : null);
  const toDayEnd = (dateText) => (dateText ? `${dateText} 23:59:59` : null);

  const withDayRange = (params) => ({
    ...params,
    start_time: toDayStart(params.start_time),
    end_time: toDayEnd(params.end_time)
  });
  const logColumnMap = {
    level: "级别",
    logger: "日志器",
    action: "动作",
    message: "消息",
    created_at: "创建时间",
    category: "类别",
    actor: "操作者",
    detail: "详情",
    result: "结果"
  };

  const mapLogRows = (rows) => {
    return (rows || []).map((row) => {
      const mapped = {};
      Object.keys(row || {}).forEach((key) => {
        if (key === "id") return;
        mapped[logColumnMap[key] || key] = row[key];
      });
      return mapped;
    });
  };

  const updateSystem = (key, value) => setSystemParams({ ...systemParams, [key]: value });
  const updateBusiness = (key, value) => setBusinessParams({ ...businessParams, [key]: value });

  useEffect(() => {
    apiGet("/logs/system/options/")
      .then((res) => setSystemOptions(res.data || []))
      .catch((err) => setActionDialog({ open: true, message: err.message, tone: "error" }));
    apiGet("/logs/business/options/")
      .then((res) => setBusinessOptions(res.data || []))
      .catch((err) => setActionDialog({ open: true, message: err.message, tone: "error" }));
  }, []);

  const searchSystem = async () => {
    try {
      const res = await apiPost("/logs/system/search/", withDayRange(systemParams));
      const data = res.data || {};
      setResultRows(mapLogRows(data.items || []));
      setResultMeta({ total: data.total || 0, page: data.page || 1, per_page: data.per_page || 50, source: "系统日志" });
      setActionDialog({ open: true, message: res.message || "系统日志加载完成。", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const searchBusiness = async () => {
    try {
      const res = await apiPost("/logs/business/search/", withDayRange(businessParams));
      const data = res.data || {};
      setResultRows(mapLogRows(data.items || []));
      setResultMeta({ total: data.total || 0, page: data.page || 1, per_page: data.per_page || 50, source: "业务日志" });
      setActionDialog({ open: true, message: res.message || "业务日志加载完成。", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const exportSystem = async () => {
    try {
      const res = await apiPost("/log/system/export/", withDayRange(systemParams));
      setActionDialog({ open: true, message: res.message || "系统日志导出完成。", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const exportBusiness = async () => {
    try {
      const res = await apiPost("/log/business/export/", withDayRange(businessParams));
      setActionDialog({ open: true, message: res.message || "业务日志导出完成。", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  return (
    <div className="grid grid-2">
      <div className="card">
        <h2>系统日志</h2>
        <div className="form">
          <label>级别</label>
          <select value={systemParams.level} onChange={(e) => updateSystem("level", e.target.value)}>
            <option value="">全部</option>
            {systemOptions.map((opt) => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>
          <div className="form-row">
            <div>
              <label>开始日期</label>
              <input type="date" value={systemParams.start_time} onChange={(e) => updateSystem("start_time", e.target.value)} />
            </div>
            <div>
              <label>结束日期</label>
              <input type="date" value={systemParams.end_time} onChange={(e) => updateSystem("end_time", e.target.value)} />
            </div>
          </div>
          <div className="button-row">
            <button className="btn-primary" onClick={searchSystem}>查询</button>
            <button className="btn-secondary" onClick={exportSystem}>导出</button>
          </div>
        </div>
      </div>

      <div className="card">
        <h2>业务日志</h2>
        <div className="form">
          <label>任务状态</label>
          <select value={businessParams.task_status} onChange={(e) => updateBusiness("task_status", e.target.value)}>
            <option value="">全部</option>
            {businessOptions.map((opt) => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>
          <div className="form-row">
            <div>
              <label>开始日期</label>
              <input type="date" value={businessParams.start_time} onChange={(e) => updateBusiness("start_time", e.target.value)} />
            </div>
            <div>
              <label>结束日期</label>
              <input type="date" value={businessParams.end_time} onChange={(e) => updateBusiness("end_time", e.target.value)} />
            </div>
          </div>
          <div className="button-row">
            <button className="btn-primary" onClick={searchBusiness}>查询</button>
            <button className="btn-secondary" onClick={exportBusiness}>导出</button>
          </div>
        </div>
      </div>

      <div className="card" style={{ gridColumn: "1 / -1" }}>
        <h2>结果</h2>
        {resultRows.length > 0 ? (
          <>
            <div className="status" style={{ marginBottom: 10 }}>
              来源：{resultMeta.source} · 第 {resultMeta.page} 页 · 每页 {resultMeta.per_page} 条 · 共 {resultMeta.total} 条
            </div>
            <div className="table-wrap">
              <DataTable rows={resultRows} />
            </div>
          </>
        ) : (
          <div className="status">暂无结果。</div>
        )}
      </div>
      <ActionDialog
        open={actionDialog.open}
        tone={actionDialog.tone}
        message={actionDialog.message}
        onClose={() => setActionDialog({ open: false, message: "", tone: "success" })}
      />
    </div>
  );
}
