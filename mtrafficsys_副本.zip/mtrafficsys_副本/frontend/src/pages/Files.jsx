import React, { useEffect, useState } from "react";
import { apiGet, apiPost, apiPostForm } from "../api/client.js";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import ResultDialog from "../components/ResultDialog.jsx";
import LoadingOverlay from "../components/LoadingOverlay.jsx";
import ActionDialog from "../components/ActionDialog.jsx";

export default function Files() {
  const [file, setFile] = useState(null);
  const [files, setFiles] = useState([]);
  const [status, setStatus] = useState("");
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState("");
  const [resultOpen, setResultOpen] = useState(false);
  const [resultData, setResultData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [actionDialog, setActionDialog] = useState({ open: false, message: "", tone: "success" });
  const [searchParams, setSearchParams] = useState({ filename: "", start_time: "", end_time: "" });
  const [page, setPage] = useState(1);
  const pageSize = 5;

  const toDayStart = (dateText) => (dateText ? `${dateText} 00:00:00` : null);
  const toDayEnd = (dateText) => (dateText ? `${dateText} 23:59:59` : null);

  const refresh = () => {
    apiGet("/upload/show/")
      .then((res) => setFiles(res.data || []))
      .catch((err) => setStatus(err.message));
  };

  useEffect(() => {
    refresh();
  }, []);

  useEffect(() => {
    setPage(1);
  }, [files]);

  const handleUpload = async () => {
    if (!file) {
      setActionDialog({ open: true, message: "请先选择文件。", tone: "error" });
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    setLoading(true);
    try {
      const res = await apiPostForm("/upload/", formData);
      setActionDialog({ open: true, message: res.message || "上传完成", tone: "success" });
      refresh();
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    } finally {
      setLoading(false);
    }
  };

  const handleExtract = async (row) => {
    if (row?.is_extracted) {
      setActionDialog({ open: true, message: "文件已提取，无需重复操作。", tone: "error" });
      return;
    }
    setLoading(true);
    try {
      const res = await apiGet(`/traffic/feature/extract/${row.fid}`);
      setActionDialog({ open: true, message: res.message || "提取完成", tone: "success" });
      refresh();
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    } finally {
      setLoading(false);
    }
  };

  const handleDetect = async (row) => {
    if (!row?.is_extracted) {
      setActionDialog({ open: true, message: "请先提取特征，再执行检测。", tone: "error" });
      return;
    }
    if (row?.is_detected) {
      setActionDialog({ open: true, message: "文件已检测，无需重复操作。", tone: "error" });
      return;
    }
    setLoading(true);
    try {
      const res = await apiGet(`/detect/file/${row.fid}`);
      setActionDialog({ open: true, message: res.message || "检测完成", tone: "success" });
      refresh();
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    } finally {
      setLoading(false);
    }
  };

  const handleReport = async (row) => {
    if (!row?.is_detected) {
      setActionDialog({ open: true, message: "请先执行检测，再导出报告。", tone: "error" });
      return;
    }
    if (!row?.is_extracted) {
      setActionDialog({ open: true, message: "请先提取特征，再导出报告。", tone: "error" });
      return;
    }
    try {
      const res = await apiGet(`/report/pdf/${row.fid}`);
      setActionDialog({ open: true, message: res.message || "报告已生成", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const handleExportResult = async (row) => {
    if (!row?.is_detected) {
      setActionDialog({ open: true, message: "请先执行检测，再导出结果。", tone: "error" });
      return;
    }
    try {
      const res = await apiGet(`/result/export/${row.fid}`);
      setActionDialog({ open: true, message: res.message || "结果已导出", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const handleShowResult = async (row) => {
    if (!row?.is_detected) {
      setActionDialog({ open: true, message: "请先执行检测，再查看结果。", tone: "error" });
      return;
    }
    try {
      const res = await apiGet(`/detect/result/search/${row.fid}`);
      setResultData(res.data || null);
      setResultOpen(true);
    } catch (err) {
      setStatus(err.message);
    }
  };

  const handleCopyResult = async () => {
    const text = resultData ? JSON.stringify(resultData, null, 2) : "";
    try {
      await navigator.clipboard.writeText(text);
      setStatus("结果已复制到剪贴板。");
    } catch (err) {
      setStatus("复制失败，请手动复制。");
    }
  };

  const handleDelete = async (fileId) => {
    try {
      const res = await apiGet(`/upload/delete/${fileId}`);
      setActionDialog({ open: true, message: res.message || "删除完成", tone: "success" });
      refresh();
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const requestDelete = (fileId) => {
    setPendingDeleteId(fileId);
    setConfirmOpen(true);
  };

  const confirmDelete = async () => {
    if (!pendingDeleteId) {
      setConfirmOpen(false);
      return;
    }
    await handleDelete(pendingDeleteId);
    setConfirmOpen(false);
    setPendingDeleteId("");
  };

  const handleSearch = async () => {
    try {
      const res = await apiPost("/upload/search/", {
        filename: searchParams.filename || null,
        start_time: toDayStart(searchParams.start_time),
        end_time: toDayEnd(searchParams.end_time)
      });
      setFiles(res.data || []);
      setActionDialog({ open: true, message: res.message || "查询完成", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };
  const totalPages = Math.max(1, Math.ceil(files.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const startIndex = (currentPage - 1) * pageSize;
  const pagedFiles = files.slice(startIndex, startIndex + pageSize);
  return (
    <div className="grid grid-2">
      <div className="card">
        <h2>上传流量文件</h2>
        <div className="form">
          <input type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} />
          <div className="button-row">
            <button className="btn-primary" onClick={handleUpload}>上传</button>
            <button className="btn-light" onClick={refresh}>刷新列表</button>
          </div>
        </div>
        {status && <div className="status">{status}</div>}
      </div>

      <div className="card">
        <h2>查询文件</h2>
        <div className="form">
          <label>文件名</label>
          <input
            value={searchParams.filename}
            onChange={(e) => setSearchParams({ ...searchParams, filename: e.target.value })}
            placeholder="支持模糊匹配"
          />
          <div className="form-row">
            <div>
              <label>开始日期</label>
              <input
                type="date"
                value={searchParams.start_time}
                onChange={(e) => setSearchParams({ ...searchParams, start_time: e.target.value })}
              />
            </div>
            <div>
              <label>结束日期</label>
              <input
                type="date"
                value={searchParams.end_time}
                onChange={(e) => setSearchParams({ ...searchParams, end_time: e.target.value })}
              />
            </div>
          </div>
          <div className="button-row">
            <button className="btn-primary" onClick={handleSearch}>查询</button>
            <button className="btn-light" onClick={refresh}>显示全部</button>
          </div>
        </div>
      </div>

      <div className="card" style={{ gridColumn: "1 / -1" }}>
        <h2>已上传文件</h2>
        {files.length === 0 ? (
          <div className="status">暂无已上传文件。</div>
        ) : (
          <div className="table-wrap">
            <table className="table">
              <thead>
                <tr>
                  <th>fid</th>
                  <th>文件名</th>
                  <th>大小</th>
                  <th>上传时间</th>
                  <th>已提取</th>
                  <th>已检测</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {pagedFiles.map((row) => (
                  <tr key={row.fid || row.id}>
                    <td>{row.fid}</td>
                    <td>{row.name || row.fname}</td>
                    <td>{row.size}</td>
                    <td>{row.uploaded_at || row.upload_date}</td>
                    <td>
                      <span className={`pill ${row.is_extracted ? "pill-success" : "pill-danger"}`}>
                        {row.is_extracted ? "是" : "否"}
                      </span>
                    </td>
                    <td>
                      <span className={`pill ${row.is_detected ? "pill-success" : "pill-danger"}`}>
                        {row.is_detected ? "是" : "否"}
                      </span>
                    </td>
                    <td>
                      <div className="button-row">
                        <button className="btn-secondary btn-sm" onClick={() => handleExtract(row)}>提取</button>
                        <button className="btn-primary btn-sm" onClick={() => handleDetect(row)}>检测</button>
                        <button className="btn-light btn-sm" onClick={() => handleReport(row)}>PDF 报告</button>
                        <button className="btn-secondary btn-sm" onClick={() => handleShowResult(row)}>查看结果</button>
                        <button className="btn-secondary btn-sm" onClick={() => handleExportResult(row)}>导出 JSON</button>
                        <button className="btn-danger btn-sm" onClick={() => requestDelete(row.fid)}>删除</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {files.length > 0 && (
          <div className="pagination">
            <div className="page-info">第 {currentPage} / {totalPages} 页 · 共 {files.length} 条记录</div>
            <div className="button-row">
              <button className="btn-light" onClick={() => setPage(Math.max(1, currentPage - 1))}>上一页</button>
              <button className="btn-light" onClick={() => setPage(Math.min(totalPages, currentPage + 1))}>下一页</button>
            </div>
          </div>
        )}
      </div>
      <ConfirmDialog
        open={confirmOpen}
        title="删除上传文件"
        description="将删除磁盘中的文件及所有关联记录，此操作不可恢复。"
        confirmLabel="删除"
        onConfirm={confirmDelete}
        onClose={() => setConfirmOpen(false)}
      />
      <ResultDialog
        open={resultOpen}
        data={resultData}
        onCopy={handleCopyResult}
        onClose={() => setResultOpen(false)}
      />
      <LoadingOverlay open={loading} message="处理中..." />
      <ActionDialog
        open={actionDialog.open}
        tone={actionDialog.tone}
        message={actionDialog.message}
        onClose={() => setActionDialog({ open: false, message: "", tone: "success" })}
      />
    </div>
  );
}
