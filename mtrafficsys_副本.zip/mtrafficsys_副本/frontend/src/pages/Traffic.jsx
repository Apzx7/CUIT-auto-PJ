import React, { useEffect, useState } from "react";
import { apiPost } from "../api/client.js";
import DataTable from "../components/DataTable.jsx";
import ActionDialog from "../components/ActionDialog.jsx";

const protocolOptions = ["dns", "tcp_udp", "http", "icmp", "tls_certificate"];
const typeOptions = ["request", "response"];
const protocolLabels = {
  dns: "DNS",
  tcp_udp: "TCP/UDP",
  http: "HTTP",
  icmp: "ICMP",
  tls_certificate: "TLS 证书"
};
const typeLabels = {
  request: "请求",
  response: "响应",
  certificate: "证书"
};

export default function Traffic() {
  const [protocol, setProtocol] = useState("dns");
  const [packetType, setPacketType] = useState("request");
  const [fileId, setFileId] = useState("");
  const [actionDialog, setActionDialog] = useState({ open: false, message: "", tone: "success" });
  const [rows, setRows] = useState([]);
  const [page, setPage] = useState(1);
  const pageSize = 50;
  const trafficColumnMap = {
    uploaded_file_fid: "文件ID",
    type: "类型",
    date: "时间",
    protocol: "协议",
    src_ip: "源IP",
    dst_ip: "目的IP",
    src_port: "源端口",
    dst_port: "目的端口",
    duration: "持续时间",
    payload_size: "负载大小",
    qname: "查询域名",
    qtype: "查询类型",
    qcls: "查询类",
    rname: "响应域名",
    rtype: "响应类型",
    rcls: "响应类",
    ttl: "TTL",
    rdata_size: "响应数据大小",
    method: "方法",
    uri: "URI",
    headers: "请求头",
    user_agent: "User-Agent",
    referer: "Referer",
    status_code: "状态码",
    status_reason: "状态说明",
    code: "ICMP编码",
    data_size: "数据大小",
    cert_chain_len: "证书链长度",
    is_valid: "证书有效",
    cert_chain: "证书链"
  };

  const truncateLongValue = (key, value) => {
    if (!(key === "headers" || key === "cert_chain")) return value;
    const text = typeof value === "string" ? value : JSON.stringify(value);
    if (!text) return value;
    const limit = 120;
    if (text.length > limit) {
      return {
        __display: `${text.slice(0, limit)}...`,
        __tooltip: text
      };
    }
    return text;
  };

  const showType = protocol === "dns" || protocol === "http";

  useEffect(() => {
    if (protocol === "tls_certificate") {
      setPacketType("certificate");
      return;
    }
    if (showType) {
      setPacketType("request");
      return;
    }
    setPacketType("request");
  }, [protocol, showType]);

  const payload = {
    protocol,
    type: packetType,
    file_id: fileId || null
  };

  const fetchFeatures = async () => {
    try {
      const res = await apiPost("/traffic/feature/show/", payload);
      setRows(res.data || []);
      setActionDialog({ open: true, message: res.message || "加载完成。", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const exportFeatures = async () => {
    try {
      const res = await apiPost("/traffic/feature/export/", payload);
      setActionDialog({ open: true, message: res.message || "导出完成。", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  useEffect(() => {
    setPage(1);
  }, [rows]);

  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const startIndex = (currentPage - 1) * pageSize;
  const pagedRows = rows.slice(startIndex, startIndex + pageSize).map((row) => {
    const mapped = {};
    Object.keys(row || {}).forEach((key) => {
      if (key === "id") return;
      mapped[trafficColumnMap[key] || key] = truncateLongValue(key, row[key]);
    });
    return mapped;
  });

  return (
    <>
      <div className="grid">
        <div className="card">
        <h2>查询流量特征</h2>
        <div className="form">
          <label>协议</label>
          <select value={protocol} onChange={(e) => setProtocol(e.target.value)}>
            {protocolOptions.map((opt) => (
              <option key={opt} value={opt}>{protocolLabels[opt] || opt}</option>
            ))}
          </select>
          {showType ? (
            <>
              <label>类型</label>
              <select value={packetType} onChange={(e) => setPacketType(e.target.value)}>
                {typeOptions.map((opt) => (
                  <option key={opt} value={opt}>{typeLabels[opt] || opt}</option>
                ))}
              </select>
            </>
          ) : (
            <div className="status">当前协议类型为固定值。</div>
          )}
          <label>文件 ID（可选）</label>
          <input value={fileId} onChange={(e) => setFileId(e.target.value)} />
          <div className="button-row">
            <button className="btn-primary" onClick={fetchFeatures}>查询</button>
            <button className="btn-secondary" onClick={exportFeatures}>导出</button>
          </div>
        </div>
      </div>

        <div className="card" style={{ gridColumn: "1 / -1" }}>
        <h2>查询结果</h2>
        <div className="table-wrap">
          <DataTable rows={pagedRows} />
        </div>
        <div className="pagination">
          <div className="page-info">第 {currentPage} / {totalPages} 页 · 共 {rows.length} 条记录</div>
          <div className="button-row">
            <button className="btn-light" onClick={() => setPage(Math.max(1, currentPage - 1))}>上一页</button>
            <button className="btn-light" onClick={() => setPage(Math.min(totalPages, currentPage + 1))}>下一页</button>
          </div>
        </div>
        </div>
      </div>
      <ActionDialog
        open={actionDialog.open}
        tone={actionDialog.tone}
        message={actionDialog.message}
        onClose={() => setActionDialog({ open: false, message: "", tone: "success" })}
      />
    </>
  );
}
