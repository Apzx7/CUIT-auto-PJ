import React, { useEffect, useState } from "react";
import { apiGet, apiPost, apiPostForm } from "../api/client.js";
import DataTable from "../components/DataTable.jsx";
import ActionDialog from "../components/ActionDialog.jsx";

export default function Rules() {
  const [ipFile, setIpFile] = useState(null);
  const [domainFile, setDomainFile] = useState(null);
  const [actionDialog, setActionDialog] = useState({ open: false, message: "", tone: "success" });
  const [rules, setRules] = useState([]);
  const [filters, setFilters] = useState({ security_level: "", category: "" });
  const [options, setOptions] = useState({ security_levels: [], categories: [] });
  const [page, setPage] = useState(1);
  const pageSize = 50;
  const ruleColumnMap = {
    id: "序号",
    fid: "规则ID",
    rule_name: "规则名称",
    rule_location: "规则路径",
    category: "分类",
    description: "描述",
    author: "作者",
    reference: "参考链接",
    malware_type: "恶意类型",
    security_level: "安全等级",
    date: "日期"
  };

  const uploadFile = async (path, file) => {
    if (!file) {
      setActionDialog({ open: true, message: "请先选择文件。", tone: "error" });
      return;
    }
    const formData = new FormData();
    formData.append("file", file);
    try {
      const res = await apiPostForm(path, formData);
      setActionDialog({
        open: true,
        message: `${res.message || "操作完成"}。输出文件：${res.output_name || "无"}，规则数：${res.rule_count || 0}`,
        tone: "success"
      });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const loadRules = async () => {
    try {
      const res = await apiGet("/rules/show/");
      setRules(res.data || []);
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const loadOptions = async () => {
    try {
      const res = await apiGet("/rules/options/");
      setOptions(res.data || { security_levels: [], categories: [] });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const searchRules = async () => {
    try {
      const payload = {
        security_level: filters.security_level || null,
        category: filters.category || null
      };
      const res = await apiPost("/rules/search/", payload);
      setRules(res.data || []);
      setActionDialog({ open: true, message: res.message || "规则筛选完成。", tone: "success" });
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  useEffect(() => {
    loadRules();
    loadOptions();
  }, []);

  useEffect(() => {
    setPage(1);
  }, [rules]);

  const totalPages = Math.max(1, Math.ceil(rules.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const startIndex = (currentPage - 1) * pageSize;
  const pagedRules = rules.slice(startIndex, startIndex + pageSize).map((row) => {
    const mapped = {};
    Object.keys(row || {}).forEach((key) => {
      mapped[ruleColumnMap[key] || key] = row[key];
    });
    return mapped;
  });

  return (
    <div className="grid grid-2">
      <div className="card">
        <h2>IP 列表转 YARA</h2>
        <div className="form">
          <input type="file" onChange={(e) => setIpFile(e.target.files?.[0] || null)} />
          <button className="btn-primary" onClick={() => uploadFile("/rules/convert/ip-file", ipFile)}>
            转换 IP 规则
          </button>
        </div>
      </div>

      <div className="card">
        <h2>域名列表转 YARA</h2>
        <div className="form">
          <input type="file" onChange={(e) => setDomainFile(e.target.files?.[0] || null)} />
          <button className="btn-primary" onClick={() => uploadFile("/rules/convert/domain-file", domainFile)}>
            转换域名规则
          </button>
        </div>
      </div>

      <div className="card" style={{ gridColumn: "1 / -1" }}>
        <h2>规则查询</h2>
        <div className="form form-row">
          <div>
            <label>安全等级</label>
            <select
              value={filters.security_level}
              onChange={(e) => setFilters({ ...filters, security_level: e.target.value })}
            >
              <option value="">全部</option>
              {options.security_levels.map((level) => (
                <option key={level} value={level}>{level}</option>
              ))}
            </select>
          </div>
          <div>
            <label>分类</label>
            <select
              value={filters.category}
              onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            >
              <option value="">全部</option>
              {options.categories.map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>
          <div className="button-row" style={{ alignItems: "flex-end" }}>
            <button className="btn-primary" onClick={searchRules}>查询</button>
            <button className="btn-light" onClick={loadRules}>显示全部</button>
          </div>
        </div>
      </div>

      <div className="card" style={{ gridColumn: "1 / -1" }}>
        <h2>规则列表</h2>
        <div className="table-wrap">
          <DataTable rows={pagedRules} />
        </div>
        <div className="pagination">
          <div className="page-info">第 {currentPage} / {totalPages} 页 · 共 {rules.length} 条记录</div>
          <div className="button-row">
            <button className="btn-light" onClick={() => setPage(Math.max(1, currentPage - 1))}>上一页</button>
            <button className="btn-light" onClick={() => setPage(Math.min(totalPages, currentPage + 1))}>下一页</button>
          </div>
        </div>
      </div>

      <ActionDialog
        open={actionDialog.open}
        tone={actionDialog.tone}
        message={actionDialog.message}
        onClose={() => setActionDialog({ open: false, message: "", tone: "success" })}
      />
    </div>
  );
}
