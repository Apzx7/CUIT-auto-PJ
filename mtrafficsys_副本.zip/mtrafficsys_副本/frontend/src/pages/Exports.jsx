import React, { useEffect, useState } from "react";
import { apiGet, downloadFile } from "../api/client.js";
import ConfirmDialog from "../components/ConfirmDialog.jsx";
import ActionDialog from "../components/ActionDialog.jsx";

export default function Exports() {
  const [rows, setRows] = useState([]);
  const [actionDialog, setActionDialog] = useState({ open: false, message: "", tone: "success" });
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pendingDeleteId, setPendingDeleteId] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const refresh = () => {
    apiGet("/exported/files/show/")
      .then((res) => setRows(res.data || []))
      .catch((err) => setActionDialog({ open: true, message: err.message, tone: "error" }));
  };

  useEffect(() => {
    refresh();
  }, []);

  useEffect(() => {
    setPage(1);
  }, [rows]);

  const deleteExport = async (fid) => {
    try {
      const res = await apiGet(`/exported/file/delete/${fid}`);
      setActionDialog({ open: true, message: res.message || "删除完成", tone: "success" });
      refresh();
    } catch (err) {
      setActionDialog({ open: true, message: err.message, tone: "error" });
    }
  };

  const requestDelete = (fid) => {
    setPendingDeleteId(fid);
    setConfirmOpen(true);
  };

  const confirmDelete = async () => {
    if (!pendingDeleteId) {
      setConfirmOpen(false);
      return;
    }
    await deleteExport(pendingDeleteId);
    setConfirmOpen(false);
    setPendingDeleteId("");
  };

  const totalPages = Math.max(1, Math.ceil(rows.length / pageSize));
  const currentPage = Math.min(page, totalPages);
  const startIndex = (currentPage - 1) * pageSize;
  const pagedRows = rows.slice(startIndex, startIndex + pageSize);

  return (
    <div className="card">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
        <h2 style={{ margin: 0 }}>已导出文件</h2>
        <button className="btn-light" onClick={refresh}>刷新</button>
      </div>
      {rows.length === 0 ? (
        <div className="status">暂无导出文件。</div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>fid</th>
                <th>名称</th>
                <th>格式</th>
                <th>大小</th>
                <th>导出时间</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              {pagedRows.map((row) => (
                <tr key={row.fid}>
                  <td>{row.fid}</td>
                  <td>{row.name}</td>
                  <td>{row.format}</td>
                  <td>{row.size}</td>
                  <td>{row.export_date}</td>
                  <td>
                    <div className="button-row">
                      <button className="btn-secondary btn-sm" onClick={() => downloadFile(row.fid)}>下载</button>
                      <button className="btn-danger btn-sm" onClick={() => requestDelete(row.fid)}>删除</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {rows.length > 0 && (
        <div className="pagination">
          <div className="page-info">第 {currentPage} / {totalPages} 页 · 共 {rows.length} 条记录</div>
          <div className="button-row">
            <button className="btn-light" onClick={() => setPage(Math.max(1, currentPage - 1))}>上一页</button>
            <button className="btn-light" onClick={() => setPage(Math.min(totalPages, currentPage + 1))}>下一页</button>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={confirmOpen}
        title="删除导出文件"
        description="将删除导出记录。若磁盘文件已不存在，不影响此操作。"
        confirmLabel="删除"
        onConfirm={confirmDelete}
        onClose={() => setConfirmOpen(false)}
      />
      <ActionDialog
        open={actionDialog.open}
        tone={actionDialog.tone}
        message={actionDialog.message}
        onClose={() => setActionDialog({ open: false, message: "", tone: "success" })}
      />
    </div>
  );
}
