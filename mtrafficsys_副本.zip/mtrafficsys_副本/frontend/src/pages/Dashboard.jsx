import React, { useEffect, useState } from "react";
import { apiGet } from "../api/client.js";
import StatCard from "../components/StatCard.jsx";
import DonutChart from "../components/DonutChart.jsx";
import ActionDialog from "../components/ActionDialog.jsx";

export default function Dashboard() {
  const [stats, setStats] = useState(null);
  const [actionDialog, setActionDialog] = useState({ open: false, message: "", tone: "success" });

  useEffect(() => {
    apiGet("/statistics/overview")
      .then((res) => setStats(res.data))
      .catch((err) => setActionDialog({ open: true, message: err.message, tone: "error" }));
  }, []);

  const processed = stats?.files?.processed_total ?? 0;
  const totalSize = stats?.files?.total_size_mb ?? 0;
  const packetTotal = stats?.packets?.total ?? 0;
  const ruleTotal = stats?.rules?.total ?? 0;
  const blacklistIp = stats?.blacklist?.ip_total ?? 0;
  const blacklistDomain = stats?.blacklist?.domain_total ?? 0;

  const featureCounts = stats?.features || {};
  const protocolData = {
    tcp_udp: featureCounts.tcp_udp || 0,
    dns: (featureCounts.dns_request || 0) + (featureCounts.dns_response || 0),
    http: (featureCounts.http_request || 0) + (featureCounts.http_response || 0),
    icmp: featureCounts.icmp || 0,
    tls_certificate: featureCounts.tls_certificate || 0
  };

  const ruleByCategory = stats?.rules?.by_category || {};
  const chartColors = ["#ff6a2b", "#0f8bdc", "#3fbf7f", "#f2b94b", "#9b6bff", "#e04646", "#00b8a9"];

  return (
    <div>
      <div className="grid grid-3">
        <StatCard title="已处理文件数" value={processed} />
        <StatCard title="总大小 (MB)" value={totalSize} />
        <StatCard title="数据包总数" value={packetTotal} />
        <StatCard title="规则总数" value={ruleTotal} />
        <StatCard title="IP 黑名单" value={blacklistIp} tone="danger" />
        <StatCard title="域名黑名单" value={blacklistDomain} tone="danger" />
      </div>

      <div className="section grid grid-2">
        <DonutChart title="协议特征分布" data={protocolData} colors={chartColors} />
        <DonutChart title="规则分类分布" data={ruleByCategory} colors={chartColors} />
      </div>

      <div className="section card">
        <h2>文件处理流程</h2>
        <div className="flow">
          <div className="flow-step">
            <div className="flow-title">上传</div>
            <div className="flow-desc">上传流量文件</div>
          </div>
          <div className="flow-arrow">→</div>
          <div className="flow-step">
            <div className="flow-title">提取</div>
            <div className="flow-desc">生成流量特征</div>
          </div>
          <div className="flow-arrow">→</div>
          <div className="flow-step">
            <div className="flow-title">检测</div>
            <div className="flow-desc">执行规则检测</div>
          </div>
          <div className="flow-arrow">→</div>
          <div className="flow-step">
            <div className="flow-title">导出</div>
            <div className="flow-desc">
              报告 · 流量特征 · 检测结果
            </div>
          </div>
        </div>
      </div>
      <ActionDialog
        open={actionDialog.open}
        tone={actionDialog.tone}
        message={actionDialog.message}
        onClose={() => setActionDialog({ open: false, message: "", tone: "success" })}
      />
    </div>
  );
}
