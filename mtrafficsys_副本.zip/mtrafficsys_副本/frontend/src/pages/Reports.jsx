import React, { useState } from "react";
import { apiGet } from "../api/client.js";

export default function Reports() {
  const [fileId, setFileId] = useState("");
  const [status, setStatus] = useState("");
  const [reportPath, setReportPath] = useState("");

  const generateReport = async () => {
    if (!fileId) {
      setStatus("请输入文件 ID。");
      return;
    }
    try {
      const res = await apiGet(`/report/pdf/${fileId}`);
      setReportPath(res.file_path || "");
      setStatus(res.message || "报告已生成。");
    } catch (err) {
      setStatus(err.message);
    }
  };

  const exportResult = async () => {
    if (!fileId) {
      setStatus("请输入文件 ID。");
      return;
    }
    try {
      const res = await apiGet(`/result/export/${fileId}`);
      setStatus(res.message || "导出完成。");
    } catch (err) {
      setStatus(err.message);
    }
  };

  return (
    <div className="grid grid-2">
      <div className="card">
        <h2>生成 PDF 报告</h2>
        <div className="form">
          <label>文件 ID</label>
          <input value={fileId} onChange={(e) => setFileId(e.target.value)} />
          <div className="button-row">
            <button className="btn-primary" onClick={generateReport}>生成 PDF</button>
            <button className="btn-secondary" onClick={exportResult}>导出检测 JSON</button>
          </div>
        </div>
        {reportPath && (
          <div className="status">报告路径：{reportPath}</div>
        )}
        {status && <div className="status">{status}</div>}
      </div>

      <div className="card">
        <h2>提示</h2>
        <div className="status">
          你可以在“导出文件”页面下载生成文件。报告导出会返回服务端路径，同时文件也会出现在导出记录中。
        </div>
      </div>
    </div>
  );
}
