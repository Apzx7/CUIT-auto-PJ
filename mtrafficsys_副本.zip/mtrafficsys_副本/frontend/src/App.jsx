import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Layout from "./components/Layout.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Files from "./pages/Files.jsx";
import Rules from "./pages/Rules.jsx";
import Traffic from "./pages/Traffic.jsx";
import Logs from "./pages/Logs.jsx";
import Exports from "./pages/Exports.jsx";
import Help from "./pages/Settings.jsx";

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/files" element={<Files />} />
        <Route path="/rules" element={<Rules />} />
        <Route path="/traffic" element={<Traffic />} />
        <Route path="/logs" element={<Logs />} />
        <Route path="/exports" element={<Exports />} />
        <Route path="/help" element={<Help />} />
        <Route path="/settings" element={<Navigate to="/help" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </Layout>
  );
}
