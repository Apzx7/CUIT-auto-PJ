import React from "react";

export default function ActionDialog({ open, tone = "success", message, onClose }) {
  if (!open) return null;
  const title = tone === "error" ? "操作失败" : "操作完成";
  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal">
        <div className="modal-header">
          <h3>{title}</h3>
        </div>
        <div className={`modal-body modal-${tone}`}>
          <p>{message}</p>
        </div>
        <div className="modal-actions">
          <button className="btn-primary" onClick={onClose}>确定</button>
        </div>
      </div>
    </div>
  );
}
