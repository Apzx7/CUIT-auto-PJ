import React from "react";

export default function StatCard({ title, value, tone }) {
  const className = tone === "danger" ? "pill pill-danger" : "pill pill-success";
  return (
    <div className="card">
      <h3>{title}</h3>
      <div className="metric">{value}</div>
      <div className={className}>{tone === "danger" ? "告警" : "正常"}</div>
    </div>
  );
}
