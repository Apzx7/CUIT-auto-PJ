import React from "react";

function buildGradient(stops) {
  if (!stops.length) return "#eee";
  const total = stops.reduce((sum, item) => sum + item.value, 0) || 1;
  let acc = 0;
  const parts = stops.map((item) => {
    const start = (acc / total) * 100;
    acc += item.value;
    const end = (acc / total) * 100;
    return `${item.color} ${start}% ${end}%`;
  });
  return `conic-gradient(${parts.join(", ")})`;
}

export default function DonutChart({ title, data, colors }) {
  const entries = Object.entries(data || {})
    .filter(([, value]) => Number(value) > 0)
    .map(([label, value], idx) => ({
      label,
      value: Number(value),
      color: colors[idx % colors.length]
    }));

  const total = entries.reduce((sum, item) => sum + item.value, 0);
  const gradient = buildGradient(entries);

  return (
    <div className="card">
      <h2>{title}</h2>
      <div className="donut-wrap">
        <div className="donut" style={{ background: gradient }}>
          <div className="donut-hole">
            <div className="donut-total">{total}</div>
            <div className="donut-label">总计</div>
          </div>
        </div>
        <div className="donut-legend">
          {entries.length === 0 ? (
            <div className="status">暂无数据。</div>
          ) : (
            entries.map((item) => (
              <div key={item.label} className="legend-item">
                <span className="legend-dot" style={{ background: item.color }} />
                <span>{item.label}</span>
                <span className="legend-value">{item.value}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
