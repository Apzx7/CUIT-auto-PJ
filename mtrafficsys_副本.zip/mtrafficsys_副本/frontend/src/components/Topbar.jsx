import React from "react";
import { useLocation } from "react-router-dom";

const titles = {
  "/dashboard": "仪表盘",
  "/files": "文件管理",
  "/rules": "规则管理",
  "/traffic": "流量特征",
  "/logs": "日志",
  "/exports": "导出文件",
  "/settings": "帮助",
  "/help": "帮助",
  "/reports": "报告",
  "/detection": "检测"
};

export default function Topbar() {
  const location = useLocation();
  const title = titles[location.pathname] || "流量检测管理台";

  return (
    <div className="topbar">
      <div className="page-title">{title}</div>
      <div className="badge">管理控制台</div>
    </div>
  );
}
