import React from "react";
import { NavLink } from "react-router-dom";

const links = [
  { to: "/dashboard", label: "仪表盘" },
  { to: "/files", label: "文件管理" },
  { to: "/rules", label: "规则管理" },
  { to: "/traffic", label: "流量特征" },
  { to: "/logs", label: "日志" },
  { to: "/exports", label: "导出文件" },
  { to: "/help", label: "帮助" }
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="brand">流量检测管理台</div>
      <nav className="nav-group">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              isActive ? "nav-item active" : "nav-item"
            }
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
