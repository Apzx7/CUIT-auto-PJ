import React, { useEffect, useState } from "react";

export default function ResultDialog({ open, data, onCopy, onClose }) {
  if (!open) return null;
  const [copied, setCopied] = useState(false);
  const columnLabelMap = {
    rule_file_name: "规则文件",
    rule_name: "规则名称",
    description: "描述",
    category: "分类",
    malware_type: "恶意类型",
    security_level: "安全等级",
    match_value: "命中值",
    verdict: "判定结果",
    severity: "危害等级",
    score: "评分",
    reasons: "判定原因",
    indicators: "威胁指标",
    recommended_actions: "建议操作",
    raw_output: "原始输出",
    ai_result: "AI结果",
    value: "值",
    index: "序号"
  };

  const parseData = (value) => {
    if (!value) return null;
    if (typeof value === "string") {
      try {
        return JSON.parse(value);
      } catch {
        return { raw: value };
      }
    }
    return value;
  };

  const safeCellText = (value) => {
    if (value === null || value === undefined) return "";
    if (typeof value === "object") return JSON.stringify(value);
    return String(value);
  };

  const isObject = (value) => value && typeof value === "object" && !Array.isArray(value);

  const buildRows = (value) => {
    if (Array.isArray(value)) {
      const allObject = value.every((item) => isObject(item));
      if (allObject) {
        const isYaraGroup = value.every((item) =>
          Object.prototype.hasOwnProperty.call(item, "rule_file_name")
          && Array.isArray(item.match)
        );

        if (isYaraGroup) {
          const rows = [];
          value.forEach((group) => {
            const fileName = group.rule_file_name;
            if (group.match.length === 0) {
              rows.push({ rule_file_name: fileName });
              return;
            }
            group.match.forEach((matchItem) => {
              if (isObject(matchItem)) {
                rows.push({ rule_file_name: fileName, ...matchItem });
              } else {
                rows.push({ rule_file_name: fileName, match_value: matchItem });
              }
            });
          });
          return rows;
        }

        return value;
      }
      return value.map((item, index) => ({
        index: index + 1,
        value: safeCellText(item)
      }));
    }

    if (isObject(value)) return [value];

    return [{ value: safeCellText(value) }];
  };

  const renderTable = (rows) => {
    const columns = [];
    rows.forEach((row) => {
      Object.keys(row).forEach((key) => {
        if (!columns.includes(key)) columns.push(key);
      });
    });

    return (
      <div className="table-wrap">
        <table className="table">
          <thead>
            <tr>
              {columns.map((col) => (
                <th key={col}>{columnLabelMap[col] || col}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => (
              <tr key={idx}>
                {columns.map((col) => (
                  <td key={`${idx}-${col}`}>{safeCellText(row[col])}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  };

  const parsed = parseData(data);

  const yaraRows = buildRows(parsed?.yara_matches ?? parsed?.matches ?? []);
  const aiRows = buildRows(parsed?.ai_detection ?? parsed?.ai_detect ?? {});

  const fallbackEntries = parsed && isObject(parsed)
    ? Object.entries(parsed)
    : [["结果", parsed]];

  useEffect(() => {
    if (!open) return;
    setCopied(false);
  }, [open, data]);

  const handleCopy = async () => {
    await onCopy();
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true">
      <div className="modal modal-wide result-modal">
        <div className="modal-header">
          <h3>检测结果</h3>
        </div>
        <div className="modal-body">
          <div className="button-row" style={{ marginBottom: 12 }}>
            <button className="btn-secondary" onClick={handleCopy}>
              {copied ? "已复制" : "复制"}
            </button>
            <button className="btn-light" onClick={onClose}>关闭</button>
          </div>
          {!parsed ? (
            <div className="status">暂无结果。</div>
          ) : (parsed?.yara_matches || parsed?.matches || parsed?.ai_detection || parsed?.ai_detect) ? (
            <div className="result-split">
              <div className="result-pane">
                <h4>YARA 命中结果</h4>
                {renderTable(yaraRows)}
              </div>
              <div className="result-pane">
                <h4>AI 分析结果</h4>
                {renderTable(aiRows)}
              </div>
            </div>
          ) : (
            fallbackEntries.map(([section, value]) => {
              const rows = buildRows(value);
              return (
                <div key={section} className="result-section">
                  <h4>{section}</h4>
                  {renderTable(rows)}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}
