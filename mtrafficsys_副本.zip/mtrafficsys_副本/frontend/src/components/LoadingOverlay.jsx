import React from "react";

export default function LoadingOverlay({ open, message }) {
  if (!open) return null;
  return (
    <div className="loading-backdrop" role="alert" aria-live="polite">
      <div className="loading-card">
        <div className="spinner" />
        <div className="loading-text">{message || "处理中..."}</div>
      </div>
    </div>
  );
}
