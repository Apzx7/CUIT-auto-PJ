import React from "react";

export default function DataTable({ rows }) {
  if (!rows || rows.length === 0) {
    return <div className="status">暂无数据。</div>;
  }

  const columns = Object.keys(rows[0]);
  const renderCell = (value) => {
    if (value && typeof value === "object" && Object.prototype.hasOwnProperty.call(value, "__display")) {
      const display = String(value.__display ?? "");
      const tooltip = String(value.__tooltip ?? "");
      return <span title={tooltip}>{display}</span>;
    }
    return String(value ?? "");
  };

  return (
    <table className="table">
      <thead>
        <tr>
          {columns.map((col) => (
            <th key={col}>{col}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, idx) => (
          <tr key={idx}>
            {columns.map((col) => (
              <td key={col}>{renderCell(row[col])}</td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  );
}
