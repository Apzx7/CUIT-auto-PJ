@echo off
setlocal

echo ============================================
echo Traffic Detection System - Startup
echo ============================================

set ROOT=%~dp0

echo [1/2] Starting backend...
start "Backend" cmd /k "python backend/main.py"
echo Backend started in a new window.

echo [2/2] Starting frontend...
if not exist "%ROOT%frontend\node_modules" (
	echo Installing frontend dependencies...
	pushd "%ROOT%frontend" >nul
	npm install
	popd >nul
)
start "Frontend" cmd /k "cd /d %ROOT%frontend && npm run dev"
echo Frontend started in a new window.

echo ============================================
echo All services launched. Keep both windows open.
echo ============================================

endlocal
