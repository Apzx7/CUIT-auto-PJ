# Mtrafficdsys

网络流量检测与分析系统，支持：

- 流量文件上传与管理
- 协议特征提取（TCP/UDP、DNS、HTTP、ICMP、TLS）
- YARA 规则检测 + AI 分析
- 检测结果导出（JSON）与 PDF 报告生成
- 系统日志/业务日志查询与导出

---

## 1. 项目结构

```text
Mtrafficdsys/
├─ backend/                # FastAPI 后端
│  ├─ main.py
│  ├─ settings.py
│  └─ src/
├─ frontend/               # React + Vite 前端
│  ├─ src/
│  └─ package.json
├─ requirement.txt         # Python 环境依赖（conda 导出格式）
├─ start.bat               # Windows 一键启动
└─ start.sh                # Linux/macOS 一键启动
```

---

## 2. 运行环境

### 后端

- Python 3.10+（推荐 3.12）
- MySQL

### 前端

- Node.js 18+
- npm 9+

---

## 3. 环境安装

### 3.1 后端依赖安装

`conda_requirements.txt` 是 conda 导出格式，优先使用 conda：

```bash
conda create -n mtraffic --file requirement.txt
conda activate mtraffic
```

如果你使用 pip，请先准备自己的 `requirements.txt`（当前仓库文件名为 `conda_requirements.txt`，不是 pip 冻结格式）。

### 3.2 前端依赖安装

```bash
cd frontend
npm install
```

---

## 4. 配置说明

### 4.1 后端配置

- `backend/configs/init.yaml`：数据库、服务端口、CORS、API Key 等, 示例配置如下：

```yaml
MYSQL_CONF:
  - host: 192.168.139.198
  - user: user
  - passwd: passwd
  - port: 3306
  - db: mtrafficsys

UVICORN_CONF:
  - host: 127.0.0.1
  - port: 8080

CORS_CONF:
  - allow_origins:
      - "*"
  - allow_methods:
      - "*"
  - allow_headers:
      - "*"

# DashScope(Qwen) API Key
DASHSCOPE_API_KEY: ""

```

- `backend/settings.py`：读取服务启动配置

请确保：

- MySQL 连接可用
- 数据库账号有建表与读写权限
- 规则文件目录与导出目录可写

### 4.2 前端配置

在 `frontend` 下创建或修改 `.env`：

```bash
VITE_API_BASE=http://127.0.0.1:8080
```

---

## 5. 启动方式

### 5.1 一键启动（推荐）

- Windows：运行根目录 `start.bat`
- Linux/macOS：运行根目录 `start.sh`

### 5.2 手动启动

后端：

```bash
cd backend
python main.py
```

前端：

```bash
cd frontend
npm run dev
```

默认访问：

- 前端：`http://localhost:5173`
- 后端：`http://127.0.0.1:8080`

---

## 6. 主要功能流程

1. 在“文件管理”上传流量文件（pcap 等）
2. 执行“提取”生成协议特征
3. 执行“检测”进行规则匹配与 AI 分析
4. 在“查看结果”中查看 YARA 与 AI 结果
5. 导出 JSON / 生成 PDF 报告
6. 在“导出文件”中下载生成物

---

## 7. 前端页面说明

- 仪表盘：总体统计、协议分布、规则分布
- 文件管理：上传、查询、提取、检测、查看结果、报告导出
- 规则管理：规则转换（IP/域名）、规则查询与筛选
- 流量特征：按协议查询与导出特征数据
- 日志：系统日志与业务日志查询/导出
- 导出文件：下载与删除导出记录
- 帮助：快速说明与运行提示

---

## 8. 后端接口概览（节选）

### 文件与检测

- `POST /upload/` 上传文件
- `GET /upload/show/` 文件列表
- `POST /upload/search/` 文件搜索
- `GET /upload/delete/{file_id}` 删除文件
- `GET /detect/file/{file_id}` 执行检测
- `GET /detect/result/search/{file_id}` 查询检测结果
- `GET /report/pdf/{file_id}` 生成 PDF 报告
- `GET /result/export/{file_id}` 导出检测 JSON

### 特征

- `GET /traffic/feature/extract/{file_id}` 提取特征
- `POST /traffic/feature/show/` 查询特征
- `POST /traffic/feature/export/` 导出特征

### 规则

- `POST /rules/convert/ip-file`
- `POST /rules/convert/domain-file`
- `GET /rules/show/`
- `POST /rules/search/`
- `GET /rules/options/`

### 日志

- `POST /logs/system/search/`
- `POST /logs/business/search/`
- `GET /logs/system/options/`
- `GET /logs/business/options/`

### 导出与下载

- `GET /exported/files/show/`
- `GET /exported/file/delete/{fid}`
- `GET /download/{fid}`

---

## 9. 常见问题

### Q1: 前端请求失败（跨域或网络错误）

- 检查后端是否启动
- 检查 `VITE_API_BASE` 是否正确
- 检查后端 CORS 配置

### Q2: 报告中文乱码

- 系统会自动尝试加载 Windows 中文字体（微软雅黑/黑体/宋体）
- 若运行环境无这些字体，请安装中文字体后重试

### Q3: 上传成功但检测失败

- 检查文件是否先执行“提取”
- 检查规则文件是否正确初始化
- 检查数据库连接与写入权限

---

## 10. 开发建议

- 后端开发：优先在 `backend/src/api` 增加接口，在 `backend/src/core` 实现业务逻辑
- 前端开发：优先复用 `frontend/src/components` 的通用组件
- 新增字段时，注意同步：数据库模型、接口返回、前端列名映射、报告导出

---

## 11. License

见仓库根目录 `LICENSE`。
