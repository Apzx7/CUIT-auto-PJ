import os
import re
import uuid
from datetime import datetime
from typing import Iterable, Optional

from ..logger.log_manager import LogManager
from ..settings import YARARule, SystemStatus
from ..storage.mysql_control import MysqlSimClass
from datetime import datetime


class YaraRulesInitializer:
	def __init__(self) -> None:
		self.logger = LogManager()
		self.logger_name = "YaraRulesInitializer"
		self.target_dir = os.path.dirname(os.path.abspath(__file__))
		self.rules_directory = os.path.join(self.target_dir, '../../yara-rules')
		self.session = MysqlSimClass().get_session()

	def __parse_date(self, value: Optional[str]) -> Optional[datetime]:
		if not value:
			return None
		for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y-%m-%d %H:%M:%S"):
			try:
				return datetime.strptime(value, fmt)
			except ValueError:
				continue
		try:
			return datetime.fromisoformat(value)
		except Exception:
			return None

	def __extract_rule_blocks(self, content: str) -> Iterable[tuple[str, str]]:
		pattern = re.compile(r"rule\s+(\w+)\s*\{", re.MULTILINE)
		for match in pattern.finditer(content):
			name = match.group(1)
			start = match.start()
			brace = 0
			i = content.find("{", start)
			if i == -1:
				continue
			for j in range(i, len(content)):
				if content[j] == "{":
					brace += 1
				elif content[j] == "}":
					brace -= 1
					if brace == 0:
						yield name, content[i + 1:j]
						break

	def __extract_meta(self, block: str) -> dict[str, str]:
		meta: dict[str, str] = {}
		m = re.search(r"\bmeta:\s*(.*?)(\n\s*strings:|\n\s*condition:|$)",
					  block, flags=re.S | re.I)
		if not m:
			return meta
		meta_body = m.group(1)
		for line in meta_body.splitlines():
			line = line.strip()
			if not line or line.startswith("//"):
				continue
			kv = re.split(r"\s*=\s*", line, maxsplit=1)
			if len(kv) != 2:
				continue
			key = kv[0].strip()
			val = kv[1].strip().strip('"').strip("'")
			meta[key] = val
		return meta

	def __upsert_rules_for_file(self, file_path: str) -> None:
		try:
			with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
				content = f.read()
		except Exception as e:
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="read yara file",
				message=f"read {file_path} failed: {e}"
			)
			return

		items = [(name, self.__extract_meta(block))
				 for name, block in self.__extract_rule_blocks(content)]
		if not items:
			return

		try:
			rule_names = [name for name, _ in items]
			existing = (self.session.query(YARARule)
						.filter(YARARule.rule_location == file_path,
								YARARule.rule_name.in_(rule_names))
						.all())
			existing_map = {r.rule_name: r for r in existing}

			new_records = []
			for rule_name, meta in items:
				record = existing_map.get(rule_name)
				if record is None:
					record = YARARule(
						fid=str(uuid.uuid4()),
						rule_name=rule_name,
						rule_location=file_path,
					)
					new_records.append(record)

				record.category = meta.get("category").lower() if meta.get("category") else None  # type: ignore
				record.description = meta.get("description")  # type: ignore
				record.author = meta.get("author")  # type: ignore
				record.reference = meta.get("reference")  # type: ignore
				record.malware_type = meta.get("malware_type").lower() if meta.get("malware_type") else None  # type: ignore
				record.security_level = meta.get("security_level").lower() if meta.get("security_level") else None  # type: ignore
				record.date = self.__parse_date(meta.get("date"))  # type: ignore

			if new_records:
				self.session.bulk_save_objects(new_records)
			self.session.commit()
		except Exception as e:
			self.session.rollback()
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="save yara meta",
				message=f"save meta failed for {file_path}: {e}"
			)

	def init_rules(self) -> None:
		try:
			marker = self.session.query(SystemStatus).first()
			if marker and getattr(marker, "is_rules_inited", False):
				return

			for root, _, files in os.walk(self.rules_directory):
				for file in files:
					if file.endswith('.yar') or file.endswith('.yara'):
						file_path = os.path.join(root, file)
						self.__upsert_rules_for_file(file_path)

			if marker is None:
				marker = SystemStatus(is_rules_inited=True, rules_inited_at=datetime.now())
				self.session.add(marker)
			else:
				marker.is_rules_inited = True
				marker.rules_inited_at = datetime.now()
			self.session.commit()
		except Exception as e:
			self.session.rollback()
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="init rules",
				message=f"init rules failed: {e}"
			)
