import os
import yara  # type: ignore
from typing import Generator, Any


class YaraRulesLoader:
    def __init__(self):
        self.target_dir = os.path.dirname(os.path.abspath(__file__))
        self.rules_directory = os.path.join(self.target_dir, '../../yara-rules')

    def load_rules(self) -> dict[str, Any]:
        '''
        Load YARA rules from the rules directory.
        return: A dictionary of compiled YARA rules.
        '''
        rules = {}
        for root, _, files in os.walk(self.rules_directory):
            for file in files:
                if file.endswith('.yar') or file.endswith('.yara'):
                    file_path = os.path.join(root, file)
                    try:
                        rules[file] = yara.compile(filepath=file_path)
                    except Exception as e:
                        print(f"Error compiling {file_path}: {e}")
                        exit(1)
        return rules
