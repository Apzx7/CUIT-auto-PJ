from typing import Optional, List, Dict

from ..storage.mysql_control import MysqlSimClass
from ..settings import YARARule
from ..logger.log_manager import LogManager


class ShowRules:
	def __init__(self) -> None:
		self.engine = MysqlSimClass().get_engine()
		self.session = MysqlSimClass().get_session()
		self.logger = LogManager()
		self.logger_name = "RulesManage"

	def get_all_records(self) -> Optional[List[Dict]]:
		"""Return all YARA rule records."""
		try:
			records = self.session.query(YARARule).all()
			return [
				{
					"fid": r.fid,
					"rule_name": r.rule_name,
					"category": r.category,
					"description": r.description,
					"author": r.author,
					"reference": r.reference,
					"malware_type": r.malware_type,
					"security_level": r.security_level,
					"date": r.date,
				}
				for r in records
			]
		except Exception as e:
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="get all rule records",
				message=f"Error occurred while retrieving rules: {e}"
			)
			return None
		finally:
			try:
				self.session.close()
			except Exception:
				pass

	def query_rules(self, security_level: Optional[str] = None,
					category: Optional[str] = None) -> Optional[List[Dict]]:
		"""Query YARA rules by security_level and/or category."""
		try:
			query = self.session.query(YARARule)
			if security_level:
				query = query.filter(YARARule.security_level == security_level)
			if category:
				query = query.filter(YARARule.category == category)
			records = query.all()
			return [
				{
					"fid": r.fid,
					"rule_name": r.rule_name,
					"category": r.category,
					"description": r.description,
					"author": r.author,
					"reference": r.reference,
					"malware_type": r.malware_type,
					"security_level": r.security_level,
					"date": r.date,
				}
				for r in records
			]
		except Exception as e:
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="query rule records",
				message=f"Error occurred while querying rules: {e}"
			)
			return None
		finally:
			try:
				self.session.close()
			except Exception:
				pass
