class ProtocolHandler():
    def __init__(self) -> None:
        self.allow_protocol = ['tcp_udp', 'icmp', 'dns', 'http', "tls_certificate"]
        self.allow_type = ['request', 'response']
        # allowed type per protocol to keep validation clear
        self.protocol_type_map = {
            'http': {'request', 'response'},
            'dns': {'request', 'response'},
        }

    def filter_protocol_type(self, protocol: str, type: str) -> bool:
        '''
        fliter protocol and type(request and response)
        param: protocol: tcp, udp, icmp, dns, http
        param: type: request, response
        return: bool, True if protocol and type is allowed
        '''
        protocol = protocol.lower()
        type = type.lower()
        # protocols that don't have type distinction
        special_protocols = ['tcp_udp', 'icmp', 'tls_certificate']

        if protocol not in self.allow_protocol:
            return False
        
        if protocol in special_protocols:
                return True

        # protocol-specific type validation
        allowed_types = self.protocol_type_map.get(protocol)
        if allowed_types is None:
            return False

        if type not in allowed_types:
            return False

        return True
