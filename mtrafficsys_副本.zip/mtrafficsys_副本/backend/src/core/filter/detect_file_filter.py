import os


class FileSizeHandler():
    def __init__(self):
        # 300MB
        self.max_size = 300 * 1024 * 1024

    def filter_file_size(self, file_path: str):
        # get file size
        file_size = os.path.getsize(file_path)
        return file_size <= self.max_size

    def show_max_size_for_human(self):
        return f'{self.max_size / 1024 / 1024}MB'
