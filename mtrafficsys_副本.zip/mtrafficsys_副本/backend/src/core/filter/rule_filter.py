from typing import Dict, List, Optional


class RuleHandler():
    def __init__(self) -> None:
        self.allow_security_levels = ["low", "medium", "high", "critical"]
        self.allow_categories = ["malware", "cve", "hacktool", "miner", "apt",
                                "misc", "web", "blackip", "blackdomain"]
          
    def get_allow_options(self) -> Dict[str, List[str]]:
        """Return allowed security levels and categories."""
        return {
            "security_levels": self.allow_security_levels,
            "categories": self.allow_categories
        }
    
    def validate(self, security_level: Optional[str], category: Optional[str]) -> bool:
        """Validate if the given security level and category are allowed."""
        if not security_level or not category:
            return True  # Allow empty values for optional filtering
        if security_level not in self.allow_security_levels:
            return False
        if category not in self.allow_categories:
            return False
        return True
