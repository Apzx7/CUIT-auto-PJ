from hashlib import md5
import hashlib
import pathlib
import secrets


class UploadFileHandler():
    def __init__(self, file_name: str) -> None:
        self.fname = file_name
        # traffic file extension
        self.allowed_traffic_extensions = ['pcap', 'pcapng']
        self.allowed_ascii_extensions = ['txt']

    def get_renamed_file(self) -> str:
        """
        rename file with md5 and token
        return: str, new file name
        """
        random = secrets.randbits(32)
        tmp_file_name = md5((self.fname + str(random)).encode()).hexdigest()
        return tmp_file_name

    def get_pcap_header_hash(self, header_bytes: bytes) -> str:
        """
        计算指定 pcap 文件开头部分的 SHA256 哈希值(16进制)。

        :param num_bytes: 要读取的字节数，默认读取 4096 字节
        :return: 文件开头部分的 SHA256 哈希值
        """
        sha256_hash = hashlib.sha256()
        sha256_hash.update(header_bytes)

        return sha256_hash.hexdigest()

    def get_file_size(self, file_path: str) -> str:
        """
        get file size and return in MB with two decimals, e.g. '1.23 MB'
        """
        # get file size(bytes)
        file_size_bytes = pathlib.Path(file_path).stat().st_size
        # convert to MB
        file_size_mb = file_size_bytes / (1024 * 1024)
        return f"{file_size_mb:.2f} MB"

    def get_file_extension(self) -> str:
        """
        get file extension
        return: str, file extension
        """
        return self.fname.split('.')[-1].lower()

    def filter_traffic_file_extension(self) -> bool:
        """
        filter file extension
        param fextension: str, file extension
        return: bool, True if allowed, False if not allowed
        """
        fextension = self.get_file_extension()
        return fextension in self.allowed_traffic_extensions
    
    def filter_ascii_file_extension(self) -> bool:
        """
        filter ascii file extension
        param fextension: str, file extension
        return: bool, True if allowed, False if not allowed
        """
        fextension = self.get_file_extension()
        return fextension in self.allowed_ascii_extensions
