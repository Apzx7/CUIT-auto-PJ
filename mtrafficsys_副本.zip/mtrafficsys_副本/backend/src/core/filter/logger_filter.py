from typing import Optional


class LoggerHandler():
	def __init__(self):
		self.allow_syslog_levels = ["debug", "info", "warning", "error", "critical"]
		self.allow_buslog_status = ["success", "failure"]

	def get_allow_options(self):
		return {
			"syslog_levels": self.allow_syslog_levels,
			"buslog_status": self.allow_buslog_status
		}
	
	def validate_syslog_level(self, level: Optional[str]) -> bool:
		if not level:
			return True  # Allow empty level for optional filtering
		return level in self.allow_syslog_levels
	
	def validate_buslog_status(self, status: Optional[str]) -> bool:
		if not status:
			return True  # Allow empty status for optional filtering
		return status in self.allow_buslog_status
