from pathlib import Path


class ResourceHandler():
    def __init__(self) -> None:
        self.allow_prefix = ['http', 'https']

    def filter_resource_prefix(self, resource: str) -> bool:
        '''
        fliter resource prefix
        param: resource: str
        return: bool, True if resource prefix is allowed
        '''
        # get prefix
        prefix = resource.split(':')[0]
        return prefix in self.allow_prefix


class ResourcesFileHandler():
    def __init__(self) -> None:
        self.allow_file_type = ['txt', 'list']

    def filter_resource_file_type(self, file_path: str) -> bool:
        '''
        fliter file type
        param: file_path: str
        return: bool, True if file type is allowed
        '''
        # get file type
        file_type = Path(file_path).suffix[1:].lower()
        return file_type in self.allow_file_type
