from datetime import datetime
from typing import Optional


class TimeHandler():
    def __init__(self):
        pass

    def check_time(self, start_time: Optional[str],
                   end_time: Optional[str]) -> bool:
        """检查开始时间是否早于结束时间
        ISO format: YYYY-MM-DDTHH:MM:SS"""
        try:
            if (not start_time) or (not end_time):
                return True
            start = datetime.fromisoformat(start_time) if start_time else None
            end = datetime.fromisoformat(end_time) if end_time else None
            if start and end and start > end:
                return False
            return True
        except ValueError:
            return False
