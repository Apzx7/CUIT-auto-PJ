from typing import Optional, Tuple
from pathlib import Path
from datetime import datetime, date
from uuid import uuid4
import json

from ..logger.log_manager import LogManager
from ..settings import DetectionResult, ExportedFileInfo, EXPORT_DIRECTORY
from ..storage.mysql_control import MysqlSimClass


class ExportScanResult:
    def __init__(self) -> None:
        self.mysql_sim = MysqlSimClass()
        self.logger = LogManager()
        self.actor = "ExportScanResult"
        self.export_dir = Path(EXPORT_DIRECTORY)
        self.engine = self.mysql_sim.get_engine()
        self.c_time = datetime.now().strftime('%Y%m%d_%H%M%S')

    def __ensure_directory_exists(self) -> None:
        """Ensure the target directory exists before writing files."""
        if not self.export_dir.exists():
            self.export_dir.mkdir(parents=True, exist_ok=True)

    def __get_file_size(self, file_path: str) -> str:
        """Return a human-readable file size for the exported file."""
        try:
            file_bytes = Path(file_path).stat().st_size
            if file_bytes < 1024:
                return f"{file_bytes} B"
            if file_bytes < 1024 ** 2:
                return f"{file_bytes / 1024:.2f} KB"
            if file_bytes < 1024 ** 3:
                return f"{file_bytes / (1024 ** 2):.2f} MB"
            return f"{file_bytes / (1024 ** 3):.2f} GB"
        except Exception:
            return "0 B"

    def __save_exported_file_info(self,
                                  file_name: str,
                                  file_id: str,
                                  file_path: str,
                                  file_type: str = "csv") -> None:
        """Persist exported file metadata to the database."""
        exported_file_info = ExportedFileInfo(
            fid=file_id,
            name=file_name,
            path=file_path,
            export_date=datetime.now(),
            format=file_type,
            size=self.__get_file_size(file_path),
        )
        with self.mysql_sim.get_session() as session:
            session.add(exported_file_info)
            session.commit()

    def export_result_to_json(self,
                              file_id: str) -> Optional[Tuple[str, str]]:
        """Export detection result of a given file_id to JSON."""
        self.__ensure_directory_exists()
        with self.mysql_sim.get_session() as session:
            query_results = session.query(DetectionResult).filter(
                DetectionResult.uploaded_file_fid == file_id
            ).first()

        if not query_results:
            return None

        record_dict = {
            "uploaded_file_fid": query_results.uploaded_file_fid,
            # convert datetime to string for JSON serialization
            "detected_at": query_results.detected_at.strftime('%Y-%m-%d %H:%M:%S'),
            "cost_time": query_results.cost_time,
            "result_json": query_results.result_json,
        }

        export_file_name = f"scan_result_{file_id}_{self.c_time}.json"
        export_file_path = self.export_dir / export_file_name

        try:
            with open(export_file_path, 'w', encoding='utf-8') as f:
                json.dump(record_dict, f, ensure_ascii=False, indent=4)
        except Exception as e:
            self.logger.add_business_log(
                category="ExportScanResult",
                actor=self.actor,
                action="export to JSON",
                detail=f"Failed to write JSON file for {file_id}: {e}",
                result="failed",
            )
            return None

        file_uuid = str(uuid4())
        self.__save_exported_file_info(
            file_name=export_file_name,
            file_id=file_uuid,
            file_path=str(export_file_path),
            file_type="json",
        )

        return export_file_name, file_uuid
