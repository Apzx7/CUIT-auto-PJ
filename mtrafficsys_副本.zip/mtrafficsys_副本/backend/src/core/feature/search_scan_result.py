from datetime import datetime
from typing import List, Optional, Union, Dict, Any

from sqlalchemy import and_

from ..logger.log_manager import LogManager
from ..settings import DetectionResult
from ..storage.mysql_control import MysqlSimClass


class SearchScanResultFeature:
    """Provide query helpers for DetectionResult records."""

    def __init__(self) -> None:
        self.mysql_sim = MysqlSimClass()
        self.logger = LogManager()
        self.actor = "DetectionResultQuery"

    def _normalize_time(self,
                        value: Optional[Union[str, datetime]]) -> Optional[datetime]:  # noqa
        """Accept datetime or ISO string; return datetime or None on failure.
        """
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        try:
            return datetime.fromisoformat(value)
        except Exception:
            self.logger.add_business_log(
                category=self.actor,
                actor=self.actor,
                action="Parse time string",
                detail=f"Invalid time format: {value}",
                result="Failure",
            )
            return None

    def query(
        self,
        start_time: Optional[Union[str, datetime]] = None,
        end_time: Optional[Union[str, datetime]] = None,
        file_id: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """
        Query DetectionResult records by optional time range and file id.

        :param start_time: inclusive start time (datetime or ISO string)
        :param end_time: inclusive end time (datetime or ISO string)
        :param file_id: uploaded file fid to filter by
        :return: list of serialized detection result rows
        """
        filters = []
        start_dt = self._normalize_time(start_time)
        end_dt = self._normalize_time(end_time)

        if file_id:
            filters.append(DetectionResult.uploaded_file_fid == file_id)
        if start_dt:
            filters.append(DetectionResult.detected_at >= start_dt)
        if end_dt:
            filters.append(DetectionResult.detected_at <= end_dt)

        try:
            with self.mysql_sim.get_session() as session:
                query = session.query(DetectionResult)
                if filters:
                    query = query.filter(and_(*filters))
                rows = query.order_by(DetectionResult.detected_at.desc()).all()

                return rows
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.actor,
                action="Query detection results",
                message=f"Query failed: {e}",
            )
            return []

    def query_detection_results_by_fid(
        self,
        file_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Query DetectionResult records by optional time range and file id.

        :param start_time: inclusive start time (datetime or ISO string)
        :param end_time: inclusive end time (datetime or ISO string)
        :param file_id: uploaded file fid to filter by
        :return: result_json column of matched records
        """
        if not file_id:
            self.logger.add_system_log(
                level="WARNING",
                logger_name=self.actor,
                action="Query detection results by fid",
                message="file_id is None or empty",
            )
            return {}

        try:
            with self.mysql_sim.get_session() as session:
                query = session.query(DetectionResult).filter(
                    DetectionResult.uploaded_file_fid == file_id
                )
                row = query.order_by(
                    DetectionResult.detected_at.desc()
                ).first()

                if row:
                    return row.result_json
                else:
                    return {}
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.actor,
                action="Query detection results",
                message=f"Query failed: {e}",
            )
            return {}
