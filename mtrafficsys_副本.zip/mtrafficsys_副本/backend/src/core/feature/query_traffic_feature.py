from ..settings import TcpUdp, DnsRequest, DnsResponse, \
    HttpRequest, HttpResponse, ICMP, TLSCertificate
from ..logger.log_manager import LogManager
from ..storage.mysql_control import MysqlSimClass
from typing import Optional, Any, Dict, List


class QueryFeature():
    def __init__(self) -> None:
        # init logger
        self.g_logger = LogManager()
        self.actor = "TrafficFeatureManage"
        # 创建数据库引擎
        self.engine = MysqlSimClass().get_engine()

        self.session = MysqlSimClass().get_session()

        # set max line to fetch, protect memory
        self.max_line = 1000

    def fetch_tcp_udp_traffic(self) -> Optional[List[TcpUdp]]:
        """get all Tcp and Udp feature from database"""
        try:
            return self.session.query(TcpUdp).limit(self.max_line).all()
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch tcp and udp traffic",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_tcp_udp_traffic_by_file(self, file_id: str
                                      ) -> Optional[List[TcpUdp]]:
        """get Tcp/Udp feature by uploaded file id"""
        try:
            return (self.session.query(TcpUdp)
                    .filter_by(uploaded_file_fid=file_id)
                    .limit(self.max_line).all())
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch tcp and udp traffic by file",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_dns_request_traffic(self) -> Optional[List[DnsRequest]]:
        '''get all dns request feature traffic from database'''
        try:
            return self.session.query(DnsRequest).limit(self.max_line).all()
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch dns request traffic",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_dns_request_traffic_by_file(self, file_id: str
                                          ) -> Optional[List[DnsRequest]]:
        '''get dns request feature traffic by uploaded file id'''
        try:
            return (self.session.query(DnsRequest)
                    .filter_by(uploaded_file_fid=file_id)
                    .limit(self.max_line).all())
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch dns request traffic by file",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_dns_response_traffic(self) -> Optional[List[DnsResponse]]:  # noqa
        '''get all dns response feature traffic from database'''
        try:
            return self.session.query(DnsResponse).limit(self.max_line).all()
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch dns response traffic",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_dns_response_traffic_by_file(self, file_id: str
                                           ) -> Optional[List[DnsResponse]]:  # noqa
        '''get dns response feature traffic by uploaded file id'''
        try:
            return (self.session.query(DnsResponse)
                    .filter_by(uploaded_file_fid=file_id)
                    .limit(self.max_line).all())
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch dns response traffic by file",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_http_request_traffic(self) -> Optional[List[Dict[str, Any]]]:  # noqa
        '''get all http request feature traffic from database,
        unpack OrderedDict/JSON headers'''
        try:
            rows = self.session.query(HttpRequest).limit(self.max_line).all()
            return rows
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch http request traffic",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_http_request_traffic_by_file(self, file_id: str
                                           ) -> Optional[List[Dict[str, Any]]]:  # noqa
        '''get http request feature traffic by uploaded file id'''
        try:
            rows = (self.session.query(HttpRequest)
                    .filter_by(uploaded_file_fid=file_id)
                    .limit(self.max_line).all())
            return rows
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch http request traffic by file",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_http_response_traffic(self) -> Optional[List[Dict[str, Any]]]:  # noqa
        '''get all http response feature traffic from database,
        unpack OrderedDict/JSON headers'''
        try:
            rows = self.session.query(HttpResponse).limit(self.max_line).all()
            return rows
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch http response traffic",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_http_response_traffic_by_file(self, file_id: str
                                            ) -> Optional[List[Dict[str, Any]]]:  # noqa
        '''get http response feature traffic by uploaded file id'''
        try:
            rows = (self.session.query(HttpResponse)
                    .filter_by(uploaded_file_fid=file_id)
                    .limit(self.max_line).all())
            return rows
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch http response traffic by file",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_icmp_traffic(self) -> Optional[List[ICMP]]:
        '''get all icmp feature from database'''
        try:
            return self.session.query(ICMP).limit(self.max_line).all()
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch icmp traffic",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_icmp_traffic_by_file(self, file_id: str
                                   ) -> Optional[List[ICMP]]:
        '''get icmp feature by uploaded file id'''
        try:
            return (self.session.query(ICMP)
                    .filter_by(uploaded_file_fid=file_id)
                    .limit(self.max_line).all())
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch icmp traffic by file",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_tls_certificate_traffic(self) -> Optional[List[TLSCertificate]]:
        '''get all tls certificate feature from database'''
        try:
            max_line = self.max_line
            return self.session.query(TLSCertificate).limit(max_line).all()
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch tls certificate traffic",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_tls_certificate_traffic_by_file(self, file_id: str
                                              ) -> Optional[List[TLSCertificate]]:
        '''get tls certificate feature by uploaded file id'''
        try:
            max_line = self.max_line
            return (self.session.query(TLSCertificate)
                    .filter_by(uploaded_file_fid=file_id)
                    .limit(max_line).all())
        except Exception as e:
            self.g_logger.add_business_log(
                category="QueryTrafficFeature",
                actor=self.actor,
                action="Fetch tls certificate traffic by file",
                detail=f"Fetch data error: {e}.",
                result="Failure"
            )
            return []
        finally:
            self.session.close()

    def fetch_traffic(self, protocol: str,
                      packet_type: str) -> Optional[List[Any]]:
        """Unified traffic fetch by protocol and type.
        Mirrors the routing logic in API layer and validates inputs
        using `ProtocolHandler` to ensure allowed combinations.
        """
        p = protocol.lower()
        t = packet_type.lower()

        if p == "tcp_udp":
            return self.fetch_tcp_udp_traffic()
        if p == "dns":
            return (self.fetch_dns_request_traffic() if t == "request"
                    else self.fetch_dns_response_traffic())
        if p == "icmp":
            return self.fetch_icmp_traffic()
        if p == "http":
            return (self.fetch_http_request_traffic() if t == "request"
                    else self.fetch_http_response_traffic())
        if p == "tls_certificate":
            return self.fetch_tls_certificate_traffic()

        # Fallback (shouldn't reach due to validation), log and return empty
        self.g_logger.add_business_log(
            category="QueryTrafficFeature",
            actor=self.actor,
            action="Unsupported protocol",
            detail=f"Unsupported protocol after validation: {protocol}",
            result="Failure"
        )
        return []

    def fetch_traffic_by_file(self, protocol: str,
                              packet_type: str,
                              file_id: str) -> Optional[List[Any]]:
        """Unified traffic fetch by protocol/type and uploaded file id."""
        p = protocol.lower()
        t = packet_type.lower()

        if p == "tcp_udp":
            return self.fetch_tcp_udp_traffic_by_file(file_id)
        if p == "dns":
            return (self.fetch_dns_request_traffic_by_file(file_id)
                    if t == "request"
                    else self.fetch_dns_response_traffic_by_file(file_id))
        if p == "icmp":
            return self.fetch_icmp_traffic_by_file(file_id)
        if p == "http":
            return (self.fetch_http_request_traffic_by_file(file_id)
                    if t == "request"
                    else self.fetch_http_response_traffic_by_file(file_id))
        if p == "tls_certificate":
            return self.fetch_tls_certificate_traffic_by_file(file_id)

        self.g_logger.add_business_log(
            category="QueryTrafficFeature",
            actor=self.actor,
            action="Unsupported protocol",
            detail=f"Unsupported protocol after validation: {protocol}",
            result="Failure"
        )
        return []
