import pandas as pd  # type: ignore
from pathlib import Path
from ..storage.mysql_control import MysqlSimClass  # type: ignore
from ..settings import TABLES, EXPORT_DIRECTORY  # type: ignore
from ..logger.log_manager import LogManager  # type: ignore
from datetime import datetime
from ..settings import ExportedFileInfo  # type: ignore
from uuid import uuid4
from typing import Optional, Tuple
import json


class Pcap2Others():
    def __init__(self) -> None:
        self.g_logger = LogManager()
        self.actor = "TrafficFeatureManage"
        self.engine = MysqlSimClass().get_engine()
        self.session = MysqlSimClass().get_session()
        self.tb_names = {
            'dns_request': TABLES['extract_dns_request'],
            'dns_response': TABLES['extract_dns_response'],
            'tcp_udp': TABLES['extract_tcp_udp'],
            'icmp': TABLES['extract_icmp'],
            'http_request': TABLES['extract_http_request'],
            'http_response': TABLES['extract_http_response'],
            'tls_certificate': TABLES['extract_tls_certificate'],
        }
        self.export_dir = Path(EXPORT_DIRECTORY)
        self.c_time = datetime.now().strftime('%Y%m%d_%H%M%S')

    def __ensure_directory_exists(self) -> None:
        """if path is not exist, create it"""
        if not self.export_dir.exists():
            self.export_dir.mkdir(parents=True, exist_ok=True)

    def __create_tables(self) -> None:
        """create tables if not exist"""
        ExportedFileInfo.__table__.create(bind=self.engine, checkfirst=True)

    def __safe_load_json(self, val: Optional[str]) -> dict:
        """
        val expected to be json string or already a dict.
        Return dict on success, {} on failure.
        """
        if val is None:
            return {}
        if isinstance(val, dict):
            return val
        if not isinstance(val, str) or val.strip() == "":
            return {}
        try:
            return json.loads(val)
        except Exception:
            # last resort: try to replace single quotes (avoid unsafe eval)
            try:
                return json.loads(val.replace("'", '"'))
            except Exception:
                return {}

    def __get_file_size(self, file_path: str) -> str:
        """
        Get the size of the file in bytes.
        """
        try:
            file_bytes = Path(file_path).stat().st_size
            # convert to KB, MB, GB as appropriate
            if file_bytes < 1024:
                return f"{file_bytes} B"
            elif file_bytes < 1024 ** 2:
                return f"{file_bytes / 1024:.2f} KB"
            elif file_bytes < 1024 ** 3:
                return f"{file_bytes / (1024 ** 2):.2f} MB"
            else:
                return f"{file_bytes / (1024 ** 3):.2f} GB"
        except Exception:
            return "0 B"

    def __save_exported_file_info(self, file_name: str,
                                  file_id: str,
                                  file_path: str,
                                  file_type: str = 'csv') -> None:
        """
        Save information about the exported file to the database.
        """
        self.__create_tables()
        exported_file_info = ExportedFileInfo(
            fid=file_id,
            name=file_name,
            path=file_path,
            export_date=datetime.now(),
            format=file_type,
            size=self.__get_file_size(file_path),
        )
        with self.session as session:
            session.add(exported_file_info)
            session.commit()

    def _get_file_path_by_fid(self, file_id: str) -> Optional[str]:
        """
        Retrieve the file path for a given file ID from the database.
        """
        try:
            result = self.session.query(ExportedFileInfo).filter_by(
                fid=file_id).first()
            if result:
                return result.path
            return None
        except Exception as e:
            self.g_logger.add_system_log(
                level="Error",
                logger_name=self.actor,
                action="Get exported file path by fid",
                message=f"Query error: {e}.",
            )
            return None

    def export_traffic(self, protocol: str,
                       packet_type: str,
                       file_id: Optional[str] = None
                       ) -> Optional[Tuple[str, str]]:
        """Unified export by protocol/type, optional filter by file_id."""
        p = protocol.lower()
        t = packet_type.lower()

        if p in ("tcp", "udp"):
            return (self.tcp_udp2csv_by_file(file_id)
                    if file_id else self.tcp_udp2csv())
        if p == "dns":
            if t == "request":
                return (self.dns_request2csv_by_file(file_id)
                        if file_id else self.dns_request2csv())
            return (self.dns_response2csv_by_file(file_id)
                    if file_id else self.dns_response2csv())
        if p == "icmp":
            return (self.icmp2csv_by_file(file_id)
                    if file_id else self.icmp2csv())
        if p == "http":
            if t == "request":
                return (self.http_request2csv_by_file(file_id)
                        if file_id else self.http_request2csv())
            return (self.http_response2csv_by_file(file_id)
                    if file_id else self.http_response2csv())
        if p == "tls":
            return (self.tls_certificate2csv_by_file(file_id)
                    if file_id else self.tls_certificate2csv())

        self.g_logger.add_business_log(
            category="TrafficFeatureExport",
            actor=self.actor,
            action="Unsupported protocol",
            detail=f"Unsupported protocol after validation: {protocol}",
            result="Failure"
        )
        return None

    def __export_query_to_csv(self, query: str, csv_name: str,
                              json_field: Optional[str] = None,
                              chunksize: int = 10000) -> Optional[Tuple]:
        """
        Stream query results to CSV in chunks. If json_field provided,
        parse it into columns using json_normalize.
        Returns csv_name on success, None on no-data or failure.
        """
        self.__ensure_directory_exists()
        csv_path = self.export_dir / csv_name
        abs_csv_path = str(csv_path.resolve())
        file_id = str(uuid4())
        first_write = True
        written = False

        try:
            # read_sql_query with chunksize returns an iterator of DataFrames
            for chunk in pd.read_sql_query(sql=query, con=self.engine,
                                           chunksize=chunksize):
                if chunk.empty:
                    continue

                if json_field and json_field in chunk.columns:
                    # parse json field safely for the whole chunk
                    parsed_series = chunk[json_field].apply(self.__safe_load_json)  # noqa
                    # normalize into dataframe (fast C-optimized path)
                    try:
                        headers_df = pd.json_normalize(parsed_series.tolist())
                    except Exception:
                        # fallback: convert each dict to DataFrame row-by-row
                        headers_df = pd.DataFrame(list(parsed_series))
                    # concat and drop original json field
                    chunk = pd.concat([chunk.drop(columns=[json_field]),
                                       headers_df], axis=1)

                # write chunk to csv; write header only for first chunk
                if first_write:
                    chunk.to_csv(csv_path, index=False, mode='w',
                                 encoding='utf-8-sig')
                    first_write = False
                else:
                    chunk.to_csv(csv_path, index=False, mode='a',
                                 header=False, encoding='utf-8-sig')
                written = True

            self.__save_exported_file_info(
                file_name=csv_name,
                file_id=file_id,
                file_path=abs_csv_path,
            )
            return (csv_name, file_id) if written else None
        except Exception as e:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Export to csv error: {e}.",
                result="Failure"
            )
            return None

    def http_request2csv(self) -> Optional[Tuple[str, str]]:
        '''
        export http request to csv file
        '''
        query = f"SELECT * FROM {self.tb_names['http_request']}"
        csv_name = f'http_request_{self.c_time}_exported.csv'

        # parse JSON headers column into separate columns while streaming
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field='headers',
                                            chunksize=10000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail=f"Exported http request traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail="http request export produced no data or failed.",
                result="Failure"
            )
        return result

    def http_request2csv_by_file(self, file_id: str
                                 ) -> Optional[Tuple[str, str]]:
        query = (f"SELECT * FROM {self.tb_names['http_request']} "
                 f"WHERE uploaded_file_fid = '{file_id}'")
        csv_name = f'http_request_{file_id}_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field='headers',
                                            chunksize=10000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail=f"Exported http request traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail="http request export produced no data or failed.",
                result="Failure"
            )
        return result

    def http_response2csv(self) -> Optional[Tuple[str, str]]:
        '''
        export http response to csv file
        '''
        query = f"SELECT * FROM {self.tb_names['http_response']}"
        csv_name = f'http_response_{self.c_time}_exported.csv'

        # parse JSON headers column into separate columns while streaming
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field='headers',
                                            chunksize=10000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail=f"Exported http response traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail="http response export produced no data or failed.",
                result="Failure"
            )
        return result

    def http_response2csv_by_file(self, file_id: str
                                  ) -> Optional[Tuple[str, str]]:
        query = (f"SELECT * FROM {self.tb_names['http_response']} "
                 f"WHERE uploaded_file_fid = '{file_id}'")
        csv_name = f'http_response_{file_id}_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field='headers',
                                            chunksize=10000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail=f"Exported http response traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export Http traffic feature to csv",
                detail="http response export produced no data or failed.",
                result="Failure"
            )
        return result

    def dns_request2csv(self) -> Optional[Tuple[str, str]]:
        query = f"SELECT * FROM {self.tb_names['dns_request']}"
        csv_name = f'dns_request_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported dns request traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="dns request traffic export produced no data or failed.",  # noqa
                result="Failure"
            )
        return result

    def dns_request2csv_by_file(self, file_id: str
                                ) -> Optional[Tuple[str, str]]:
        query = (f"SELECT * FROM {self.tb_names['dns_request']} "
                 f"WHERE uploaded_file_fid = '{file_id}'")
        csv_name = f'dns_request_{file_id}_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported dns request traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="dns request traffic export produced no data or failed.",
                result="Failure"
            )
        return result

    def dns_response2csv(self) -> Optional[Tuple[str, str]]:
        query = f"SELECT * FROM {self.tb_names['dns_response']}"
        csv_name = f'dns_response_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported dns response traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="dns response traffic export produced no data or failed.",  # noqa
                result="Failure"
            )
        return result

    def dns_response2csv_by_file(self, file_id: str
                                 ) -> Optional[Tuple[str, str]]:
        query = (f"SELECT * FROM {self.tb_names['dns_response']} "
                 f"WHERE uploaded_file_fid = '{file_id}'")
        csv_name = f'dns_response_{file_id}_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported dns response traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="dns response traffic export produced no data or failed.",
                result="Failure"
            )
        return result

    def tcp_udp2csv(self) -> Optional[Tuple[str, str]]:
        query = f"SELECT * FROM {self.tb_names['tcp_udp']}"
        csv_name = f'tcp_udp_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported tcp and udp traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="tcp and udp traffic export produced no data or failed.",  # noqa
                result="Failure"
            )
        return result

    def tcp_udp2csv_by_file(self, file_id: str
                            ) -> Optional[Tuple[str, str]]:
        query = (f"SELECT * FROM {self.tb_names['tcp_udp']} "
                 f"WHERE uploaded_file_fid = '{file_id}'")
        csv_name = f'tcp_udp_{file_id}_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported tcp and udp traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="tcp and udp traffic export produced no data or failed.",
                result="Failure"
            )
        return result

    def icmp2csv(self) -> Optional[Tuple[str, str]]:
        query = f"SELECT * FROM {self.tb_names['icmp']}"
        csv_name = f'icmp_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported icmp traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="icmp traffic export produced no data or failed.",  # noqa
                result="Failure"
            )
        return result

    def icmp2csv_by_file(self, file_id: str
                         ) -> Optional[Tuple[str, str]]:
        query = (f"SELECT * FROM {self.tb_names['icmp']} "
                 f"WHERE uploaded_file_fid = '{file_id}'")
        csv_name = f'icmp_{file_id}_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported icmp traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="icmp traffic export produced no data or failed.",
                result="Failure"
            )
        return result

    def tls_certificate2csv(self) -> Optional[Tuple[str, str]]:
        query = f"SELECT * FROM {self.tb_names['tls_certificate']}"
        csv_name = f'tls_certificate_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported tls_certificate traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="tls_certificate traffic export produced no data or failed.",  # noqa
                result="Failure"
            )
        return result

    def tls_certificate2csv_by_file(self, file_id: str
                                    ) -> Optional[Tuple[str, str]]:
        query = (f"SELECT * FROM {self.tb_names['tls_certificate']} "
                 f"WHERE uploaded_file_fid = '{file_id}'")
        csv_name = f'tls_certificate_{file_id}_{self.c_time}_exported.csv'
        result = self.__export_query_to_csv(query, csv_name,
                                            json_field=None, chunksize=20000)
        if result:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail=f"Exported tls_certificate traffic to csv: {result}.",
                result="Success"
            )
        else:
            self.g_logger.add_business_log(
                category="TrafficFeatureExport",
                actor=self.actor,
                action="Export traffic feature to csv",
                detail="tls_certificate traffic export produced no data or failed.",
                result="Failure"
            )
        return result
