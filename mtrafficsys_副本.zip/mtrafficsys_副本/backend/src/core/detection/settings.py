from ..conf.load import YamlLoader


DASHSCOPE_API_KEY = YamlLoader().get_api_key()
BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
