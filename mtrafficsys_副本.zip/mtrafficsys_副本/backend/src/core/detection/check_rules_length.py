from ..logger.log_manager import LogManager
from pathlib import Path


class CheckRulesLength:
    def __init__(self):
        # init logger
        self.g_logger = LogManager()
        self.actor = "CheckRulesLength"
        # 最大单个规则文件行数
        self.MAX_LINES_PER_FILE = 100000

    def is_length_over_max(self, file_path: str) -> bool:
        """
        Check whether given rule file exceeds
        MAX_LINES_PER_FILE (by line count).
        Return True if >= MAX_LINES_PER_FILE.
        """
        try:
            p = Path(file_path)
            if not p.exists():
                return False
            # count non-empty lines
            with p.open('r') as f:
                cnt = sum(1 for line in f if line.strip())
            return cnt >= self.MAX_LINES_PER_FILE
        except Exception as e:
            self.g_logger.add_system_log(
                level="ERROR",
                logger_name=self.actor,
                action="check rules file length",
                message=f"Error occurred while checking rules file length: {e}"
            )
            return False
