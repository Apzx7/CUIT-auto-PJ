from ..rules.load_rules import YaraRulesLoader  # type: ignore
from typing import Any, Generator


class FileDetecter:
	def __init__(self):
		self.yara_loader = YaraRulesLoader()

	def __scan_from_file(self, file_path: str) -> Generator[tuple[str, list], None, None]:
		'''
        Scan a file for YARA matches.
        param file_path: The path to the file to scan.
        return: A list of tuples containing the rule name and matches.
        '''
		rules = self.yara_loader.load_rules()
        # TODO: if file is so large that it can't be detected at once
		with open(file_path, 'rb') as f:
			data = f.read()
			yield from (
				(rule_name, rule.match(data=data))
				for rule_name, rule in rules.items() if rule.match(data=data)
			)

	def parse_scan_results(self, file_path: str) -> list[dict[str, Any]]:
		'''
		Parse the results of scanning a file for YARA matches.
		param file_path: The path to the file to scan.
		return: A list of dictionaries containing rule and match details.
		'''
		match_infos: list[dict[str, Any]] = []
		all_matches = self.__scan_from_file(file_path)
		for rule_file_name, matches in all_matches:
			tmp_dic: dict[str, Any] = {
				'rule_file_name': rule_file_name,
				'match': [],
			}
			for match in matches:
				tmp_dic['match'].append({  
					"rule_name": match.rule,
					"description": match.meta.get('description', ''),
					"category": match.meta.get('category', ''),
					"malware_type": match.meta.get('malware_type', ''),
					"security_level": match.meta.get('security_level', ''),
				})
			match_infos.append(tmp_dic)
		return match_infos
