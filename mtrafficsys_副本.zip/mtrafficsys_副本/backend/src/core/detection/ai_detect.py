from .settings import DASHSCOPE_API_KEY, BASE_URL
from openai import OpenAI
from typing import Any, Dict, Union, List
import json


class AiDetect:
	def __init__(self):
		self.api_key = DASHSCOPE_API_KEY
		self.base_url = BASE_URL
		self.model = "qwen-flash"
		self.system_prompt = (
			"你是网络安全分析师。你将收到一段自然语言描述，内容是某文件的 "
			"YARA 静态规则命中信息。请基于命中结果进行分析与解释，最终仅输出 "
			"合法 JSON（不要 Markdown），字段包括：verdict（benign/suspicious/" \
			"malicious/unknown）、severity（none/low/medium/high/critical）、" \
			"category（字符串列表）、score（0-1，越高表示越可能恶意）、" \
			"reasons（字符串列表）、indicators（字符串列表）、" \
			"recommended_actions（字符串列表）。若信息不足，请返回 verdict=unknown，" \
			"并在 reasons 中说明原因。"
		)

	def payload_to_prompt(self, payload: Dict[str, Any]) -> str:
		"""Convert YARA payload into a natural language description (Chinese)."""
		file_id = payload.get("file_id", "unknown")
		match_count = payload.get("match_count", 0)
		yara_matches = payload.get("yara_matches", [])

		lines: List[str] = []
		lines.append("以下是某文件的 YARA 检测结果，请分析其风险与类别：")
		lines.append(f"文件 ID: {file_id}")
		lines.append(f"命中规则文件数: {len(yara_matches)}")
		lines.append(f"命中规则总数: {match_count}")

		for idx, group in enumerate(yara_matches, start=1):
			rule_file = group.get("rule_file_name", "unknown")
			rules = group.get("match", [])
			lines.append(f"规则文件 {idx}: {rule_file}，命中 {len(rules)} 条规则")
			for r_idx, rule in enumerate(rules, start=1):
				rule_name = rule.get("rule_name", "unknown")
				description = rule.get("description", "")
				category = rule.get("category", "")
				malware_type = rule.get("malware_type", "")
				security_level = rule.get("security_level", "")
				meta_parts = []
				if category:
					meta_parts.append(f"类别: {category}")
				if malware_type:
					meta_parts.append(f"恶意类型: {malware_type}")
				if security_level:
					meta_parts.append(f"安全等级: {security_level}")
				meta_text = ("；".join(meta_parts)) if meta_parts else "无元数据"
				desc_text = description if description else "无描述"
				lines.append(
					f"- 规则 {r_idx}: {rule_name}，描述: {desc_text}，{meta_text}"
				)

		lines.append("请给出总体判定，并总结关键命中原因。")
		return "\n".join(lines)

	def detect(self, payload: Union[str, Dict[str, Any]]) -> Dict[str, Any]:
		"""Analyze YARA detection results and return a JSON dict."""
		if isinstance(payload, str):
			payload_obj: Dict[str, Any] = {"text": payload}
			prompt_text = payload
		else:
			payload_obj = payload
			prompt_text = self.payload_to_prompt(payload_obj)

		client = OpenAI(
			api_key=self.api_key,
			base_url=self.base_url,
		)

		completion = client.chat.completions.create(
			model=self.model,
			messages=[
				{"role": "system", "content": self.system_prompt},
				{"role": "user", "content": prompt_text},
			]
		)
		content = completion.choices[0].message.content or ""
		try:
			return json.loads(content)
		except Exception:
			return {
				"verdict": "unknown",
				"severity": "none",
				"category": [],
				"score": 0.0,
				"reasons": ["model output was not valid JSON"],
				"indicators": [],
				"recommended_actions": [],
				"raw_output": content,
			}
