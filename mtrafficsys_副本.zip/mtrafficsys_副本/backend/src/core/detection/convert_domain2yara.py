from pathlib import Path
import re
from typing import List, Tuple, Set
from ..logger.log_manager import LogManager
from .check_rules_length import CheckRulesLength  # type: ignore
import random
from ..storage.mysql_control import MysqlSimClass  # type: ignore
from ..settings import BlackDomain  # type: ignore
from datetime import datetime


class ConvertDomain2Yara:
	def __init__(self) -> None:
		self.g_logger = LogManager()
		self.actor = "ConvertDomain2Yara"
		self.current_dir = Path(__file__).resolve().parent
		self.rules_dir = (self.current_dir / '../../yara-rules').resolve()
		self.checker = CheckRulesLength()
		self.session = MysqlSimClass().get_session()
		self.time_format = '%Y-%m-%d %H:%M'
		self.domain_rule_sample = '''
rule black_domain_{0}{{
	meta:
		description = "black domain {1}"
		date = "{2}"
		category = "BlackDomain"
		malware_type = "Domain Threat Intelligence"
		security_level = "Low"
	strings:
		$a = "{3}"
	condition:
		$a
}}'''
		self.domain_pattern = re.compile(r'^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+$',
										 re.IGNORECASE)

	def __ensure_rules_dir(self) -> None:
		if not self.rules_dir.exists():
			self.rules_dir.mkdir(parents=True, exist_ok=True)

	def __get_out_path(self) -> str:
		self.__ensure_rules_dir()
		file_name = 'black_domain_{}.yar'
		existing = list(self.rules_dir.glob('black_domain_*.yar'))
		if not existing:
			idx = 0
		else:
			idxs: List[int] = []
			for p in existing:
				m = re.search(r'black_domain_(\d+)\.yar$', p.name)
				if m:
					idxs.append(int(m.group(1)))
			idx = max(idxs) if idxs else 0
		candidate = str(self.rules_dir / file_name.format(idx))
		if self.checker.is_length_over_max(candidate):
			idx += 1
			candidate = str(self.rules_dir / file_name.format(idx))
		return candidate

	def __match_domain_format(self, domain: str) -> bool:
		return bool(self.domain_pattern.match(domain))
	
	def __get_random_hex(self, length: int = 8) -> str:
		sample_str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
		return ''.join(random.choices(sample_str, k=length))

	def __get_existing_domains(self) -> Set[str]:
		try:
			rows = (self.session.query(BlackDomain.domain_name)
					.all())
			return set(r[0] for r in rows if r and r[0])
		except Exception as e:
			self.g_logger.add_system_log(
				level="ERROR",
				logger_name=self.actor,
				action="fetch existing domain",
				message=f"fetch existing domain failed: {e}"
			)
			try:
				self.session.rollback()
			except Exception:
				pass
			return set()

	def convert_from_list(self, items: List[str], source: str) -> Tuple[str, int]:
		out_path = self.__get_out_path()
		candidates = set(items)
		existing_domains = self.__get_existing_domains()
		rules: List[str] = []
		new_domains: List[str] = []
		date = datetime.now().strftime(self.time_format)

		for domain in candidates:
			if not domain:
				continue
			line = domain.strip()
			if self.__match_domain_format(line):
				if line in existing_domains:
					continue
				random_suffix = self.__get_random_hex()
				rules.append(self.domain_rule_sample.format(random_suffix,
															line,
															date,
															line))
				new_domains.append(line)
			else:
				self.g_logger.add_system_log(
                    level="WARNING",
                    logger_name=self.actor,
                    action="validate domain",
                    message=f"{domain} format is incorrect"
                )

		if not rules:
			return (out_path, 0)

		try:
			with open(out_path, 'a') as f:
				f.write('\n'.join(rules) + '\n')
			if new_domains:
				objs = [BlackDomain(domain_name=d,
								source=source,
								destination=out_path)
						for d in new_domains]
				try:
					self.session.bulk_save_objects(objs)
					self.session.commit()
				except Exception as e:
					self.session.rollback()
					self.g_logger.add_system_log(
						level="ERROR",
						logger_name=self.actor,
						action="insert domain",
						message=f"insert domain failed: {e}"
					)
			return (out_path, len(rules))
		except Exception as e:
			self.g_logger.add_system_log(
				level="ERROR",
				logger_name=self.actor,
				action="write domain rules",
				message=f"write domain rules failed: {e}"
			)
			return (out_path, 0)
