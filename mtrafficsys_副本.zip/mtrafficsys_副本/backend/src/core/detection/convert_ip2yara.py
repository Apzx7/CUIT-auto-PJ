from pathlib import Path
import re
import ipaddress
from typing import List, Tuple, Set
from ..logger.log_manager import LogManager
from .check_rules_length import CheckRulesLength  # type: ignore
import random
from ..storage.mysql_control import MysqlSimClass  # type: ignore
from ..settings import BlackIP  # type: ignore
from datetime import datetime


class ConvertIP2Yara:
	def __init__(self) -> None:
		self.g_logger = LogManager()
		self.actor = "ConvertIP2Yara"
		self.current_dir = Path(__file__).resolve().parent
		self.rules_dir = (self.current_dir / '../../yara-rules').resolve()
		self.checker = CheckRulesLength()
		self.session = MysqlSimClass().get_session()
		self.time_format = '%Y-%m-%d %H:%M'
		self.ip_rule_sample = '''
rule black_ip_{0}{{
	meta:
		description = "black ip {1}"
		date = "{2}"
		category = "BlackIP"
		malware_type = "IP Threat Intelligence"
		security_level = "Low"
	strings:
		$a = "{3}"
	condition:
		$a
}}'''

	def __ensure_rules_dir(self) -> None:
		if not self.rules_dir.exists():
			self.rules_dir.mkdir(parents=True, exist_ok=True)

	def __get_out_path(self) -> str:
		self.__ensure_rules_dir()
		file_name = 'black_ip_{}.yar'
		existing = list(self.rules_dir.glob('black_ip_*.yar'))
		if not existing:
			idx = 0
		else:
			idxs: List[int] = []
			for p in existing:
				m = re.search(r'black_ip_(\d+)\.yar$', p.name)
				if m:
					idxs.append(int(m.group(1)))
			idx = max(idxs) if idxs else 0
		candidate = str(self.rules_dir / file_name.format(idx))
		if self.checker.is_length_over_max(candidate):
			idx += 1
			candidate = str(self.rules_dir / file_name.format(idx))
		return candidate

	def __is_valid_ip_or_cidr(self, s: str) -> bool:
		try:
			if '/' in s:
				ipaddress.ip_network(s, strict=False)
			else:
				ipaddress.ip_address(s)
			return True
		except Exception:
			return False

	def __get_random_hex(self, length: int = 8) -> str:
		sample_str = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
		return ''.join(random.choices(sample_str, k=length))

	def __get_existing_ips(self) -> Set[str]:
		try:
			rows = (self.session.query(BlackIP.ip_address)
					.all())
			return set(r[0] for r in rows if r and r[0])
		except Exception as e:
			self.g_logger.add_system_log(
				level="ERROR",
				logger_name=self.actor,
				action="fetch existing ip",
				message=f"fetch existing ip failed: {e}"
			)
			try:
				self.session.rollback()
			except Exception:
				pass
			return set()

	def convert_from_list(self, items: List[str], source: str) -> Tuple[str, int]:
		out_path = self.__get_out_path()
		candidates = set(items)
		existing_ips = self.__get_existing_ips()
		rules: List[str] = []
		new_ips: List[str] = []
		date = datetime.now().strftime(self.time_format)

		for ip in candidates:
			if not ip:
				continue
			line = ip.strip()
			if self.__is_valid_ip_or_cidr(line):
				if line in existing_ips:
					continue
				random_suffix = self.__get_random_hex()
				rules.append(self.ip_rule_sample.format(random_suffix, line, date, line))
				new_ips.append(line)
			else:
				self.g_logger.add_system_log(
					level="WARNING",
					logger_name=self.actor,
					action="validate ip",
					message=f"{ip} format is incorrect"
				)

		if not rules:
			return (out_path, 0)

		try:
			with open(out_path, 'a') as f:
				f.write('\n'.join(rules) + '\n')
			if new_ips:
				objs = [BlackIP(ip_address=ip,
							source=source,
							destination=out_path)
						for ip in new_ips]
				try:
					self.session.bulk_save_objects(objs)
					self.session.commit()
				except Exception as e:
					self.session.rollback()
					self.g_logger.add_system_log(
						level="ERROR",
						logger_name=self.actor,
						action="insert ip",
						message=f"insert ip failed: {e}"
					)
			return (out_path, len(rules))
		except Exception as e:
			self.g_logger.add_system_log(
				level="ERROR",
				logger_name=self.actor,
				action="write ip rules",
				message=f"write ip rules failed: {e}"
			)
			return (out_path, 0)
