from ..storage.mysql_control import MysqlSimClass
from ..settings import DetectionResult, Base
from ..logger.log_manager import LogManager
import datetime
from typing import Optional
import json


class SaveDetection():
    def __init__(self):
        self.session = MysqlSimClass().get_session()
        self.logger = LogManager()
        self.logger_name = "DetectionResultManage"
        # 确保表存在（开发环境可用）
        try:
            Base.metadata.create_all(self.session.bind)
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="Save detection result",
                message=f"Error creating tables: {e}"
            )

    def save_result(self, file_id: str, result: dict,
                    cost_time: float, matched_count: int) -> Optional[int]:
        """
        保存检测结果到数据库
        :param file_id: 上传文件的唯一标识符
        :param result: 检测结果的字典表示
        :return: 新插入记录的ID, 或None(如果保存失败)
        """
        try:
            # time format: YYYY-MM-DD HH:MM:SS
            ddate = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            result_json = json.dumps(result, ensure_ascii=False)
            rec = DetectionResult(
                uploaded_file_fid=file_id,
                detected_at=ddate,
                result_json=result_json,
                cost_time=cost_time,
                matched_rules_count=matched_count
            )
            self.session.add(rec)
            self.session.commit()
            return rec.id  # type: ignore
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="Save detection result",
                message=f"Error saving detection result: {e}"
            )
            try:
                self.session.rollback()
            except Exception:
                pass
            return None
