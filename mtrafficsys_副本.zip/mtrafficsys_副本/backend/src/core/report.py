from __future__ import annotations

from datetime import datetime
import uuid
import json
from pathlib import Path
from typing import Dict, Any, Optional, List, Tuple

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import (
	SimpleDocTemplate, Table, TableStyle, Paragraph, 
	Spacer, PageBreak, Image, KeepTogether
)
from reportlab.pdfgen import canvas
from reportlab.graphics.shapes import Drawing, Rect, String
from reportlab.graphics.charts.piecharts import Pie
from reportlab.graphics import renderPDF
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from sqlalchemy.sql import func

from .logger.log_manager import LogManager
from .storage.mysql_control import MysqlSimClass
from .settings import (
	REPORT_DIRECTORY, UploadedFileInfo, DetectionResult,
	TcpUdp, DnsRequest, DnsResponse, HttpRequest, HttpResponse,
	ICMP, TLSCertificate, YARARule, ExportedFileInfo
)

# Professional color scheme (Burp Suite style)
COLOR_PRIMARY = colors.HexColor('#FF6600')  # Orange
COLOR_SECONDARY = colors.HexColor('#333333')  # Dark Gray
COLOR_ACCENT = colors.HexColor('#0099CC')  # Blue
COLOR_SUCCESS = colors.HexColor('#5CB85C')  # Green
COLOR_WARNING = colors.HexColor('#F0AD4E')  # Yellow
COLOR_DANGER = colors.HexColor('#D9534F')  # Red
COLOR_HEADER_BG = colors.HexColor('#F5F5F5')  # Light Gray
COLOR_BORDER = colors.HexColor('#DDDDDD')  # Border Gray


class ReportGenerator:
	def __init__(self) -> None:
		self.logger = LogManager()
		self.logger_name = "ReportGenerator"
		self.session = MysqlSimClass().get_session()
		self.report_dir = Path(REPORT_DIRECTORY)
		self.styles = getSampleStyleSheet()
		self._setup_fonts()
		self._setup_custom_styles()
		self.report_date = datetime.now()

	def _setup_fonts(self) -> None:
		"""Register a Chinese-capable font for PDF text rendering."""
		self.font_regular = 'Helvetica'
		self.font_bold = 'Helvetica-Bold'

		font_candidates: List[Tuple[str, str, Optional[str]]] = [
			('YaHei', 'msyh.ttc', 'msyhbd.ttc'),
			('SimHei', 'simhei.ttf', None),
			('SimSun', 'simsun.ttc', None),
		]

		fonts_dir = Path('C:/Windows/Fonts')
		for alias, regular_name, bold_name in font_candidates:
			regular_path = fonts_dir / regular_name
			if not regular_path.exists():
				continue
			try:
				regular_alias = f'{alias}-Regular'
				pdfmetrics.registerFont(TTFont(regular_alias, str(regular_path)))

				if bold_name:
					bold_path = fonts_dir / bold_name
					if bold_path.exists():
						bold_alias = f'{alias}-Bold'
						pdfmetrics.registerFont(TTFont(bold_alias, str(bold_path)))
					else:
						bold_alias = regular_alias
				else:
					bold_alias = regular_alias

				self.font_regular = regular_alias
				self.font_bold = bold_alias
				return
			except Exception:
				continue

	def _setup_custom_styles(self) -> None:
		"""Setup custom paragraph styles"""
		self.styles['Normal'].fontName = self.font_regular
		self.styles['Normal'].wordWrap = 'CJK'
		# Cover title style
		self.styles.add(ParagraphStyle(
			name='CoverTitle',
			parent=self.styles['Heading1'],
			fontSize=36,
			textColor=COLOR_PRIMARY,
			alignment=TA_CENTER,
			spaceAfter=12,
			fontName=self.font_bold
		))
		
		# Section header style
		self.styles.add(ParagraphStyle(
			name='SectionHeader',
			parent=self.styles['Heading1'],
			fontSize=14,
			textColor=colors.white,
			backColor=COLOR_PRIMARY,
			alignment=TA_LEFT,
			spaceAfter=12,
			spaceBefore=12,
			leftIndent=10,
			fontName=self.font_bold
		))
		
		# Info box title style
		self.styles.add(ParagraphStyle(
			name='InfoBoxTitle',
			parent=self.styles['Normal'],
			fontSize=12,
			textColor=colors.white,
			alignment=TA_LEFT,
			fontName=self.font_bold
		))

		self.styles.add(ParagraphStyle(
			name='TableKey',
			parent=self.styles['Normal'],
			fontSize=9,
			leading=11,
			fontName=self.font_bold,
			textColor=COLOR_SECONDARY,
			wordWrap='CJK'
		))

		self.styles.add(ParagraphStyle(
			name='TableValue',
			parent=self.styles['Normal'],
			fontSize=9,
			leading=11,
			fontName=self.font_regular,
			textColor=COLOR_SECONDARY,
			wordWrap='CJK'
		))

		self.styles.add(ParagraphStyle(
			name='TableCellSmall',
			parent=self.styles['Normal'],
			fontSize=8,
			leading=10,
			fontName=self.font_regular,
			textColor=COLOR_SECONDARY,
			wordWrap='CJK'
		))

		self.styles.add(ParagraphStyle(
			name='CoverSubTitle',
			parent=self.styles['Normal'],
			fontSize=11,
			fontName=self.font_regular,
			textColor=COLOR_SECONDARY,
			alignment=TA_CENTER
		))

	def __ensure_report_dir(self) -> None:
		if not self.report_dir.exists():
			self.report_dir.mkdir(parents=True, exist_ok=True)

	def _add_page_number(self, canvas_obj: canvas.Canvas, doc) -> None:
		"""Add header and footer to each page"""
		page_num = canvas_obj.getPageNumber()
		
		# Skip cover page
		if page_num == 1:
			return
			
		# Header
		canvas_obj.saveState()
		canvas_obj.setFillColor(COLOR_HEADER_BG)
		canvas_obj.rect(0, A4[1] - 50, A4[0], 50, fill=1, stroke=0)
		canvas_obj.setFillColor(COLOR_PRIMARY)
		canvas_obj.rect(0, A4[1] - 3, A4[0], 3, fill=1, stroke=0)
		
		canvas_obj.setFillColor(COLOR_SECONDARY)
		canvas_obj.setFont(self.font_bold, 12)
		canvas_obj.drawString(20, A4[1] - 30, "流量检测系统")
		
		canvas_obj.setFont(self.font_regular, 9)
		canvas_obj.setFillColor(colors.grey)
		canvas_obj.drawRightString(A4[0] - 20, A4[1] - 30, 
								  f"生成时间: {self.report_date:%Y-%m-%d %H:%M}")
		
		# Footer
		canvas_obj.setStrokeColor(COLOR_BORDER)
		canvas_obj.line(20, 40, A4[0] - 20, 40)
		
		canvas_obj.setFont(self.font_regular, 8)
		canvas_obj.setFillColor(colors.grey)
		canvas_obj.drawString(20, 25, "内部文档 - 请勿外传")
		canvas_obj.drawRightString(A4[0] - 20, 25, f"第 {page_num - 1} 页")
		
		canvas_obj.restoreState()

	def _create_info_table(self, title: str, items: List[Tuple[str, Any]]) -> KeepTogether:
		"""Create a professional info box as a table"""
		# Header row
		data = [[Paragraph(title, self.styles['InfoBoxTitle']), '']]
		# Data rows
		for key, value in items:
			value_text = str(value)
			if 'hash' in str(key).lower() and value_text:
				value_text = '<br/>'.join(
					[value_text[i:i + 16] for i in range(0, len(value_text), 16)]
				)
			data.append([
				Paragraph(str(key), self.styles['TableKey']),
				Paragraph(value_text, self.styles['TableValue'])
			])
		
		table = Table(data, colWidths=[3*inch, 4*inch])
		table.setStyle(TableStyle([
			# Header row
			('BACKGROUND', (0, 0), (-1, 0), COLOR_PRIMARY),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('FONTNAME', (0, 0), (-1, 0), self.font_bold),
			('FONTSIZE', (0, 0), (-1, 0), 12),
			('SPAN', (0, 0), (-1, 0)),
			('ALIGN', (0, 0), (-1, 0), 'LEFT'),
			('LEFTPADDING', (0, 0), (-1, 0), 10),
			('TOPPADDING', (0, 0), (-1, 0), 8),
			('BOTTOMPADDING', (0, 0), (-1, 0), 8),
			
			# Data rows
			('BACKGROUND', (0, 1), (-1, -1), colors.white),
			('FONTNAME', (0, 1), (0, -1), self.font_bold),
			('FONTNAME', (1, 1), (1, -1), self.font_regular),
			('FONTSIZE', (0, 1), (-1, -1), 10),
			('TEXTCOLOR', (0, 1), (-1, -1), COLOR_SECONDARY),
			('ALIGN', (0, 1), (0, -1), 'LEFT'),
			('ALIGN', (1, 1), (1, -1), 'LEFT'),
			('LEFTPADDING', (0, 1), (-1, -1), 10),
			('RIGHTPADDING', (0, 1), (-1, -1), 10),
			('TOPPADDING', (0, 1), (-1, -1), 5),
			('BOTTOMPADDING', (0, 1), (-1, -1), 5),
			
			# Alternating row colors
			('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, COLOR_HEADER_BG]),
			
			# Border
			('BOX', (0, 0), (-1, -1), 1, COLOR_BORDER),
			('LINEBELOW', (0, 0), (-1, 0), 2, COLOR_PRIMARY),
		]))
		
		return KeepTogether(table)

	def _create_dynamic_result_table(self, title: str,
							 rows: List[Dict[str, Any]]) -> Table:
		"""Create a dynamic table where dict keys are columns."""
		if not rows:
			rows = [{"info": "无命中详情"}]

		column_name_map = {
			"rule_file_name": "规则文件",
			"rule_name": "规则名称",
			"description": "描述",
			"category": "分类",
			"malware_type": "恶意类型",
			"security_level": "安全等级",
			"match_value": "命中值",
			"verdict": "判定结果",
			"severity": "危害等级",
			"score": "评分",
			"reasons": "判定原因",
			"indicators": "威胁指标",
			"recommended_actions": "建议操作",
			"raw_output": "原始输出",
			"ai_result": "AI结果",
			"info": "信息",
		}

		columns: List[str] = []
		for row in rows:
			for key in row.keys():
				if key not in columns:
					columns.append(key)

		data: List[List[Any]] = []
		data.append([
			Paragraph(col, ParagraphStyle(
				'DynamicTableHeader',
				parent=self.styles['Normal'],
				fontName=self.font_bold,
				fontSize=9,
				textColor=colors.white,
				wordWrap='CJK'
			)) for col in [column_name_map.get(c, c) for c in columns]
		])

		for row in rows:
			row_cells: List[Any] = []
			for col in columns:
				val = row.get(col, "")
				if isinstance(val, (dict, list)):
					cell_text = json.dumps(val, ensure_ascii=False)
				else:
					cell_text = str(val) if val is not None else ""
				row_cells.append(Paragraph(cell_text, self.styles['TableCellSmall']))
			data.append(row_cells)

		available_width = 7.1 * inch
		col_width = max(1.2 * inch, available_width / max(len(columns), 1))
		table = Table(data, colWidths=[col_width] * len(columns), repeatRows=1)
		table.setStyle(TableStyle([
			('BACKGROUND', (0, 0), (-1, 0), COLOR_SECONDARY),
			('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
			('ALIGN', (0, 0), (-1, -1), 'LEFT'),
			('VALIGN', (0, 0), (-1, -1), 'TOP'),
			('LEFTPADDING', (0, 0), (-1, -1), 6),
			('RIGHTPADDING', (0, 0), (-1, -1), 6),
			('TOPPADDING', (0, 0), (-1, -1), 5),
			('BOTTOMPADDING', (0, 0), (-1, -1), 5),
			('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, COLOR_HEADER_BG]),
			('GRID', (0, 0), (-1, -1), 0.6, COLOR_BORDER),
		]))
		return table

	def _extract_detailed_match_rows(self, result_json: Optional[Any]) -> List[Dict[str, Any]]:
		"""Flatten detailed match results from detection json."""
		if not result_json:
			return []

		result_text = str(result_json)
		try:
			parsed = json.loads(result_text)
		except Exception:
			return [{"raw_result": result_text}]

		if not isinstance(parsed, dict):
			return [{"result": parsed}]

		yara_matches = parsed.get('yara_matches') or parsed.get('matches') or []
		rows: List[Dict[str, Any]] = []

		if isinstance(yara_matches, list):
			for group in yara_matches:
				if not isinstance(group, dict):
					rows.append({"rule_file_name": "unknown", "match": group})
					continue

				rule_file_name = group.get('rule_file_name', 'unknown')
				match_list = group.get('match', [])

				if isinstance(match_list, list) and match_list:
					for item in match_list:
						if isinstance(item, dict):
							rows.append({"rule_file_name": rule_file_name, **item})
						else:
							rows.append({
								"rule_file_name": rule_file_name,
								"match_value": item,
							})
				else:
					rows.append({"rule_file_name": rule_file_name})

		if not rows:
			rows.append({"info": "未找到命中详情"})

		return rows

	def _extract_ai_rows(self, result_json: Optional[Any]) -> List[Dict[str, Any]]:
		"""Extract AI analysis object into single-row table data."""
		if not result_json:
			return []

		result_text = str(result_json)
		try:
			parsed = json.loads(result_text)
		except Exception:
			return []

		if not isinstance(parsed, dict):
			return []

		ai_obj = parsed.get('ai_detection') or parsed.get('ai_detect')
		if ai_obj is None:
			return []

		if isinstance(ai_obj, dict):
			row: Dict[str, Any] = {}
			for key, value in ai_obj.items():
				if isinstance(value, (dict, list)):
					row[key] = json.dumps(value, ensure_ascii=False)
				else:
					row[key] = value
			return [row]

		return [{"ai_result": ai_obj}]

	def _create_pie_chart(self, data: Dict[str, int], title: str) -> Drawing:
		"""Create a professional pie chart"""
		items = [(k, v) for k, v in data.items() if v > 0]
		if not items:
			items = [("No Data", 1)]
		
		drawing = Drawing(400, 300)
		
		# Title
		title_text = String(200, 280, title, textAnchor='middle', 
						   fontSize=14, fillColor=COLOR_SECONDARY, fontName=self.font_bold)
		drawing.add(title_text)
		
		# Pie chart
		pie = Pie()
		pie.x = 100
		pie.y = 50
		pie.width = 200
		pie.height = 200
		pie.data = [v for _, v in items]
		total_value = sum(v for _, v in items) or 1
		pie.labels = [f"{k} ({(v / total_value) * 100:.1f}%)" for k, v in items]
		
		# Professional color palette
		pie.slices.strokeWidth = 1
		pie.slices.strokeColor = colors.white
		color_list = [
			COLOR_PRIMARY, COLOR_ACCENT, COLOR_SUCCESS, COLOR_WARNING,
			COLOR_DANGER, colors.HexColor('#5BC0DE'), colors.HexColor('#9966CC'),
			colors.HexColor('#FF6B9D'), colors.HexColor('#FFA500'), colors.HexColor('#20B2AA'),
		]
		for i, item in enumerate(items):
			pie.slices[i].fillColor = color_list[i % len(color_list)]
		
		pie.slices.fontName = self.font_regular
		pie.slices.fontSize = 8
		pie.slices.labelRadius = 1.2
		pie.sideLabels = True
		
		drawing.add(pie)
		
		return drawing

	def __get_file_size(self, file_path: str) -> str:
		try:
			file_bytes = Path(file_path).stat().st_size
			if file_bytes < 1024:
				return f"{file_bytes} B"
			if file_bytes < 1024 ** 2:
				return f"{file_bytes / 1024:.2f} KB"
			if file_bytes < 1024 ** 3:
				return f"{file_bytes / (1024 ** 2):.2f} MB"
			return f"{file_bytes / (1024 ** 3):.2f} GB"
		except Exception:
			return "0 B"

	def __save_exported_file_info(self, report_name: str,
								 report_path: str) -> None:
		try:
			record = ExportedFileInfo(
				fid=str(uuid.uuid4()),
				name=report_name,
				path=report_path,
				export_date=datetime.now(),
				format='pdf',
				size=self.__get_file_size(report_path),
			)
			self.session.add(record)
			self.session.commit()
		except Exception as e:
			self.session.rollback()
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="save exported report",
				message=f"save exported report failed: {e}"
			)

	def __get_file_info(self, file_id: str) -> Optional[UploadedFileInfo]:
		return (self.session.query(UploadedFileInfo)
				.filter_by(fid=file_id)
				.first())

	def __get_detection_result(self, file_id: str) -> Optional[DetectionResult]:
		return (self.session.query(DetectionResult)
				.filter_by(uploaded_file_fid=file_id)
				.order_by(DetectionResult.detected_at.desc())
				.first())

	def __get_protocol_counts(self, file_id: str) -> Dict[str, int]:
		return {
			"TCP/UDP": self.session.query(TcpUdp)
			.filter_by(uploaded_file_fid=file_id).count(),
			"DNS请求": self.session.query(DnsRequest)
			.filter_by(uploaded_file_fid=file_id).count(),
			"DNS响应": self.session.query(DnsResponse)
			.filter_by(uploaded_file_fid=file_id).count(),
			"HTTP请求": self.session.query(HttpRequest)
			.filter_by(uploaded_file_fid=file_id).count(),
			"HTTP响应": self.session.query(HttpResponse)
			.filter_by(uploaded_file_fid=file_id).count(),
			"ICMP": self.session.query(ICMP)
			.filter_by(uploaded_file_fid=file_id).count(),
			"TLS证书": self.session.query(TLSCertificate)
			.filter_by(uploaded_file_fid=file_id).count(),
		}

	def __get_rule_stats(self) -> Tuple[int, Dict[str, int]]:
		rule_category_rows = (self.session.query(
			YARARule.category,
			func.count(YARARule.id)
		).group_by(YARARule.category).all())
		by_category = {
			(category or "UNKNOWN"): int(count)
			for category, count in rule_category_rows
		}
		total = self.session.query(YARARule).count()
		return total, by_category

	def generate_report(self, file_id: str) -> Optional[str]:
		self.__ensure_report_dir()
		try:
			file_info = self.__get_file_info(file_id)
			if file_info is None:
				return None

			detection = self.__get_detection_result(file_id)
			proto_counts = self.__get_protocol_counts(file_id)
			rule_total, rule_by_category = self.__get_rule_stats()

			report_name = f"report_{file_id}_{self.report_date:%Y%m%d_%H%M%S}.pdf"
			report_path = str(self.report_dir / report_name)

			# Create PDF document
			doc = SimpleDocTemplate(
				report_path,
				pagesize=A4,
				topMargin=60,
				bottomMargin=60,
				leftMargin=40,
				rightMargin=40
			)

			# Story - all content elements
			story = []

			# ========== Cover Page ==========
			story.append(Spacer(1, 2*inch))
			story.append(Paragraph("流量检测", self.styles['CoverTitle']))
			story.append(Paragraph("分析报告", self.styles['CoverTitle']))
			story.append(Spacer(1, 1.5*inch))
			
			cover_info = f"""
			<para align=center fontSize=12 textColor=#333333>
			<b>报告时间:</b> {self.report_date:%Y-%m-%d %H:%M:%S}<br/>
			<b>文件ID:</b> {file_id}<br/>
			<b>文件名:</b> {file_info.name}
			</para>
			"""
			story.append(Paragraph(cover_info, self.styles['Normal']))
			story.append(Spacer(1, 2*inch))
			story.append(Paragraph("流量检测系统 - 专业版", 
								 ParagraphStyle('CoverFooter', parent=self.styles['Normal'],
										  fontSize=10, textColor=colors.grey, alignment=TA_CENTER,
										  fontName=self.font_regular, wordWrap='CJK')))
			story.append(PageBreak())

			# ========== Section 1: File Information ==========
			story.append(Paragraph("1. 文件信息", self.styles['SectionHeader']))
			story.append(Spacer(1, 0.2*inch))
			
			file_items = [
				("文件名", file_info.name),
				("文件哈希(MD5)", file_info.hashcode),
				("文件大小", file_info.size),
				("总包数", str(file_info.total_packets or "N/A")),
				("上传时间", file_info.upload_date.strftime("%Y-%m-%d %H:%M:%S") if file_info.upload_date else "N/A"),
			]
			if detection and detection.detected_at:
				file_items.append(
					("检测时间", detection.detected_at.strftime("%Y-%m-%d %H:%M:%S"))
				)
			
			story.append(self._create_info_table("基础信息", file_items))
			story.append(Spacer(1, 0.3*inch))

			# ========== Section 2: Protocol Statistics ==========
			story.append(Paragraph("2. 协议特征统计", 
								 ParagraphStyle('Section2', parent=self.styles['SectionHeader'], backColor=COLOR_ACCENT)))
			story.append(Spacer(1, 0.2*inch))
			
			proto_items = [(k, str(v)) for k, v in proto_counts.items()]
			story.append(self._create_info_table("协议分布", proto_items))
			story.append(Spacer(1, 0.2*inch))
			
			# Protocol pie chart
			story.append(self._create_pie_chart(proto_counts, "协议分布分析"))
			story.append(Spacer(1, 0.3*inch))

			# ========== Section 3: Rule Statistics ==========
			story.append(Paragraph("3. 规则统计", 
								 ParagraphStyle('Section3', parent=self.styles['SectionHeader'], backColor=COLOR_SUCCESS)))
			story.append(Spacer(1, 0.2*inch))
			
			rule_items = [("规则总数", str(rule_total))]
			for cat, count in rule_by_category.items():
				rule_items.append((cat, str(count)))
			
			story.append(self._create_info_table("规则分类", rule_items))
			story.append(Spacer(1, 0.3*inch))

			# ========== Section 4: Detection Results ==========
			threat_detected = detection and detection.matched_rules_count and detection.matched_rules_count > 0
			section_color = COLOR_DANGER if threat_detected else COLOR_SUCCESS
			
			story.append(Paragraph("4. 检测结果", 
								 ParagraphStyle('Section4', parent=self.styles['SectionHeader'], backColor=section_color)))
			story.append(Spacer(1, 0.2*inch))
			
			if detection:
				result_items = [
					("命中规则数", str(detection.matched_rules_count or 0)),
					("处理耗时", f"{detection.cost_time or 0} 秒"),
					("状态", "检测到威胁" if threat_detected else "未发现威胁"),
				]
				story.append(self._create_info_table("检测摘要", result_items))
				
				# Detailed results table
				if detection.result_json:
					story.append(Spacer(1, 0.2*inch))
					story.append(Paragraph("详细命中结果", 
									 ParagraphStyle('DetailHeader', parent=self.styles['Normal'],
												  fontSize=11, textColor=colors.white, 
												  backColor=COLOR_SECONDARY, leftIndent=10,
												  fontName=self.font_bold, wordWrap='CJK')))
					story.append(Spacer(1, 0.1*inch))

					detailed_rows = self._extract_detailed_match_rows(detection.result_json)
					story.append(self._create_dynamic_result_table("详细命中结果", detailed_rows))

					ai_rows = self._extract_ai_rows(detection.result_json)
					if ai_rows:
						story.append(Spacer(1, 0.2*inch))
						story.append(Paragraph("AI 检测分析", 
									 ParagraphStyle('AIHeader', parent=self.styles['Normal'],
												  fontSize=11, textColor=colors.white, 
												  backColor=COLOR_SECONDARY, leftIndent=10,
												  fontName=self.font_bold, wordWrap='CJK')))
						story.append(Spacer(1, 0.1*inch))
						story.append(self._create_dynamic_result_table("AI 检测分析", ai_rows))
			else:
				story.append(self._create_info_table("检测摘要", [("状态", "尚未执行检测")]))

			# Build PDF with header/footer
			doc.build(story, onFirstPage=lambda c, d: None, 
					 onLaterPages=self._add_page_number)
			
			self.__save_exported_file_info(report_name, report_path)
			return report_path
			
		except Exception as e:
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="generate report",
				message=f"Report generation failed: {e}"
			)
			return None
		finally:
			try:
				self.session.close()
			except Exception:
				pass
