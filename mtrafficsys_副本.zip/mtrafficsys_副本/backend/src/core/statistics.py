from typing import Dict, Any
import re
from sqlalchemy.sql import func

from .logger.log_manager import LogManager
from .storage.mysql_control import MysqlSimClass
from .settings import (
	UploadedFileInfo, TcpUdp, DnsRequest, DnsResponse, HttpRequest,
	HttpResponse, ICMP, TLSCertificate, BlackIP, BlackDomain,
	YARARule
)


class TrafficStatistics:
	def __init__(self) -> None:
		self.logger = LogManager()
		self.logger_name = "TrafficStatistics"
		self.session = MysqlSimClass().get_session()

	def __parse_size_to_bytes(self, size_str: str) -> int:
		"""Parse size like '1.23 MB' into bytes."""
		if not size_str:
			return 0
		m = re.match(r"^\s*([0-9.]+)\s*([KMG]?B)\s*$", size_str, re.I)
		if not m:
			return 0
		value = float(m.group(1))
		unit = m.group(2).upper()
		factor = {
			"B": 1,
			"KB": 1024,
			"MB": 1024 ** 2,
			"GB": 1024 ** 3,
		}.get(unit, 1)
		return int(value * factor)

	def __bytes_to_mb(self, num_bytes: int) -> float:
		return round(num_bytes / (1024 ** 2), 2)

	def get_overview(self) -> Dict[str, Any]:
		"""Return traffic statistics overview."""
		try:
			processed_files = (self.session.query(UploadedFileInfo)
							   .filter_by(is_extracted=True))
			processed_total = processed_files.count()

			total_packets = (self.session.query(
				func.coalesce(func.sum(UploadedFileInfo.total_packets), 0))
				.filter_by(is_extracted=True)
				.scalar())

			size_rows = (self.session.query(UploadedFileInfo.size)
						 .filter_by(is_extracted=True)
						 .all())
			total_bytes = 0
			for (size_str,) in size_rows:
				total_bytes += self.__parse_size_to_bytes(size_str)

			feature_counts = {
				"tcp_udp": self.session.query(TcpUdp).count(),
				"dns_request": self.session.query(DnsRequest).count(),
				"dns_response": self.session.query(DnsResponse).count(),
				"http_request": self.session.query(HttpRequest).count(),
				"http_response": self.session.query(HttpResponse).count(),
				"icmp": self.session.query(ICMP).count(),
				"tls_certificate": self.session.query(TLSCertificate).count(),
			}

			blacklist_counts = {
				"ip_total": self.session.query(BlackIP).count(),
				"domain_total": self.session.query(BlackDomain).count(),
			}

			rule_category_rows = (self.session.query(
				YARARule.category,
				func.count(YARARule.id)
			)
				.group_by(YARARule.category)
				.all())
			rule_counts_by_category = {
				(category or "UNKNOWN"): int(count)
				for category, count in rule_category_rows
			}

			return {
				"files": {
					"processed_total": processed_total,
					"total_size_mb": self.__bytes_to_mb(total_bytes),
				},
				"packets": {
					"total": int(total_packets or 0),
				},
				"features": feature_counts,
				"blacklist": blacklist_counts,
				"rules": {
					"by_category": rule_counts_by_category,
					"total": sum(rule_counts_by_category.values())
				},
			}
		except Exception as e:
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="get overview",
				message=f"Statistics error: {e}"
			)
			return {
				"files": {"processed_total": 0, "total_size_mb": 0},
				"packets": {"total": 0},
				"features": {},
				"blacklist": {"ip_total": 0, "domain_total": 0},
				"rules": {"by_category": {}, "total": 0},
			}
		finally:
			try:
				self.session.close()
			except Exception:
				pass
