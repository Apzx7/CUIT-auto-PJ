import dpkt  # type: ignore
import socket
from io import BufferedReader
from datetime import datetime
from typing import Any, Optional
from collections import defaultdict

from ...logger.log_manager import LogManager  # type: ignore
from ...settings import DNS_TYPE  # type: ignore


class UnifiedFeatureExtractor:
    def __init__(self) -> None:
        self.logger = LogManager()
        self.logger_name = "TrafficFeatureExtractor"
        self.pcap_magic_head = b'\xd4\xc3\xb2\xa1'
        self.pcapng_magic_head = b'\x0a\x0d\x0d\x0a'
        self.root_certs_folder = 'root_certs'

        # state for aggregation across single pass
        self.tcp_conn: Any = defaultdict(lambda: {
            'start_time': None, 'end_time': None, 'total_length': 0,
            'src_ip': None, 'dst_ip': None, 'src_port': None, 'dst_port': None,
        })
        self.udp_conn: Any = defaultdict(lambda: {
            'start_time': None, 'end_time': None, 'total_length': 0,
            'src_ip': None, 'dst_ip': None, 'src_port': None, 'dst_port': None,
        })
        self.tcp_piece: dict[tuple, Any] = {}

        self.features: dict[str, Any] = {
            'dns': {
                'request': [],
                'response': [],
            },
            'http': {
                'request': [],
                'response': [],
            },
            'icmp': [],
            'tcp_udp': [],
            'tls': {
                'certificates': []
            },
            'meta': {
                'total_packets': 0
            }
        }

    def __judge_pcap_file_format(self, reader: BufferedReader) -> Any:
        data = reader.read(4)
        reader.seek(0)
        if data.startswith(self.pcap_magic_head):
            return dpkt.pcap.Reader(reader)
        elif data.startswith(self.pcapng_magic_head):
            return dpkt.pcapng.Reader(reader)
        else:
            return None

    def __format_size(self, size_bytes: float) -> str:
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} TB"

    def __inet_to_str(self, inet: Any) -> str:
        try:
            return socket.inet_ntop(socket.AF_INET, inet)
        except ValueError:
            return socket.inet_ntop(socket.AF_INET6, inet)

    def __get_dns_type(self, dns_type: int) -> str:
        if not str(dns_type) in DNS_TYPE.keys():
            return 'Unknown'
        return DNS_TYPE[str(dns_type)]

    def __parse_http(self, timestamp: float, http_data: bytes) -> Optional[tuple]:
        date = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S')
        try:
            http = dpkt.http.Request(http_data)
            headers = dict(http.headers) if http.headers is not None else {}
            return ('Request', date, http.method, http.uri, headers,
                    headers.get('user-agent', ''), headers.get('referer', ''))
        except dpkt.dpkt.UnpackError:
            try:
                http = dpkt.http.Response(http_data)
                headers = dict(http.headers) if http.headers is not None else {}
                return ('Response', date, http.status, http.reason, headers)
            except dpkt.dpkt.UnpackError:
                return None

    def __append_tls_piece(self, ip: dpkt.ip.IP, tcp: dpkt.tcp.TCP) -> None:
        if len(tcp.data) <= 0:
            return
        src_ip = self.__inet_to_str(ip.src)  # type: ignore
        dst_ip = self.__inet_to_str(ip.dst)  # type: ignore
        src_port = tcp.sport  # type: ignore
        dst_port = tcp.dport  # type: ignore
        ssl_data = tcp.data
        basic_tuple = (src_ip, dst_ip, src_port, dst_port)
        seq = tcp.seq  # type: ignore
        if basic_tuple not in self.tcp_piece:
            self.tcp_piece[basic_tuple] = {}
        self.tcp_piece[basic_tuple][seq] = ssl_data

    def __build_tcp_stream(self) -> dict:
        tcp_piece = self.tcp_piece
        for t4, dic in tcp_piece.items():
            if not dic:
                continue
            seq = min(dic.keys())
            combined = dic[seq]
            piece_len = len(dic[seq])
            while (seq + piece_len) in dic:
                seq = seq + piece_len
                combined += dic[seq]
                piece_len = len(dic[seq])
            tcp_piece[t4] = combined
        return tcp_piece

    def __init_trust_certs(self, certs_folder: str) -> dict:
        from OpenSSL import crypto
        from pathlib import Path

        certs_map: dict[int, Any] = {}
        for file_path in Path(certs_folder).rglob('*'):
            if not file_path.is_file():
                continue
            ext = file_path.suffix
            with file_path.open('rb') as f:
                if ext == '.pem':
                    cert = crypto.load_certificate(crypto.FILETYPE_PEM, f.read())  # noqa
                    certs_map[cert.get_subject().hash()] = cert
                elif ext == '.der':
                    cert = crypto.load_certificate(crypto.FILETYPE_ASN1, f.read())  # noqa
                    certs_map[cert.get_subject().hash()] = cert
        return certs_map

    def __validate_cert_chain(self, certs_folder: str, cert_chain: list) -> bool:
        from OpenSSL import crypto

        try:
            certs_map = self.__init_trust_certs(certs_folder)
            store = crypto.X509Store()
            n = len(cert_chain)
            for i in range(1, n):
                store.add_cert(cert_chain[i])
            root_hash = cert_chain[-1].get_issuer().hash()
            if root_hash not in certs_map:
                return False
            store.add_cert(certs_map[root_hash])
            store_ctx = crypto.X509StoreContext(store, cert_chain[0])
            try:
                store_ctx.verify_certificate()
            except Exception as e:
                self.logger.add_system_log(
                    level="WARNING",
                    logger_name=self.logger_name,
                    action="validate certificate chain",
                    message=f"Certificate chain validation failed: {e}"
                )
                return False
            else:
                return True
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="validate certificate chain",
                message=f"Error validating certificate chain: {e}"
            )
            return False

    def __extract_tls_certificates(self) -> None:
        import struct
        from OpenSSL import crypto
        from cryptography.hazmat.primitives.serialization import PublicFormat, Encoding
        import hashlib

        try:
            streams = self.__build_tcp_stream()
            for t4, ssl_combined in streams.items():
                total_len = len(ssl_combined)
                curpos = 0
                while curpos < total_len:
                    if (total_len - curpos) < 12:
                        break
                    if ssl_combined[curpos] != 0x16:  # Handshake ContentType
                        break
                    handshake_len = struct.unpack('!H', ssl_combined[curpos+3:curpos+5])[0]
                    curpos += 5
                    cur_handshake_len = 0
                    while (cur_handshake_len < handshake_len and curpos < total_len):
                        this_len = struct.unpack('!I', b'\x00' + ssl_combined[curpos+1:curpos+4])[0]
                        cur_handshake_len += this_len + 4
                        if ssl_combined[curpos] == 0x0b:  # Certificate
                            cert_len = struct.unpack('!I', b'\x00' + ssl_combined[curpos+4:curpos+7])[0]
                            curpos += 7
                            sub_cert_len = 0
                            cert_chain = []
                            cert_chain_data = []
                            while sub_cert_len < cert_len:
                                try:
                                    this_sub_len = struct.unpack('!I', b'\x00' + ssl_combined[curpos:curpos+3])[0]
                                except Exception:
                                    break
                                curpos += 3
                                this_sub_cert = ssl_combined[curpos:curpos + this_sub_len]
                                if len(this_sub_cert) != this_sub_len:
                                    break
                                sub_cert_len += this_sub_len + 3
                                curpos += this_sub_len
                                try:
                                    cert = crypto.load_certificate(crypto.FILETYPE_ASN1, this_sub_cert)
                                except Exception:
                                    break
                                CN = cert.get_subject().CN
                                ISSUER_CN = cert.get_issuer().CN
                                signature_algorithm = cert.get_signature_algorithm().decode()
                                pub_key = cert.get_pubkey().to_cryptography_key()
                                if hasattr(pub_key, 'public_bytes'):
                                    public_key = pub_key.public_bytes(encoding=Encoding.PEM, format=PublicFormat.SubjectPublicKeyInfo).hex()  # type: ignore
                                else:
                                    public_key = None
                                md5cert = hashlib.md5(this_sub_cert).hexdigest()
                                cert_chain.append({"CN": CN, "ISSUER_CN": ISSUER_CN,
                                                   'signature_algorithm': signature_algorithm,
                                                   'public_key': public_key,
                                                   "md5": md5cert})
                                cert_chain_data.append(cert)
                            if len(cert_chain_data) > 0:
                                is_valid = self.__validate_cert_chain(self.root_certs_folder, cert_chain_data)
                            else:
                                is_valid = False
                            self.features['tls']['certificates'].append({
                                "src_ip": t4[1], "dst_ip": t4[0],
                                "src_port": t4[3], "dst_port": t4[2],
                                "cert_chain_len": len(cert_chain),
                                "is_valid": is_valid,
                                "cert_chain": cert_chain,
                            })
                        else:
                            curpos += this_len + 4
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="extract TLS certificates",
                message=f"Error extracting TLS certificates: {e}"
            )

    def _process_icmp(self, ts: float, ip: Any) -> bool:
        """Process ICMP packet and append feature if applicable. Return True if handled."""
        if not isinstance(ip.data, dpkt.icmp.ICMP):
            return False
        icmp = ip.data
        date = datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
        src_ip = socket.inet_ntoa(ip.src)
        dst_ip = socket.inet_ntoa(ip.dst)
        size = self.__format_size(float(len(icmp.data)))
        self.features['icmp'].append((date, src_ip, dst_ip, icmp.type, icmp.code, size))  # type: ignore
        return True

    def _process_udp(self, ts: float, ip: Any) -> bool:
        """Process UDP packet, extract DNS if port 53, and aggregate UDP connection. Return True if handled."""
        if not isinstance(ip.data, dpkt.udp.UDP):
            return False
        udp = ip.data
        date = datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
        src_ip = socket.inet_ntoa(ip.src)
        dst_ip = socket.inet_ntoa(ip.dst)

        # DNS extraction
        if udp.dport == 53 or udp.sport == 53:  # type: ignore
            try:
                dns = dpkt.dns.DNS(udp.data)
            except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError):
                dns = None
            if dns:
                if dns.qr == 0:
                    for qname in dns.qd:
                        self.features['dns']['request'].append((
                            'Request', date, src_ip, dst_ip,
                            qname.name, self.__get_dns_type(qname.type), qname.cls
                        ))
                elif dns.qr == 1:
                    for answer in getattr(dns, 'an', []):
                        self.features['dns']['response'].append((
                            'Response', date, src_ip, dst_ip,
                            answer.name, self.__get_dns_type(answer.type),
                            answer.cls, answer.ttl,
                            self.__format_size(len(answer.rdata))
                        ))

        # UDP aggregation
        src_ip_s = self.__inet_to_str(ip.src)  # type: ignore
        dst_ip_s = self.__inet_to_str(ip.dst)  # type: ignore
        conn_key = (src_ip_s, dst_ip_s)
        info = self.udp_conn[conn_key]
        info['src_ip'] = src_ip_s
        info['dst_ip'] = dst_ip_s
        info['src_port'] = udp.sport  # type: ignore
        info['dst_port'] = udp.dport  # type: ignore
        if info['start_time'] is None:
            info['start_time'] = ts
        info['end_time'] = ts
        info['total_length'] += len(udp.data)
        return True

    def _process_tcp(self, ts: float, ip: Any) -> bool:
        """Process TCP packet: parse HTTP, collect TLS pieces, aggregate TCP. Return True if handled."""
        if not isinstance(ip.data, dpkt.tcp.TCP):
            return False
        tcp = ip.data
        # HTTP parse
        parsed = self.__parse_http(ts, tcp.data)
        if parsed:
            if parsed[0] == 'Request':
                self.features['http']['request'].append(parsed)
            else:
                self.features['http']['response'].append(parsed)

        # TLS gather pieces
        self.__append_tls_piece(ip, tcp)

        # TCP aggregation
        src_ip_s = self.__inet_to_str(ip.src)  # type: ignore
        dst_ip_s = self.__inet_to_str(ip.dst)  # type: ignore
        conn_key = (src_ip_s, dst_ip_s)
        info = self.tcp_conn[conn_key]
        info['src_ip'] = src_ip_s
        info['dst_ip'] = dst_ip_s
        info['src_port'] = tcp.sport  # type: ignore
        info['dst_port'] = tcp.dport  # type: ignore
        if info['start_time'] is None or (getattr(tcp, 'flags', 0) & dpkt.tcp.TH_SYN):  # type: ignore
            info['start_time'] = ts
        info['end_time'] = ts
        info['total_length'] += len(tcp.data)
        return True

    def extract_all(self, pcap_file: str) -> dict:
        """
        Single-pass extraction of features for DNS/HTTP/ICMP/TCP/UDP/TLS.
        Returns a dict with protocol-specific lists mirroring existing extractors.
        """
        packet_count = 0
        try:
            with open(pcap_file, 'rb') as f:
                p = self.__judge_pcap_file_format(f)
                if p is None:
                    return self.features
                for ts, buf in p:
                    packet_count += 1
                    try:
                        eth = dpkt.ethernet.Ethernet(buf)
                    except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError):
                        continue
                    if not isinstance(eth.data, dpkt.ip.IP):
                        continue
                    ip: Any = eth.data

                    # ICMP
                    if self._process_icmp(ts, ip):
                        continue

                    # UDP (DNS + aggregation)
                    if self._process_udp(ts, ip):
                        continue

                    # TCP (HTTP/TLS + aggregation)
                    self._process_tcp(ts, ip)

                # after iterating all packets: finalize aggregates
                for conn_key, info in self.tcp_conn.items():
                    if info['src_ip'] is None:
                        continue
                    duration = (info['end_time'] - info['start_time']) if (info['end_time'] and info['start_time']) else 0.0
                    size = self.__format_size(float(info['total_length']))
                    date = datetime.fromtimestamp(info['start_time']).strftime('%Y-%m-%d %H:%M:%S') if info['start_time'] else ''
                    self.features['tcp_udp'].append((
                        date, 'TCP', info['src_ip'], info['dst_ip'],
                        info['src_port'], info['dst_port'], duration, size
                    ))
                for conn_key, info in self.udp_conn.items():
                    if info['src_ip'] is None:
                        continue
                    duration = (info['end_time'] - info['start_time']) if (info['end_time'] and info['start_time']) else 0.0
                    size = self.__format_size(float(info['total_length']))
                    date = datetime.fromtimestamp(info['start_time']).strftime('%Y-%m-%d %H:%M:%S') if info['start_time'] else ''
                    self.features['tcp_udp'].append((
                        date, 'UDP', info['src_ip'], info['dst_ip'],
                        info['src_port'], info['dst_port'], duration, size
                    ))

                # finalize TLS certificates (optional validation omitted for speed)
                self.__extract_tls_certificates()

                self.features['meta']['total_packets'] = packet_count

        except FileNotFoundError:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="extract all features",
                message=f"File not found: {pcap_file}"
            )
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="extract all features",
                message=f"Error reading pcap: {e}"
            )
        return self.features
