import dpkt  # type: ignore
import socket
from io import BufferedReader
# import binascii
from datetime import datetime
from typing import Any, Generator, Optional
from ...logger.log_manager import LogManager  # type: ignore


class IcmpFeatureExtractor():
    def __init__(self) -> None:
        self.logger = LogManager()
        self.logger_name = "TrafficFeatureExtractor"
        self.pcap_magic_head = b'\xd4\xc3\xb2\xa1'
        self.pcapng_magic_head = b'\x0a\x0d\x0d\x0a'

    def __judge_pcap_file_format(self, reader: BufferedReader) -> Any:
        '''
        Judge the pcap file format, pcap or pcapng
        param: reader: file reader
        return: dpkt.pcap.Reader or dpkt.pcapng.Reader
        '''
        # read 4 bytes to judge the pcap file format
        data = reader.read(4)
        # reset the file pointer to the beginning
        reader.seek(0)
        if data.startswith(self.pcap_magic_head):
            return dpkt.pcap.Reader(reader)
        elif data.startswith(self.pcapng_magic_head):
            return dpkt.pcapng.Reader(reader)
        else:
            return None

    def __format_size(self, size_bytes: float) -> str:
        """将字节大小格式化为可读的字符串,使用B、KB、MB等单位"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} TB"

    def __parse_icmp(self, timestamp: float,
                     ip_data: dpkt.ip.IP) -> Optional[tuple]:
        '''
        Parse the ICMP packets from the IP data.
        param: timestamp: packet timestamp
        param: ip_data: IP data
        return: date, src_ip, dst_ip, type, code, data_size
        '''
        if not isinstance(ip_data, dpkt.ip.IP):
            return None

        ip = ip_data

        if not isinstance(ip.data, dpkt.icmp.ICMP):
            return None

        icmp = ip.data
        # extract date --> example format: 2024-04-17 12:35:09
        date = datetime.fromtimestamp(timestamp).strftime(
            '%Y-%m-%d %H:%M:%S')
        # 记录源和目的IP地址
        src_ip = socket.inet_ntoa(ip.src)  # type: ignore
        dst_ip = socket.inet_ntoa(ip.dst)  # type: ignore
        # length of data --> len(icmp.data)
        size = self.__format_size(float(len(icmp.data)))
        return (date, src_ip, dst_ip,
                icmp.type, icmp.code, size)  # type: ignore

    def _extract_icmp_feature(self, pcap_file: str
                              ) -> Generator[tuple, None, None]:
        '''extract ICMP traffic from pcap file'''

        with open(pcap_file, 'rb') as f:
            p = self.__judge_pcap_file_format(f)

            for ts, buf in p:
                try:
                    eth = dpkt.ethernet.Ethernet(buf)
                except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError) as e:
                    self.logger.add_system_log(
                        level="WARNING",
                        logger_name=self.logger_name,
                        action="extract ICMP feature",
                        message=f"Failed to unpack Ethernet frame: {e}"
                    )
                    continue

                if not self.__parse_icmp(ts, eth.data):  # type: ignore
                    continue

                yield self.__parse_icmp(ts, eth.data)  # type: ignore
