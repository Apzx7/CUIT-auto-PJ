import dpkt  # type: ignore
from io import BufferedReader
from ...logger.log_manager import LogManager  # type: ignore
from typing import Any
from OpenSSL import crypto
import struct
import hashlib
import socket
from pathlib import Path
from cryptography.hazmat.primitives.serialization import PublicFormat, Encoding


class TLSHandshakeExtractor():
    def __init__(self):
        self.logger = LogManager()
        self.logger_name = "TrafficFeatureExtractor"
        self.pcap_magic_head = b'\xd4\xc3\xb2\xa1'
        self.pcapng_magic_head = b'\x0a\x0d\x0d\x0a'
        self.root_certs_floder = 'root_certs'
        self.tls_versions = {
            '769': 'TLS v1.0',
            '771': 'TLS v1.2',
            # tls v1.3 also use 771 for compatible tls v1.2s
        }
        self.tls_extension_types = {
            0: 'server_name',
            1: 'max_fragment_length',
            2: 'client_certificate_url',
            3: 'trusted_ca_keys',
            4: 'truncated_hmac',
            5: 'status_request',
            6: 'user_mapping',
            7: 'client_authz',
            8: 'server_authz',
            9: 'cert_type',
            10: 'elliptic_curves',
            11: 'ec_point_formats',
            12: 'srp',
            13: 'signature_algorithms',
            14: 'use_srtp',
            15: 'heartbeat',
            35: 'session_tickets',
            13172: 'next_protocol_negotiation',
            65281: 'renegotiation_info',
        }

    def __judge_pcap_file_format(self, reader: BufferedReader) -> Any:
        '''
        Judge the pcap file format, pcap or pcapng
        param: reader: file reader
        return: dpkt.pcap.Reader or dpkt.pcapng.Reader
        '''
        # read 4 bytes to judge the pcap file format
        data = reader.read(4)
        # reset the file pointer to the beginning
        reader.seek(0)
        if data.startswith(self.pcap_magic_head):
            return dpkt.pcap.Reader(reader)
        elif data.startswith(self.pcapng_magic_head):
            return dpkt.pcapng.Reader(reader)
        else:
            return None

    def __inet_to_str(self, inet: Any) -> str:
        """Convert inet object to a string."""
        try:
            return socket.inet_ntop(socket.AF_INET, inet)
        except ValueError:
            return socket.inet_ntop(socket.AF_INET6, inet)

    def __build_tcp_stream(self, tcp_piece: dict[tuple, Any]) -> dict:
        '''
        Build tcp stream by sequence number
        param: tcp_piece, dict, key is 4-tuple, value is dict,
        key is sequence number, value is tcp.data
        return: dict, key is 4-tuple, value is tcp stream
        '''
        # A->B和B->A是按两个流统计的，所以遍历一边源，就可以遍历到所有情况
        # 根据4元组进行组流
        for t4, dic in tcp_piece.items():
            # 选取最小的sequence number
            seq = min(dic.keys())
            ssl_combined = dic[seq]
            piece_len = len(dic[seq])
            while ((seq + piece_len) in dic):
                seq = seq + piece_len
                # 拼接tcp stream
                ssl_combined += dic[seq]
                piece_len = len(dic[seq])
            # 四元组对应流
            tcp_piece[t4] = ssl_combined
        return tcp_piece

    def __init_trust_certs(self, certs_folder: str) -> dict:
        '''
        Initialize trust certificates
        param: certs_folder, root certificates folder
        return: dict, key is hash, value is certificate
        '''
        certs_map = {}
        for file_path in Path(certs_folder).rglob('*'):
            if file_path.is_file():
                ext = file_path.suffix
                with file_path.open('rb') as f:
                    if ext == '.pem':
                        cert = crypto.load_certificate(crypto.FILETYPE_PEM, f.read())  # noqa
                        certs_map[cert.get_subject().hash()] = cert
                    elif ext == '.der':
                        cert = crypto.load_certificate(crypto.FILETYPE_ASN1, f.read())  # noqa
                        certs_map[cert.get_subject().hash()] = cert
        return certs_map

    def __validate_cert_chain(self, certs_folder: str,
                              cert_chain: list) -> bool:
        '''
        Validate the certificate chain
        param: certs_folder, root certificates folder
        param: cert_chain, certificate chain
        return: bool, True or False
        '''
        try:
            certs_map = self.__init_trust_certs(certs_folder)
            store = crypto.X509Store()
            n = len(cert_chain)
            for i in range(1, n):
                store.add_cert(cert_chain[i])
            root_hash = cert_chain[-1].get_issuer().hash()
            if root_hash not in certs_map:
                return False
            store.add_cert(certs_map[root_hash])
            store_ctx = crypto.X509StoreContext(store, cert_chain[0])
            try:
                store_ctx.verify_certificate()
            except Exception as e:
                self.logger.add_system_log(
                    level="WARNING",
                    logger_name=self.logger_name,
                    action="validate certificate chain",
                    message=f"Certificate chain validation failed: {e}"
                )
                return False
            else:
                return True
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="validate certificate chain",
                message=f"Error validating certificate chain: {e}"
            )
            return False

    def __extract_server_certs(self, tcp_piece: dict[tuple, Any]) -> list:
        '''
        Extract server certificates from the TLS handshake packets
        param: tcp_piece, dict, key is 4-tuple, value is dict,
        key is sequence number, value is tcp.data
        return: a list, all certificates chains
        '''
        all_cert_chains = []
        try:
            for t4, ssl_combined in tcp_piece.items():
                total_len = len(ssl_combined)
                curpos = 0
                while (curpos < total_len):
                    # 如果特别小，直接跳过
                    if (total_len - curpos) < 12:
                        break
                    # Content Type: Handshake
                    if ssl_combined[curpos] != 0x16:
                        break

                    handshake_len = struct.unpack('!H',
                                                  ssl_combined[curpos+3:curpos+5])[0]  # noqa
                    # handshake protocol start
                    curpos += 5
                    cur_handshake_len = 0
                    while (cur_handshake_len < handshake_len and curpos < total_len):  # noqa
                        this_handshake_len = struct.unpack('!I', b'\x00'
                                                         + ssl_combined[curpos+1:curpos+4])[0]  # noqa
                        cur_handshake_len += this_handshake_len + 4
                        # 证书链开始
                        # #如果这一段是证书
                        if ssl_combined[curpos] == 0x0b:
                            cert_len = struct.unpack('!I', b'\x00' +
                                                     ssl_combined[curpos+4:curpos+7])[0]  # noqa
                            # certificates start
                            curpos += 7
                            # 所有子证书的总大小
                            sub_cert_len = 0
                            # 子证书编号，编号形成证书链，越靠下越小
                            sub_cert_count = 1
                            cert_chain = []
                            cert_chain_data = []

                            while (sub_cert_len < cert_len):
                                try:
                                    # 当前子证书大小
                                    this_sub_len = struct.unpack('!I', b'\x00' +  # noqa
                                                                 ssl_combined[curpos:curpos+3])[0]  # noqa
                                except Exception as e:
                                    self.logger.add_system_log(
                                        level="WARNING",
                                        logger_name=self.logger_name,
                                        action="extract server certificates",
                                        message=f"Failed to unpack sub-certificate length: {e}"  # noqa
                                    )
                                    break
                                curpos += 3
                                this_sub_cert = ssl_combined[curpos:curpos + this_sub_len]  # noqa
                                if len(this_sub_cert) != this_sub_len:
                                    # 证书不完整
                                    break
                                # +3是"证书长度"，3个字节
                                sub_cert_len += this_sub_len + 3
                                curpos += this_sub_len
                                # start = time.time()
                                md5cert = hashlib.md5(this_sub_cert).hexdigest()  # noqa
                                # sum += time.time() - start
                                # append追加证书链
                                try:
                                    cert = crypto.load_certificate(crypto.FILETYPE_ASN1,  # noqa
                                                                   this_sub_cert)  # noqa
                                except Exception as e:
                                    # malformed packet
                                    self.logger.add_system_log(
                                        level="WARNING",
                                        logger_name=self.logger_name,
                                        action="extract server certificates",
                                        message=f"Failed to load sub-certificate: {e}"  # noqa
                                    )
                                    break
                                CN = cert.get_subject().CN
                                ISSUER_CN = cert.get_issuer().CN
                                signature_algorithm = cert.get_signature_algorithm().decode()  # noqa
                                pub_key = cert.get_pubkey().to_cryptography_key()  # noqa
                                if hasattr(pub_key, 'public_bytes'):
                                    public_key = pub_key.public_bytes(  # type: ignore
                                        encoding=Encoding.PEM,
                                        format=PublicFormat.SubjectPublicKeyInfo  # noqa
                                    ).hex()
                                else:
                                    public_key = None
                                sub_cert_count += 1
                                cert_chain.append({"CN": CN,
                                                   "ISSUER_CN": ISSUER_CN,
                                                   'signature_algorithm': signature_algorithm,  # noqa
                                                   'public_key': public_key,
                                                   "md5": md5cert})
                                cert_chain_data.append(cert)

                            # 验证证书链，cert_chain[-1]是最靠近根部的证书
                            if len(cert_chain_data) > 0:
                                is_valid = self.__validate_cert_chain(self.root_certs_floder,  # noqa
                                                                      cert_chain_data)  # noqa
                            else:
                                is_valid = False
                            all_cert_chains.append({"src_ip": t4[1], "dst_ip": t4[0],  # noqa
                                                    "src_port": t4[3], "dst_port": t4[2],  # noqa
                                                    "cert_chain_len": len(cert_chain),  # noqa
                                                    "is_valid": is_valid, "cert_chain": cert_chain})  # noqa
                        else:
                            # 不是证书直接跳过
                            curpos += this_handshake_len + 4
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="extract server certificates",
                message=f"Error extracting server certificates: {e}"
            )
        return all_cert_chains

    def _extract_handshake_feature(self, pcap_file: str) -> dict[str, list[dict]]:  # noqa
        """
        Extract TLS handshake packets from a PCAP file.
        param: pcap_file: str
        """
        handshake_features: dict[str, list[dict]] = {
            'certificates': []
        }
        tcp_piece: dict[tuple, Any] = {}
        try:
            with open(pcap_file, 'rb') as f:
                p = self.__judge_pcap_file_format(f)
                if p is None:
                    return handshake_features
                for ts, buf in p:
                    try:
                        eth = dpkt.ethernet.Ethernet(buf)
                        if not isinstance(eth.data, dpkt.ip.IP):
                            continue
                        ip = eth.data
                        if not isinstance(ip.data, dpkt.tcp.TCP):
                            continue
                        tcp = ip.data
                        if len(tcp.data) <= 0:
                            continue
                        src_ip = self.__inet_to_str(ip.src)  # type: ignore
                        dst_ip = self.__inet_to_str(ip.dst)  # type: ignore
                        src_port = tcp.sport  # type: ignore
                        dst_port = tcp.dport  # type: ignore
                        ssl_data = tcp.data
                        basic_tuple = (src_ip, dst_ip, src_port, dst_port)
                        seq = tcp.seq  # type: ignore
                        if basic_tuple not in tcp_piece:
                            tcp_piece[basic_tuple] = {}
                        tcp_piece[basic_tuple][seq] = ssl_data
                    except Exception as e:
                        self.logger.add_system_log(
                            level="WARNING",
                            logger_name=self.logger_name,
                            action="extract TLS handshake feature",
                            message=f"Error processing packet: {e}"
                        )
                        continue
        except FileNotFoundError:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="extract TLS handshake feature",
                message=f"File not found: {pcap_file}"
            )
            return handshake_features
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="extract TLS handshake feature",
                message=f"Error reading pcap file: {e}"
            )
            return handshake_features

        try:
            tcp_stream = self.__build_tcp_stream(tcp_piece)
            all_cert_chains = self.__extract_server_certs(tcp_stream)
            handshake_features['certificates'] = all_cert_chains
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="extract TLS handshake feature",
                message=f"Error extracting handshake features: {e}"
            )

        return handshake_features
