import dpkt  # type: ignore
from io import BufferedReader
from datetime import datetime
from typing import Any, Optional
from ...logger.log_manager import LogManager  # type: ignore


class HttpFeatureExtractor():
    def __init__(self) -> None:
        self.logger = LogManager()
        self.logger_name = "TrafficFeatureExtractor"
        self.pcap_magic_head = b'\xd4\xc3\xb2\xa1'
        self.pcapng_magic_head = b'\x0a\x0d\x0d\x0a'

    def __judge_pcap_file_format(self, reader: BufferedReader) -> Any:
        '''
        Judge the pcap file format, pcap or pcapng
        param: reader: file reader
        return: dpkt.pcap.Reader or dpkt.pcapng.Reader
        '''
        # read 4 bytes to judge the pcap file format
        data = reader.read(4)
        # reset the file pointer to the beginning
        reader.seek(0)
        if data.startswith(self.pcap_magic_head):
            return dpkt.pcap.Reader(reader)
        elif data.startswith(self.pcapng_magic_head):
            return dpkt.pcapng.Reader(reader)
        else:
            return None

    def __parse_http(self, timestamp: float,
                     http_data: bytes) -> Optional[tuple]:
        '''extract some http parse, like method, header, url, body etc'''
        # extract date --> example format: 2024-04-17 12:35:09
        date = datetime.fromtimestamp(timestamp).strftime(
            '%Y-%m-%d %H:%M:%S')
        try:
            http = dpkt.http.Request(http_data)
            # headers is OrderedDict -> convert to dict
            headers = dict(http.headers) if http.headers is not None else {}
            return ('Request', date, http.method, http.uri, headers,
                    headers.get('user-agent', ''), headers.get('referer', ''))
        except dpkt.dpkt.UnpackError:
            try:
                http = dpkt.http.Response(http_data)
                headers = dict(http.headers) if http.headers is not None else {}  # noqa
                return ('Response', date, http.status, http.reason, headers)
            except dpkt.dpkt.UnpackError:
                return None

    def _extract_http_feature(self, pcap_file: str) -> dict[str, list[tuple]]:
        '''
        Extract HTTP traffic features from a pcap file.
        param: pcap_file: pcap file path
        return: dict, include request and response
        '''
        http_datas: dict[str, list[tuple]] = {
            'request': [],
            'response': []
        }
        with open(pcap_file, 'rb') as f:
            p = self.__judge_pcap_file_format(f)

            for ts, buf in p:
                # ignore wrong format packets
                try:
                    eth = dpkt.ethernet.Ethernet(buf)
                except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError):
                    continue
                if isinstance(eth.data, dpkt.ip.IP):
                    ip = eth.data
                    if isinstance(ip.data, dpkt.tcp.TCP):
                        tcp = ip.data
                        # if tcp is not none, continue
                        data = self.__parse_http(ts, tcp.data)
                        if not data:
                            continue
                        if data[0] == 'Request':
                            http_datas['request'].append(data)
                        else:
                            http_datas['response'].append(data)
        return http_datas
