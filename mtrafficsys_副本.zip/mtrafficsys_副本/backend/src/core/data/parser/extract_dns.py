import dpkt  # type: ignore
import socket
from io import BufferedReader
# import binascii
from datetime import datetime
from ...logger.log_manager import LogManager  # type: ignore
from ...settings import DNS_TYPE  # type: ignore
from typing import Any


class DnsFeatureExtractor():
    def __init__(self) -> None:
        self.logger = LogManager()
        self.logger_name = "TrafficFeatureExtractor"
        self.pcap_magic_head = b'\xd4\xc3\xb2\xa1'
        self.pcapng_magic_head = b'\x0a\x0d\x0d\x0a'

    def __judge_pcap_file_format(self, reader: BufferedReader) -> Any:
        '''
        Judge the pcap file format, pcap or pcapng
        param: reader: file reader
        return: dpkt.pcap.Reader or dpkt.pcapng.Reader
        '''
        # read 4 bytes to judge the pcap file format
        data = reader.read(4)
        # reset the file pointer to the beginning
        reader.seek(0)
        if data.startswith(self.pcap_magic_head):
            return dpkt.pcap.Reader(reader)
        elif data.startswith(self.pcapng_magic_head):
            return dpkt.pcapng.Reader(reader)
        else:
            return None

    def __format_size(self, size_bytes: float) -> str:
        """将字节大小格式化为可读的字符串,使用B、KB、MB等单位"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} TB"

    def __get_dns_type(self, dns_type: int) -> str:
        '''get dns type from DNS_TYPE'''
        if not str(dns_type) in DNS_TYPE.keys():
            return 'Unknown'
        return DNS_TYPE[str(dns_type)]

    def _extract_dns_feature(self, pcap_file: str) -> dict[str, list[tuple]]:
        '''
        Extract DNS traffic features from a pcap file.
        param: pcap_file: pcap file path
        return: dict, include request and response
        request: date, src_ip, dst_ip, qname, qtype, qcls
        response: date, src_ip, dst_ip, rname, rtype, rcls, ttl, rdata_size
        '''
        dns_datas: dict[str, list[tuple]] = {
            'request': [],
            'response': []
        }

        with open(pcap_file, 'rb') as f:
            p = self.__judge_pcap_file_format(f)

            for ts, buf in p:
                try:
                    eth = dpkt.ethernet.Ethernet(buf)
                except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError) as e:
                    self.logger.add_system_log(
                        level="WARNING",
                        logger_name=self.logger_name,
                        action="extract DNS feature",
                        message=f"Failed to unpack Ethernet frame: {e}"
                    )
                    continue

                if not isinstance(eth.data, dpkt.ip.IP):
                    continue

                ip: Any = eth.data
                udp = ip.data

                if not isinstance(udp, dpkt.udp.UDP):
                    continue

                # extract date --> example format: 2024-04-17 12:35:09
                date = datetime.fromtimestamp(ts).strftime(
                    '%Y-%m-%d %H:%M:%S')
                # 记录源和目的IP地址
                src_ip = socket.inet_ntoa(ip.src)
                dst_ip = socket.inet_ntoa(ip.dst)

                # 检查端口号是否为53（DNS端口）
                if udp.dport == 53 or udp.sport == 53:  # type: ignore
                    try:
                        dns = dpkt.dns.DNS(udp.data)
                    except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError) as e:
                        self.logger.add_system_log(
                            level="WARNING",
                            logger_name=self.logger_name,
                            action="extract DNS feature",
                            message=f"Failed to unpack DNS packet: {e}"
                        )
                        continue
                else:
                    continue

                # DNS请求(qr == 0)
                if dns.qr == 0:
                    for qname in dns.qd:
                        request = (
                            'Request',
                            date,
                            src_ip,
                            dst_ip,
                            qname.name,
                            self.__get_dns_type(qname.type),
                            qname.cls
                        )
                        dns_datas['request'].append(request)
                elif dns.qr == 1:
                    for answer in dns.an:  # type: ignore
                        response = (
                            'Response',
                            date,
                            src_ip,
                            dst_ip,
                            answer.name,
                            self.__get_dns_type(answer.type),
                            answer.cls,
                            answer.ttl,
                            # length of rdata is len(answer.rdata)
                            self.__format_size(len(answer.rdata))
                            # binascii.hexlify(answer.rdata).decode('utf-8')
                        )
                        dns_datas['response'].append(response)

        return dns_datas
