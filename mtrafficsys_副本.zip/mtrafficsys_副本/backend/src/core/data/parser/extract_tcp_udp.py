import dpkt  # type: ignore
import socket
from io import BufferedReader
# import binascii
from datetime import datetime
from typing import Any, Generator, Optional
from collections import defaultdict
from ...logger.log_manager import LogManager  # type: ignore


class TcpUdpFeatureExtractor():
    def __init__(self) -> None:
        self.logger = LogManager()
        self.logger_name = "TrafficFeatureExtractor"
        self.pcap_magic_head = b'\xd4\xc3\xb2\xa1'
        self.pcapng_magic_head = b'\x0a\x0d\x0d\x0a'

    def __judge_pcap_file_format(self, reader: BufferedReader) -> Any:
        '''
        Judge the pcap file format, pcap or pcapng
        param: reader: file reader
        return: dpkt.pcap.Reader or dpkt.pcapng.Reader
        '''
        # read 4 bytes to judge the pcap file format
        data = reader.read(4)
        # reset the file pointer to the beginning
        reader.seek(0)
        if data.startswith(self.pcap_magic_head):
            return dpkt.pcap.Reader(reader)
        elif data.startswith(self.pcapng_magic_head):
            return dpkt.pcapng.Reader(reader)
        else:
            return None

    def __get_mac_addr(self, address: Any) -> str:
        """Convert a MAC address to a readable/printable string."""
        return ':'.join('%02x' % b for b in address)

    def __inet_to_str(self, inet: Any) -> str:
        """Convert inet object to a string."""
        try:
            return socket.inet_ntop(socket.AF_INET, inet)
        except ValueError:
            return socket.inet_ntop(socket.AF_INET6, inet)

    def __get_raw_payload(self, data: bytes) -> str:
        """Print the raw payload."""
        # for test, just extract 20 bytes for payload
        hex_payload = ' '.join('%02x' % b for b in data[:20])
        return hex_payload

    def __format_size(self, size_bytes: float) -> str:
        """将字节大小格式化为可读的字符串,使用B、KB、MB等单位"""
        for unit in ['B', 'KB', 'MB', 'GB']:
            if size_bytes < 1024.0:
                return f"{size_bytes:.2f} {unit}"
            size_bytes /= 1024.0
        return f"{size_bytes:.2f} TB"

    def __parse_tcp_udp(self, timestamp: float,
                        ip_data: dpkt.ip.IP) -> Optional[tuple]:
        '''
        Parse the TCP and UDP packets from the IP data.
        param: timestamp: packet timestamp
        param: ip_data: IP data
        return: (date, protocol, src_ip, dst_ip, src_port,
        dst_port, duration, size) or none
        '''
        # tcp/udp connect info
        tcp_conn: Any = defaultdict(lambda: {
            'start_time': None, 'end_time': None, 'total_length': 0})
        udp_conn: Any = defaultdict(lambda: {
            'start_time': None, 'end_time': None, 'total_length': 0})
        if not isinstance(ip_data, dpkt.ip.IP):
            return None
        try:
            ip = ip_data
            src_ip = self.__inet_to_str(ip.src)  # type: ignore
            dst_ip = self.__inet_to_str(ip.dst)  # type: ignore
            # extract date --> example format: 2024-04-17 12:35:09
            date = datetime.fromtimestamp(timestamp).strftime(
                '%Y-%m-%d %H:%M:%S')
            # 使用源和目的IP作为连接的唯一标识
            conn_key = (src_ip, dst_ip)

            # 解析 TCP 和 UDP 数据包
            if isinstance(ip.data, dpkt.tcp.TCP):
                tcp = ip.data
                src_port = tcp.sport  # type: ignore
                dst_port = tcp.dport  # type: ignore

                # 更新TCP连接的信息
                if dst_port in [53]:  # 如果是DNS流量
                    return None
                # TCP连接开始
                if tcp.flags & dpkt.tcp.TH_SYN:  # type: ignore
                    if tcp_conn[conn_key]['start_time'] is None:
                        tcp_conn[conn_key]['start_time'] = timestamp  # noqa E501

                # 更新连接结束时间和总载荷长度
                tcp_conn[conn_key]['end_time'] = timestamp
                tcp_conn[conn_key]['total_length'] += len(tcp.data)  # noqa E501
                # get lenth of payload
                lenth = tcp_conn[conn_key]['total_length']
                # get lenth size(KB etc)
                size = self.__format_size(float(lenth))
                # get duration of connection
                # if both of start_time and end_time are not none
                if tcp_conn[conn_key]['end_time'] and tcp_conn[conn_key]['start_time']:  # noqa E501
                    duration = tcp_conn[conn_key]['end_time'] - \
                        tcp_conn[conn_key]['start_time']
                else:
                    duration = 0.0
                # get payload
                # payload = self.__get_raw_payload(tcp.data)
                # payload=payload
                return date, 'TCP', src_ip, dst_ip, src_port, dst_port, duration, size  # noqa E501

            elif isinstance(ip.data, dpkt.udp.UDP):
                udp = ip.data
                src_port = udp.sport  # type: ignore
                dst_port = udp.dport  # type: ignore
                # 更新UDP连接的信息
                udp_conn[conn_key]['total_length'] += len(udp.data)
                # 记录连接开始时间
                if udp_conn[conn_key]['start_time'] is None:
                    udp_conn[conn_key]['start_time'] = timestamp
                # 更新结束时间
                udp_conn[conn_key]['end_time'] = timestamp
                # get lenth of payload
                lenth = udp_conn[conn_key]['total_length']
                # get lenth size(KB etc)
                size = self.__format_size(float(lenth))
                # get duration of connection
                duration = udp_conn[conn_key]['end_time'] - \
                    udp_conn[conn_key]['start_time']
                # get payload
                # payload = self.__get_raw_payload(udp.data)
                return date, 'UDP', src_ip, dst_ip, src_port, dst_port, duration, size  # noqa E501
            else:
                return None
        except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError):
            return None

    def _extract_tcp_udp_feature(self, pcap_file: str
                                 ) -> Generator[tuple, None, None]:
        """
        Extract TCP and UDP traffic features from a pcap file.
        param: pcap_file: pcap file path
        return: Generator[TcpUdp], include date, protocol, src_ip, dst_ip,
        src_port, dst_port, duration, payload_size
        """
        with open(pcap_file, 'rb') as f:
            p = self.__judge_pcap_file_format(f)
            for timestamp, buf in p:
                # ignore wrong format packets
                try:
                    eth = dpkt.ethernet.Ethernet(buf)
                except (dpkt.dpkt.NeedData, dpkt.dpkt.UnpackError):
                    continue

                eth = dpkt.ethernet.Ethernet(buf)

                # 提取源 MAC 和目标 MAC 地址
                # src_mac = self._get_mac_addr(eth.src)
                # dst_mac = self._get_mac_addr(eth.dst)
                if not self.__parse_tcp_udp(timestamp,
                                            eth.data):  # type: ignore
                    continue
                yield self.__parse_tcp_udp(timestamp, eth.data)  # type: ignore
