import json
from ...storage.mysql_control import MysqlSimClass
from typing import Generator, Any
from ...decorators import timing_decorator
from ...settings import DnsRequest, DnsResponse, TcpUdp, \
    HttpRequest, HttpResponse, ICMP, TLSCertificate, UploadedFileInfo
from ...logger.log_manager import LogManager
from ..parser.unified_extractor import UnifiedFeatureExtractor


class FeatureSaver:
    def __init__(self, pcap_file_path: str, uploaded_file_fid: str,
                 batch_size: int = 50000) -> None:
        self.g_logger = LogManager()
        self.logger_name = "InsertPcapTraffic"
        self.pcap_file = pcap_file_path
        self.uploaded_file_fid = uploaded_file_fid
        self.batch_size = batch_size

        # 初始化数据库会话（优化配置）
        mysql_sim = MysqlSimClass()
        self.session = mysql_sim.get_session()

        # 优化会话配置：关闭自动刷新，提高批量插入性能
        self.session.autoflush = False
        self.session.expire_on_commit = False

        # 初始化统一特征提取器
        self.unified_extractor = UnifiedFeatureExtractor()
        self._features_cache: dict[str, Any] | None = None

        self.dns_qname_max_len = 100
        self.dns_rname_max_len = 100

    def __get_features(self) -> dict[str, Any]:
        if self._features_cache is None:
            self._features_cache = self.unified_extractor.extract_all(self.pcap_file)
        return self._features_cache
    
    def __update_total_packets(self, total_packets: int) -> None:
        """更新 UploadedFileInfo 表中的 total_packets 字段"""
        record = (self.session.query(UploadedFileInfo)
                  .filter_by(fid=self.uploaded_file_fid).first())
        if record is not None:
            record.total_packets = total_packets
            self.session.commit()

    # 优化数据生成方法 - 预处理 JSON
    def __data2tcp_udp(self) -> Generator[dict, None, None]:
        """返回字典而不是 ORM 对象，提高性能"""
        datas = self.__get_features().get('tcp_udp', [])
        for tup in datas:
            yield {
                'uploaded_file_fid': self.uploaded_file_fid,
                'date': tup[0],
                'protocol': tup[1],
                'src_ip': tup[2],
                'dst_ip': tup[3],
                'src_port': tup[4],
                'dst_port': tup[5],
                'duration': tup[6],
                'payload_size': tup[7]
            }

    def __data2dns_request(self) -> Generator[dict, None, None]:
        datas = self.__get_features().get('dns', {}).get('request', [])
        for d in datas:
            qname = d[4] if len(d[4]) <= self.dns_qname_max_len else 'qname too long'  # noqa
            yield {
                'uploaded_file_fid': self.uploaded_file_fid,
                'type': d[0],
                'date': d[1],
                'src_ip': d[2],
                'dst_ip': d[3],
                'qname': qname,
                'qtype': d[5],
                'qcls': d[6]
            }

    def __data2dns_response(self) -> Generator[dict, None, None]:
        datas = self.__get_features().get('dns', {}).get('response', [])
        for d in datas:
            rname = d[4] if len(d[4]) <= self.dns_rname_max_len else 'rname too long'  # noqa
            yield {
                'uploaded_file_fid': self.uploaded_file_fid,
                'type': d[0],
                'date': d[1],
                'src_ip': d[2],
                'dst_ip': d[3],
                'rname': rname,
                'rtype': d[5],
                'rcls': d[6],
                'ttl': d[7],
                'rdata_size': d[8]
            }

    def __data2http_request(self) -> Generator[dict, None, None]:
        datas = self.__get_features().get('http', {}).get('request', [])
        for d in datas:
            headers_json = json.dumps(d[4], ensure_ascii=False) if d[4] else None  # noqa
            yield {
                'uploaded_file_fid': self.uploaded_file_fid,
                'type': d[0],
                'date': d[1],
                'method': d[2],
                'uri': d[3],
                'headers': headers_json,
                'user_agent': d[5],
                'referer': d[6]
            }

    def __data2http_response(self) -> Generator[dict, None, None]:
        datas = self.__get_features().get('http', {}).get('response', [])
        for d in datas:
            headers_json = json.dumps(d[4], ensure_ascii=False) if d[4] else None  # noqa
            yield {
                'uploaded_file_fid': self.uploaded_file_fid,
                'type': d[0],
                'date': d[1],
                'status_code': d[2],
                'status_reason': d[3],
                'headers': headers_json
            }

    def __data2icmp(self) -> Generator[dict, None, None]:
        datas = self.__get_features().get('icmp', [])
        for d in datas:
            yield {
                'uploaded_file_fid': self.uploaded_file_fid,
                'date': d[0],
                'src_ip': d[1],
                'dst_ip': d[2],
                'type': d[3],
                'code': d[4],
                'data_size': d[5]
            }

    def __data2tls_certificate(self) -> Generator[dict, None, None]:
        datas = self.__get_features().get('tls', {}).get('certificates', [])
        for d in datas:
            cert_chain_json = json.dumps(d['cert_chain']) if d['cert_chain'] else None  # noqa
            yield {
                'uploaded_file_fid': self.uploaded_file_fid,
                'src_ip': d['src_ip'],
                'dst_ip': d['dst_ip'],
                'src_port': d['src_port'],
                'dst_port': d['dst_port'],
                'cert_chain_len': d['cert_chain_len'],
                'is_valid': d['is_valid'],
                'cert_chain': cert_chain_json
            }

    @timing_decorator
    def insert_traffic(self) -> int:
        """
        优化后的流量插入方法
        """
        inserted_count = 0
        try:
            features = self.__get_features()
            total_packets = (features.get('meta', {})
                             .get('total_packets', 0))

            self.__update_total_packets(total_packets)

            # 分别处理每种协议类型，使用优化的批量插入
            protocols_data = [
                (self.__data2tcp_udp(), TcpUdp, "TCP/UDP"),
                (self.__data2dns_request(), DnsRequest, "DNS Request"),
                (self.__data2dns_response(), DnsResponse, "DNS Response"),
                (self.__data2http_request(), HttpRequest, "HTTP Request"),
                (self.__data2http_response(), HttpResponse, "HTTP Response"),
                (self.__data2icmp(), ICMP, "ICMP"),
                (self.__data2tls_certificate(), TLSCertificate,
                 "TLS Certificate")
            ]

            for data_gen, model_class, protocol_name in protocols_data:
                count = self.__bulk_insert_optimized_dict(data_gen,
                                                          model_class)
                inserted_count += count
                self.g_logger.add_system_log(
                    level="INFO",
                    logger_name=self.logger_name,
                    action=f"insert_{protocol_name.lower().replace('/', '_')}",
                    message=f"Inserted {count} {protocol_name} records"
                )

            # 最终提交
            self.session.commit()

            self.g_logger.add_system_log(
                level="INFO",
                logger_name=self.logger_name,
                action="insert_traffic",
                message=f"Successfully inserted {inserted_count} total records for {self.pcap_file}"  # noqa
            )

            return inserted_count

        except Exception as e:
            self.g_logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="insert_traffic",
                message=f"Insert failed: {str(e)}"
            )
            try:
                self.session.rollback()
            except Exception:
                pass
            return 0
        finally:
            try:
                self.session.close()
            except Exception:
                pass

    def __bulk_insert_optimized_dict(self,
                                     data_generator: Generator[dict, None, None],  # noqa
                                     model_class,
                                     batch_size: int = 0) -> int:
        """
        直接使用字典的批量插入方法（最高性能）
        """
        if batch_size == 0:
            batch_size = self.batch_size

        count = 0
        batch = []
        commit_interval = batch_size * 10  # 每10个批次提交一次

        try:
            for data_dict in data_generator:
                batch.append(data_dict)
                if len(batch) >= batch_size:
                    self.session.bulk_insert_mappings(model_class, batch)
                    count += len(batch)
                    batch.clear()
                    # 定期提交，避免内存溢出和长事务
                    if count >= commit_interval:
                        self.session.commit()
                        # 重新开始新事务
                        batch = []

            # 处理剩余数据
            if batch:
                self.session.bulk_insert_mappings(model_class, batch)
                count += len(batch)

            return count

        except Exception as e:
            self.g_logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action=f"bulk_insert_dict_{model_class.__name__}",
                message=f"Dict bulk insert failed: {str(e)}"
            )
            raise
