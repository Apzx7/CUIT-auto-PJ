from ...storage.mysql_control import MysqlSimClass
from ...settings import UploadedFileInfo, Base
from ...logger.log_manager import LogManager
from typing import Optional


class SaveUploadFile():
    def __init__(self):
        # 创建数据库引擎 & 会话
        self.engine = MysqlSimClass().get_engine()
        self.session = MysqlSimClass().get_session()
        self.logger = LogManager()
        self.logger_name = "UploadFileInfoManage"

    def save_file_info(self, fid: str, fname: str, rname: str, fpath: str,
                       udate: str, hashcode: str, fsize: str) -> Optional[int]:
        '''
        save file info to mysql using ORM UploadedFileInfo
        param: file_path: absolute or relative file path
        return: inserted record id or None on failure
        '''
        try:
            record = UploadedFileInfo(
                fid=fid,
                name=fname,
                rename=rname,
                path=fpath,
                upload_date=udate,
                hashcode=hashcode,
                size=fsize
            )
            self.session.add(record)
            self.session.commit()
            # refresh to get generated id
            self.session.refresh(record)
            return getattr(record, "id", None)
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="save file info",
                message=f"Error occurred while saving file info: {e}"
            )
            try:
                self.session.rollback()
            except Exception:
                pass
            return None
