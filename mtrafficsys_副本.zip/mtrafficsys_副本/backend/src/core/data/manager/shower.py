from ...storage.mysql_control import MysqlSimClass
from ...settings import UploadedFileInfo
from ...logger.log_manager import LogManager
from typing import Optional, List, Any
from datetime import datetime
from sqlalchemy import and_  # type: ignore


class ShowUploadFile():
    def __init__(self):
        # 创建数据库引擎 & 会话
        self.engine = MysqlSimClass().get_engine()
        self.session = MysqlSimClass().get_session()
        self.logger = LogManager()
        self.logger_name = "UploadFileInfoManage"

    def get_all_records(self) -> Optional[List[dict]]:
        '''get all record from UploadedFileInfo table
        '''
        try:
            records = self.session.query(UploadedFileInfo).all()

            return [
                {
                    "fid": r.fid,
                    "name": r.name,
                    "upload_date": r.upload_date,
                    "hashcode": r.hashcode,
                    "size": r.size,
                    "is_extracted": r.is_extracted,
                    "is_detected": r.is_detected,
                    "extracted_at": r.extracted_at,
                    "detected_at": r.detected_at,
                    "total_packets": r.total_packets,
                }
                for r in records
            ]
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="get all uploaded file records",
                message=f"Error occurred while retrieving uploaded file records: {e}"  # noqa
            )
            return None

    def _get_file_name_by_fid(self, fid: str) -> Optional[str]:
        '''
        get file name by file id
        return: file name or None
        '''
        if fid is None:
            return None
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                return record.name
            return None
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="get file name by fid",
                message=f"Error occurred while retrieving file name: {e}"
            )
            return None

    def _get_file_path_by_fid(self, fid: str) -> Optional[str]:
        '''
        get file path by file id
        return: file path or None
        '''
        if fid is None:
            return None
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                return record.path
            return None
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="get file path by fid",
                message=f"Error occurred while retrieving file path: {e}"
            )
            return None

    def _get_file_record_by_fid(self, fid: str) -> Optional[UploadedFileInfo]:
        '''
        get UploadedFileInfo object by file id
        return: UploadedFileInfo object or None
        '''
        if fid is None:
            return None
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            return record
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="get file record by fid",
                message=f"Error occurred while retrieving file record: {e}"
            )
            return None

    def _update_file_is_extracted(self, fid: str) -> bool:
        '''
        update file record is_extracted to True by file id
        return: True on success, False on failure
        '''
        if fid is None:
            return False
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                record.is_extracted = True
                self.session.commit()
                self.session.refresh(record)
                return True
            return False
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="update file is_extracted",
                message=f"Error occurred while updating is_extracted: {e}"
            )
            try:
                self.session.rollback()
            except Exception:
                pass
            return False

    def _update_file_is_detected(self, fid: str) -> bool:
        '''
        update file record is_detected to True by file id
        return: True on success, False on failure
        '''
        if fid is None:
            return False
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                record.is_detected = True
                self.session.commit()
                self.session.refresh(record)
                return True
            return False
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="update file is_detected",
                message=f"Error occurred while updating is_detected: {e}"
            )
            try:
                self.session.rollback()
            except Exception:
                pass
            return False

    def _update_file_extracted_at(self, fid: str, extracted_at: str) -> bool:
        '''
        update file record extracted_at timestamp by file id
        return: True on success, False on failure
        '''
        if fid is None:
            return False
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                record.extracted_at = extracted_at
                self.session.commit()
                # refresh to get updated data
                self.session.refresh(record)
                return True
            return False
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="update file extracted_at",
                message=f"Error occurred while updating extracted_at: {e}"
            )
            try:
                self.session.rollback()
            except Exception:
                pass
            return False

    def _update_file_detected_at(self, fid: str, detected_at: str) -> bool:
        '''
        update file record detected_at timestamp by file id
        return: True on success, False on failure
        '''
        if fid is None:
            return False
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                record.detected_at = detected_at
                self.session.commit()
                # refresh to get updated values
                self.session.refresh(record)
                return True
            return False
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="update file detected_at",
                message=f"Error occurred while updating detected_at: {e}"
            )
            try:
                self.session.rollback()
            except Exception:
                pass
            return False

    def _check_file_is_extracted(self, fid: str) -> bool:
        '''
        check if file is extracted by file id
        return: True if extracted, False otherwise
        '''
        if fid is None:
            return False
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                return getattr(record, "is_extracted", False)
            return False
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="check file is_extracted",
                message=f"Error occurred while checking is_extracted: {e}"
            )
            return False

    def _check_file_is_detected(self, fid: str) -> bool:
        '''
        check if file is detected by file id
        return: True if detected, False otherwise
        '''
        if fid is None:
            return False
        try:
            record = self.session.query(UploadedFileInfo).filter(UploadedFileInfo.fid == fid).first()  # noqa
            if record:
                return getattr(record, "is_detected", False)
            return False
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="check file is_detected",
                message=f"Error occurred while checking is_detected: {e}"
            )
            return False
        
    def _get_file_info_by_name_and_time(self, fname: Optional[str] = None,
                                        start_time: Optional[str] = None,
                                        end_time: Optional[str] = None) -> Optional[List[dict]]:
        '''
        get file records by filename and upload time range
        return: list of UploadedFileInfo objects or None
        '''
        try:
            q = self.session.query(UploadedFileInfo)
            conds: List[Any] = []
            if fname:
                conds.append(UploadedFileInfo.name.like(f"%{fname}%"))
            if start_time:
                t = start_time if isinstance(start_time, datetime) else datetime.fromisoformat(start_time)  # noqa
                conds.append(UploadedFileInfo.upload_date >= t)
            if end_time:
                t = end_time if isinstance(end_time, datetime) else datetime.fromisoformat(end_time)  # noqa
                conds.append(UploadedFileInfo.upload_date <= t)
            if conds:
                q = q.filter(and_(*conds))

            records = q.all()
            return [
                {
                    "fid": r.fid,
                    "name": r.name,
                    "upload_date": r.upload_date,
                    "hashcode": r.hashcode,
                    "size": r.size,
                    "is_extracted": r.is_extracted,
                    "is_detected": r.is_detected,
                    "extracted_at": r.extracted_at,
                    "detected_at": r.detected_at,
                    "total_packets": r.total_packets,
                }
                for r in records
            ]
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="get file info by name and time",
                message=f"Error occurred while retrieving file info: {e}"
            )
            return None