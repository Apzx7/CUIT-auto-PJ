import os
from typing import Optional

from ...storage.mysql_control import MysqlSimClass
from ...logger.log_manager import LogManager
from ...settings import (
	UploadedFileInfo, DetectionResult, TcpUdp, DnsRequest, DnsResponse,
	HttpRequest, HttpResponse, ICMP, TLSCertificate
)


class DeleteUploadFile:
	def __init__(self) -> None:
		self.engine = MysqlSimClass().get_engine()
		self.session = MysqlSimClass().get_session()
		self.logger = LogManager()
		self.logger_name = "UploadFileInfoManage"

	def delete_record_by_fid(self, fid: Optional[str]) -> bool:
		if not fid:
			return False
		try:
			record = self.session.query(UploadedFileInfo).filter_by(fid=fid).first()
			if not record:
				return False

			file_path = record.path
			if file_path and os.path.exists(file_path):
				try:
					os.remove(file_path)
				except Exception as e:
					self.logger.add_system_log(
						level="ERROR",
						logger_name=self.logger_name,
						action="delete uploaded file from disk",
						message=f"Failed to delete file {file_path}: {e}"
					)
					return False

			self.session.query(TcpUdp).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.query(DnsRequest).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.query(DnsResponse).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.query(HttpRequest).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.query(HttpResponse).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.query(ICMP).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.query(TLSCertificate).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.query(DetectionResult).filter_by(uploaded_file_fid=fid).delete(synchronize_session=False)
			self.session.delete(record)
			self.session.commit()
			return True
		except Exception as e:
			self.logger.add_system_log(
				level="ERROR",
				logger_name=self.logger_name,
				action="delete uploaded file record",
				message=f"Error occurred while deleting file record: {e}"
			)
			try:
				self.session.rollback()
			except Exception:
				pass
			return False
