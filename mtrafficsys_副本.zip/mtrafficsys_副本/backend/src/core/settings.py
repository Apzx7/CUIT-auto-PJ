from typing import Union
from .conf.load import YamlLoader
from sqlalchemy import (Column, DateTime, String, Integer, Float,
                        TEXT, Boolean, ForeignKey)
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy.sql import func
import time


conf_class = YamlLoader()

# mysql config
MYSQL_CONF: dict[str, Union[str, int]] = {}
if conf_class.get_mysql_conf() is None:
    raise ValueError("MySQL configuration is missing or invalid.")
for d in conf_class.get_mysql_conf():  # type: ignore
    # d is a dict
    MYSQL_CONF = {**MYSQL_CONF, **d}

MYSQL_URL = f"mysql+pymysql://{MYSQL_CONF['user']}:{MYSQL_CONF['passwd']}@{MYSQL_CONF['host']}:{MYSQL_CONF['port']}/{MYSQL_CONF['db']}"  # noqa E501
# mysql table name
TABLES = {
    'uploaded_file_info': 'UPLOADED_FILE_INFO',
    'detection_result': 'DETECTION_RESULT',
    'extract_tcp_udp': 'TCP_UDP_TRAFFIC',
    'extract_dns_request': 'DNS_REQUEST_TRAFFIC',
    'extract_dns_response': 'DNS_RESPONSE_TRAFFIC',
    'extract_http_request': 'HTTP_REQUEST_TRAFFIC',
    'extract_http_response': 'HTTP_RESPONSE_TRAFFIC',
    'extract_icmp': 'ICMP_TRAFFIC',
    'extract_tls_certificate': 'TLS_CERTIFICATE',
    'black_list_ip': 'BLACKLIST_IP',
    'black_list_domain': 'BLACKLIST_DOMAIN',
    'yara_rules_file': 'YARA_RULES_FILE',
    'system_status': 'SYSTEM_STATUS',
    'system_log': 'SYSTEM_LOG',
    'business_log': 'BUSINESS_LOG',
    'exported_file_info': 'EXPORTED_FILE_INFO',
}

# default export directory(csv, xlsx)
EXPORT_DIRECTORY = 'result/export/'
# default report directory(pdf)
REPORT_DIRECTORY = 'result/report/'

# logger start tag
START_BANNER = ('\n' + '-' * 70 + '\n' +
                f"\n\tStarted At {time.ctime()}  "
                + "@Author: d1k3siy @mail: 2098415680@qq.com"
                + '\n\n' + '-' * 70 + '\n')

# define dns type
DNS_TYPE = {
    '1': "A",  # IPv4地址记录
    '2': "NS",  # 指定域名服务器
    '5': "CNAME",  # 别名记录
    '6': "SOA",  # 主域名服务器信息
    '12': "PTR",  # 指向记录，用于反向DNS查询
    '15': "MX",  # 邮件交换记录
    '16': "TXT",  # 文本记录，用于存储文本信息
    '28': "AAAA",  # IPv6地址记录
    '257': "CAA",  # 证书颁发机构授权记录
    '33': "SRV",  # 服务定位器记录
    '39': "DNAME",  # 域名别名记录
    '43': "DS",  # 委托签名者记录
    '44': "SSHFP",  # SSH公钥指纹记录
    '46': "RRSIG",  # 资源记录签名
    '47': "NSEC",  # 下一个安全记录
    '50': "NSEC3",  # 下一个安全记录（版本3）
    '51': "NSEC3PARAM",  # NSEC3参数记录
    '52': "TLSA",  # TLS证书关联记录
    '55': "HIP",  # 主机身份协议记录
    '64': "SVCB",  # 服务绑定记录
    '65': "HTTPS",  # HTTPS服务绑定记录
    '256': "URI",  # 统一资源标识符记录
    '258': "AVC",  # 应用版本控制记录
    '259': "AMTRELAY",  # AMT中继记录
    '260': "TA",  # 信任锚记录
    '261': "DLV",  # DNSSEC查找验证记录
    '32768': "TA",  # 信任锚记录（私有扩展）
    '32769': "DLV"  # DNSSEC查找验证记录（私有扩展）
}


# 定义数据库模型基类
Base = declarative_base()


# define uploaded file info class
class UploadedFileInfo(Base):  # type: ignore
    __tablename__ = TABLES['uploaded_file_info']

    # define column name
    id = Column(Integer, primary_key=True)
    # uuid
    fid = Column(String(36), unique=True, index=True, nullable=False)
    name = Column(String(100))  # 原始文件名
    rename = Column(String(100))  # 重命名后的文件名
    path = Column(String(200))  # 文件存储路径
    upload_date = Column(DateTime, default=func.now())  # 上传时间
    hashcode = Column(String(64), index=True)  # 文件哈希
    size = Column(String(20))  # 文件大小
    is_extracted = Column(Boolean, default=False)  # 是否已提取流量
    is_detected = Column(Boolean, default=False)  # 是否已检测

    # 新增便于追踪的字段
    extracted_at = Column(DateTime, nullable=True)  # 提取完成时间
    detected_at = Column(DateTime, nullable=True)  # 检测完成时间
    total_packets = Column(Integer, default=0)  # 总数据包数

    # 反向关系
    detection_history = relationship('DetectionResult',
                                     back_populates="uploaded_file",
                                     cascade="all, delete-orphan")


# 定义检测结果表
class DetectionResult(Base):  # type: ignore
    __tablename__ = TABLES['detection_result']

    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),  # noqa
                               nullable=False)
    detected_at = Column(DateTime, default=func.now())  # 检测时间
    cost_time = Column(Float)  # 检测耗时（秒）
    matched_rules_count = Column(Integer)  # 匹配的规则数量
    result_json = Column(TEXT)  # 详细结果JSON

    # 反向关系
    uploaded_file = relationship('UploadedFileInfo',
                                 back_populates="detection_history")


# define extract TCP and UDP traffic class
class TcpUdp(Base):  # type: ignore
    __tablename__ = TABLES['extract_tcp_udp']

    # define column name
    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),
                               index=True, nullable=False)
    date = Column(DateTime)
    protocol = Column(String(3))
    src_ip = Column(String(45))
    dst_ip = Column(String(45))
    # port: 0~65535
    src_port = Column(String(5))
    dst_port = Column(String(5))
    duration = Column(Float)
    payload_size = Column(String(10))


# define extract DNS protocol class(from client)
class DnsRequest(Base):  # type: ignore
    __tablename__ = TABLES['extract_dns_request']

    #  define column name
    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),
                               index=True, nullable=False)
    type = Column(String(10))
    date = Column(DateTime)
    # include ipv4 and ipv6
    src_ip = Column(String(45))
    dst_ip = Column(String(45))
    # client send query to dns server
    qname = Column(String(255))
    # query type(look 'DNS_TYPE')
    qtype = Column(String(10))
    qcls = Column(Integer)


# define extract DNS protocol class(from server)
class DnsResponse(Base):  # type: ignore
    __tablename__ = TABLES['extract_dns_response']

    #  define column name
    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),
                               index=True, nullable=False)
    type = Column(String(10))
    date = Column(DateTime)
    # ipv4 max is 16
    src_ip = Column(String(45))
    dst_ip = Column(String(45))
    # dns serve domain
    rname = Column(String(255))
    # query type(look 'DNS_TYPE')
    rtype = Column(String(10))
    rcls = Column(Integer)
    ttl = Column(Integer)
    rdata_size = Column(String(10))


# define extract ICMP protocol class
class ICMP(Base):  # type: ignore
    __tablename__ = TABLES['extract_icmp']

    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),
                               index=True, nullable=False)
    date = Column(DateTime)
    src_ip = Column(String(45))
    dst_ip = Column(String(45))
    type = Column(Integer)
    code = Column(Integer)
    data_size = Column(String(10))


# 定义HTTP请求表
class HttpRequest(Base):  # type: ignore
    __tablename__ = TABLES['extract_http_request']

    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),
                               index=True, nullable=False)
    type = Column(String(10))
    date = Column(DateTime)
    method = Column(String(10))
    uri = Column(TEXT)
    headers = Column(TEXT, nullable=True)
    user_agent = Column(String(500))  # 用户代理
    referer = Column(String(500))  # 引用页


# define extract HTTP protocol class(HTTP response)
class HttpResponse(Base):  # type: ignore
    __tablename__ = TABLES['extract_http_response']

    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),
                               index=True, nullable=False)
    type = Column(String(10))
    date = Column(DateTime)
    # the length of code is 3
    status_code = Column(String(3))
    status_reason = Column(String(200))
    headers = Column(TEXT, nullable=True)


# define extract TLS certificate class
class TLSCertificate(Base):  # type: ignore
    __tablename__ = TABLES['extract_tls_certificate']

    id = Column(Integer, primary_key=True)
    uploaded_file_fid = Column(String(36),
                               ForeignKey(f"{TABLES['uploaded_file_info']}.fid"),
                               index=True, nullable=False)
    src_ip = Column(String(45))  # 扩展IP字段长度
    dst_ip = Column(String(45))
    src_port = Column(Integer)
    dst_port = Column(Integer)
    cert_chain_len = Column(Integer)
    is_valid = Column(Boolean)
    cert_chain = Column(TEXT)


# 定义YARA规则元数据表（用于管理规则）
class YARARule(Base):  # type: ignore
    __tablename__ = TABLES['yara_rules_file']

    id = Column(Integer, primary_key=True)
    fid = Column(String(36), unique=True, index=True, nullable=False)
    rule_name = Column(String(255), nullable=False)
    rule_location = Column(String(500), nullable=False)  # 规则文件路径
    category = Column(String(100))  # 规则分类
    description = Column(TEXT)  # 规则描述
    author = Column(String(100))  # 规则作者
    reference = Column(TEXT)  # 参考链接
    malware_type = Column(String(100))  # 恶意软件类型
    security_level = Column(String(50))  # 安全级别
    date = Column(DateTime)  # 规则创建或更新时间


class SystemStatus(Base):  # type: ignore
    __tablename__ = TABLES['system_status']

    id = Column(Integer, primary_key=True)
    is_rules_inited = Column(Boolean, default=False)  # YARA规则是否已初始化
    rules_inited_at = Column(DateTime, nullable=True)  # 初始化时间


# 新增：系统日志表（主要记录框架/平台级别日志）
class SystemLog(Base):  # type: ignore
    __tablename__ = TABLES['system_log']

    id = Column(Integer, primary_key=True)
    # e.g. DEBUG/INFO/WARNING/ERROR
    level = Column(String(20), index=True, nullable=False)
    logger = Column(String(150), nullable=True)  # logger 名称或模块名
    action = Column(String(200), nullable=False)  # 日志动作简述
    message = Column(TEXT, nullable=False)  # 日志消息
    created_at = Column(DateTime, default=func.now(), index=True)


# 新增：业务日志表（记录业务事件、操作审计、用户行为等）
class BusinessLog(Base):  # type: ignore
    __tablename__ = TABLES['business_log']

    id = Column(Integer, primary_key=True)
    # 业务类别，如 'rule_update','user_action'
    category = Column(String(100), index=True, nullable=False)
    actor = Column(String(150), nullable=True)  # 触发者（用户/服务）
    action = Column(String(200), nullable=False)  # 动作简述
    detail = Column(TEXT, nullable=False)  # 详细信息，可存 JSON 文本
    result = Column(String(50), nullable=False)  # 结果/状态，如 'success'/'failed'
    created_at = Column(DateTime, default=func.now(), index=True)


class ExportedFileInfo(Base):  # type: ignore
    __tablename__ = TABLES['exported_file_info']

    id = Column(Integer, primary_key=True)
    fid = Column(String(36), unique=True, index=True, nullable=False)
    name = Column(String(100))  # 原始文件名
    path = Column(String(200))  # 文件存储路径
    export_date = Column(DateTime, default=func.now())  # 导出时间
    format = Column(String(10))  # 文件格式(csv, xlsx)
    size = Column(String(20))  # 文件大小


class BlackIP(Base):  # type: ignore
    __tablename__ = TABLES['black_list_ip']

    id = Column(Integer, primary_key=True)
    ip_address = Column(String(45), unique=True, index=True, nullable=False)
    added_at = Column(DateTime, default=func.now())
    source = Column(String(100))  # 黑名单来源描述
    destination = Column(String(100))  # 黑名单所在文件路径


class BlackDomain(Base):  # type: ignore
    __tablename__ = TABLES['black_list_domain']

    id = Column(Integer, primary_key=True)
    domain_name = Column(String(255), unique=True, index=True, nullable=False)
    added_at = Column(DateTime, default=func.now())
    source = Column(String(100))  # 黑名单来源描述
    destination = Column(String(100))  # 黑名单所在文件路径
