from ..storage.mysql_control import MysqlSimClass
from ..logger.log_manager import LogManager
from ..settings import ExportedFileInfo
from typing import Optional, List, Dict


class ShowExportedFile():
    def __init__(self):
        # 创建数据库引擎 & 会话
        self.engine = MysqlSimClass().get_engine()
        self.session = MysqlSimClass().get_session()
        self.logger = LogManager()
        self.logger_name = "ExportedFileInfoManage"

    def get_all_records(self) -> Optional[List[Dict]]:
        '''get all record from ExportedFileInfo table
        '''
        try:
            records = self.session.query(ExportedFileInfo).all()
            return [
                {
                    "fid": r.fid,
                    "name": r.name,
                    "export_date": r.export_date,
                    "format": r.format,
                    "size": r.size
                }
                for r in records
            ]
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="get all exported file records",
                message=f"Error occurred while retrieving exported file records: {e}"  # noqa
            )
            return None
