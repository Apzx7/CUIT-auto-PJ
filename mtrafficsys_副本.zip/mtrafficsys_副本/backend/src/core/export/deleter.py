from ..storage.mysql_control import MysqlSimClass
from ..settings import ExportedFileInfo
from ..logger.log_manager import LogManager
import os


class DeleteExportedFile():
    def __init__(self) -> None:
        self.engine = MysqlSimClass().get_engine()
        self.session = MysqlSimClass().get_session()
        self.logger = LogManager()
        self.logger_name = "ExportedFileInfoManage"

    def delete_file_by_fid(self, fid: str) -> bool:
        """Delete exported file from filesystem by fid.
        Returns True if file is deleted successfully, otherwise False.
        """
        try:
            record = self.session.query(ExportedFileInfo).filter_by(fid=fid).first()  # noqa
            if record:
                file_path = record.path
                if os.path.exists(file_path):
                    os.remove(file_path)
                    self.logger.add_system_log(
                        level="INFO",
                        logger_name=self.logger_name,
                        action="delete exported file",
                        message=f"Deleted exported file at {file_path}"
                    )
                    return True
                else:
                    self.logger.add_system_log(
                        level="WARNING",
                        logger_name=self.logger_name,
                        action="delete exported file",
                        message=f"File at {file_path} does not exist"
                    )
                    return False
            else:
                self.logger.add_system_log(
                    level="WARNING",
                    logger_name=self.logger_name,
                    action="delete exported file",
                    message=f"No exported file record found for fid={fid}"
                )
                return False
        except Exception as e:
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="delete exported file",
                message=f"Error deleting exported file for fid={fid}: {e}"  # noqa
            )
            return False
        finally:
            self.session.close()

    def delete_record_by_fid(self, fid: str) -> bool:
        """Delete exported file record(s) by fid.
        Returns True if at least one record is deleted, otherwise False.
        """
        try:
            # first delete the file from filesystem
            file_deleted = self.delete_file_by_fid(fid)
            if not file_deleted:
                return False
            count = self.session.query(ExportedFileInfo).filter_by(fid=fid).delete()  # noqa
            self.session.commit()
            if count > 0:
                self.logger.add_system_log(
                    level="INFO",
                    logger_name=self.logger_name,
                    action="delete exported file record",
                    message=f"Deleted exported file record(s) with fid={fid}"
                )
                return True
            else:
                self.logger.add_system_log(
                    level="WARNING",
                    logger_name=self.logger_name,
                    action="delete exported file record",
                    message=f"No exported file record found for fid={fid}"
                )
                return False
        except Exception as e:
            self.session.rollback()
            self.logger.add_system_log(
                level="ERROR",
                logger_name=self.logger_name,
                action="delete exported file record",
                message=f"Error deleting exported file record for fid={fid}: {e}"  # noqa
            )
            return False
        finally:
            self.session.close()
