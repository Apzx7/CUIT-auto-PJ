import uuid
from datetime import datetime
from typing import Optional, Tuple

import pandas as pd
from pathlib import Path

from ..settings import ExportedFileInfo, EXPORT_DIRECTORY, TABLES
from ..storage.mysql_control import MysqlSimClass
from .log_manager import LogManager


class LogExporter:
    def __init__(self) -> None:
        self.g_logger = LogManager()
        self.actor = "LogExport"
        self.engine = MysqlSimClass().get_engine()
        self.session = MysqlSimClass().get_session()
        self.export_dir = Path(EXPORT_DIRECTORY)
        self.c_time = datetime.now().strftime('%Y%m%d_%H%M%S')
        self.tb_names = {
            'system_log': TABLES['system_log'],
            'business_log': TABLES['business_log'],
        }

    def __ensure_directory_exists(self) -> None:
        """Create export directory if missing."""
        if not self.export_dir.exists():
            self.export_dir.mkdir(parents=True, exist_ok=True)

    def __get_file_size(self, file_path: str) -> str:
        """Return human-readable file size."""
        try:
            file_bytes = Path(file_path).stat().st_size
            if file_bytes < 1024:
                return f"{file_bytes} B"
            if file_bytes < 1024 ** 2:
                return f"{file_bytes / 1024:.2f} KB"
            if file_bytes < 1024 ** 3:
                return f"{file_bytes / (1024 ** 2):.2f} MB"
            return f"{file_bytes / (1024 ** 3):.2f} GB"
        except Exception:
            return "0 B"

    def __save_exported_file_info(self, file_name: str,
                                  file_id: str,
                                  file_path: str,
                                  file_type: str = 'csv') -> None:
        """Persist exported file metadata."""
        exported_file_info = ExportedFileInfo(
            fid=file_id,
            name=file_name,
            path=file_path,
            export_date=datetime.now(),
            format=file_type,
            size=self.__get_file_size(file_path),
        )
        with self.session as session:
            session.add(exported_file_info)
            session.commit()

    def __sanitize(self, value: str) -> str:
        """Basic single-quote escape for simple SQL string usage."""
        return value.replace("'", "''")

    def __parse_datetime(self,
                         value: Optional[datetime | str]) -> Optional[datetime]:  # noqa
        """Parse datetime from string or passthrough if already datetime."""
        if value is None:
            return None
        if isinstance(value, datetime):
            return value
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(value, fmt)
            except ValueError:
                continue
        try:
            return datetime.fromisoformat(value)
        except Exception:
            return None

    def __build_conditions(self, start_time: Optional[datetime],
                           end_time: Optional[datetime],
                           level_or_result: Optional[str],
                           field_level: str) -> str:
        conditions = []
        if start_time:
            conditions.append(f"created_at >= '{start_time:%Y-%m-%d %H:%M:%S}'")  # noqa
        if end_time:
            conditions.append(f"created_at <= '{end_time:%Y-%m-%d %H:%M:%S}'")
        if level_or_result:
            safe_val = self.__sanitize(level_or_result)
            conditions.append(f"{field_level} = '{safe_val}'")
        return " WHERE " + " AND ".join(conditions) if conditions else ""

    def __export_query_to_csv(self, query: str, csv_name: str,
                              chunksize: int = 20000) -> Optional[Tuple[str, str]]:  # noqa
        """Stream SQL query to CSV, returning (file_name, file_id) on success.
        """
        self.__ensure_directory_exists()
        csv_path = self.export_dir / csv_name
        abs_csv_path = str(csv_path.resolve())
        file_id = str(uuid.uuid4())
        first_write = True
        written = False

        try:
            for chunk in pd.read_sql_query(sql=query, con=self.engine,
                                           chunksize=chunksize):
                if chunk.empty:
                    continue
                if first_write:
                    chunk.to_csv(csv_path, index=False, mode='w',
                                 encoding='utf-8-sig')
                    first_write = False
                else:
                    chunk.to_csv(csv_path, index=False, mode='a',
                                 header=False, encoding='utf-8-sig')
                written = True

            if not written:
                return None

            self.__save_exported_file_info(
                file_name=csv_name,
                file_id=file_id,
                file_path=abs_csv_path,
            )
            return (csv_name, file_id)
        except Exception as e:
            self.g_logger.add_business_log(
                category="LogExport",
                actor=self.actor,
                action="Export logs to csv",
                detail=f"Export error: {e}.",
                result="Failure"
            )
            return None

    def export_system_logs(self,
                           start_time: Optional[datetime | str] = None,
                           end_time: Optional[datetime | str] = None,
                           level: Optional[str] = None) -> Optional[Tuple[str, str]]:  # noqa
        """Export system logs filtered by time range and level."""
        start_dt = self.__parse_datetime(start_time)
        end_dt = self.__parse_datetime(end_time)
        where_clause = self.__build_conditions(start_dt, end_dt,
                                               level, 'level')
        query = (f"SELECT * FROM {self.tb_names['system_log']}"
                 f"{where_clause} ORDER BY created_at DESC")

        level_suffix = f"_{level.lower()}" if level else ""
        csv_name = f"system_log{level_suffix}_{self.c_time}_exported.csv"

        result = self.__export_query_to_csv(query, csv_name)
        self.g_logger.add_business_log(
            category="LogExport",
            actor=self.actor,
            action="Export system log",
            detail=f"start={start_dt}, end={end_dt}, level={level}. Export result: {result}",  # noqa
            result="Success" if result else "Failure"
        )
        return result

    def export_business_logs(self,
                             start_time: Optional[datetime | str] = None,
                             end_time: Optional[datetime | str] = None,
                             result_filter: Optional[str] = None) -> Optional[Tuple[str, str]]:  # noqa
        """Export business logs filtered by time range and result."""
        start_dt = self.__parse_datetime(start_time)
        end_dt = self.__parse_datetime(end_time)
        where_clause = self.__build_conditions(start_dt, end_dt,
                                               result_filter, 'result')
        query = (f"SELECT * FROM {self.tb_names['business_log']}"
                 f"{where_clause} ORDER BY created_at DESC")

        result_suffix = f"_{result_filter.lower()}" if result_filter else ""
        csv_name = f"business_log{result_suffix}_{self.c_time}_exported.csv"

        export_result = self.__export_query_to_csv(query, csv_name)
        self.g_logger.add_business_log(
            category="LogExport",
            actor=self.actor,
            action="Export business log",
            detail=f"start={start_dt}, end={end_dt}, result={result_filter}. Export result: {export_result}",  # noqa
            result="Success" if export_result else "Failure"
        )
        return export_result
