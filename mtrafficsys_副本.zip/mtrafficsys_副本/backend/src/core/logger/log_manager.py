from typing import Optional, Dict, Any, Union
from datetime import datetime, timezone

from ..storage.mysql_control import MysqlSimClass  # type: ignore
from ..settings import SystemLog, BusinessLog  # type: ignore
from sqlalchemy import asc, desc, and_  # type: ignore

# ...existing code...


class LogManager:
    """
    提供系统日志(SystemLog)与业务日志(BusinessLog)的查询、排序、分页与导出功能。
    注意: caller 负责在适当时机调用 close() 释放 DB session。
    """

    def __init__(self) -> None:
        self.session = MysqlSimClass().get_session()
        self.logger_name = "LogManager"

    def close(self) -> None:
        try:
            self.session.close()
        except Exception:
            pass

    def _serialize_log(self,
                       rec: Union[SystemLog, BusinessLog]) -> Dict[str, Any]:
        # 将 ORM 实例序列化为 dict（只包含常用字段）
        d: Dict[str, Any] = {}
        for col in rec.__table__.columns:
            v = getattr(rec, col.name)
            # datetime -> ISO
            if isinstance(v, datetime):
                d[col.name] = v.isoformat()
            else:
                d[col.name] = v
        return d

    def _apply_common_sort(self, query, model, sort_by: str, descending: bool):
        if not hasattr(model, sort_by):
            sort_by = "created_at" if hasattr(model, "created_at") else model.__table__.columns.keys()[0]  # noqa
        order_col = getattr(model, sort_by)
        return query.order_by(desc(order_col) if descending else asc(order_col))  # noqa

    def query_system_logs(self,
                          level: Optional[str] = None,
                          start_time: Optional[Union[datetime, str]] = None,
                          end_time: Optional[Union[datetime, str]] = None,
                          page: int = 1,
                          per_page: int = 50,
                          sort_by: str = "created_at",
                          desc_order: bool = True) -> Dict[str, Any]:
        """
        查询 SystemLog, 返回 pagination 结果字典 {total,page,per_page,items}
        start_time/end_time 可传 datetime 或 ISO 字符串。
        """
        q = self.session.query(SystemLog)
        conds = []
        if level:
            conds.append(SystemLog.level == level)
        if start_time:
            t = start_time if isinstance(start_time, datetime) else datetime.fromisoformat(start_time)  # noqa
            conds.append(SystemLog.created_at >= t)
        if end_time:
            t = end_time if isinstance(end_time, datetime) else datetime.fromisoformat(end_time)  # noqa
            conds.append(SystemLog.created_at <= t)
        if conds:
            q = q.filter(and_(*conds))

        total = q.count()
        q = self._apply_common_sort(q, SystemLog, sort_by, desc_order)
        offset = max(page - 1, 0) * per_page
        rows = q.offset(offset).limit(per_page).all()
        items = [self._serialize_log(r) for r in rows]
        return {"total": total, "page": page,
                "per_page": per_page, "items": items}

    def query_business_logs(self,
                            task_status: Optional[str] = None,
                            start_time: Optional[Union[datetime, str]] = None,
                            end_time: Optional[Union[datetime, str]] = None,
                            page: int = 1,
                            per_page: int = 50,
                            sort_by: str = "created_at",
                            desc_order: bool = True) -> Dict[str, Any]:
        """
        查询 BusinessLog, 返回 pagination 结果字典 {total,page,per_page,items}
        """
        q = self.session.query(BusinessLog)
        conds = []
        if task_status:
            conds.append(BusinessLog.result == task_status)
        if start_time:
            t = start_time if isinstance(start_time, datetime) else datetime.fromisoformat(start_time)  # noqa
            conds.append(BusinessLog.created_at >= t)
        if end_time:
            t = end_time if isinstance(end_time, datetime) else datetime.fromisoformat(end_time)  # noqa
            conds.append(BusinessLog.created_at <= t)
        if conds:
            q = q.filter(and_(*conds))

        total = q.count()
        q = self._apply_common_sort(q, BusinessLog, sort_by, desc_order)
        offset = max(page - 1, 0) * per_page
        rows = q.offset(offset).limit(per_page).all()
        items = [self._serialize_log(r) for r in rows]
        return {"total": total, "page": page,
                "per_page": per_page, "items": items}

    def add_system_log(self,
                       level: str,
                       logger_name: str,
                       action: str,
                       message: str) -> None:
        """
        添加一条系统日志记录。
        """
        session = MysqlSimClass().get_session()
        try:
            log_rec = SystemLog(
                level=level,
                logger=logger_name,
                action=action,
                message=message,
                created_at=datetime.now(timezone.utc)
            )
            session.add(log_rec)
            session.commit()
        except Exception:
            try:
                session.rollback()
            except Exception:
                pass
        finally:
            try:
                session.close()
            except Exception:
                pass

    def add_business_log(self,
                         category: str,
                         actor: str,
                         action: str,
                         detail: str,
                         result: str) -> None:
        """
        添加一条业务日志记录。
        """
        session = MysqlSimClass().get_session()
        try:
            log_rec = BusinessLog(
                category=category,
                actor=actor,
                action=action,
                detail=detail,
                result=result,
                created_at=datetime.now(timezone.utc)
            )
            session.add(log_rec)
            session.commit()
        except Exception:
            try:
                session.rollback()
            except Exception:
                pass
        finally:
            try:
                session.close()
            except Exception:
                pass
