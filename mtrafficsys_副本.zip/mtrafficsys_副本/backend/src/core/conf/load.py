from ruamel.yaml import YAML, YAMLError
from .settings import CONF_FILE
import os


class YamlLoader():
    def __init__(self):
        self.file_path = CONF_FILE
        self.config = self.load_yaml()

    def load_yaml(self):
        yaml = YAML(typ='rt')
        # preserve quotes, it used to keep the comments
        yaml.preserve_quotes = True
        # default_flow_style=False, it used to parse block style
        yaml.default_flow_style = False

        try:
            with open(self.file_path, 'r') as file:
                return yaml.load(file)
        except FileNotFoundError:
            return None
        except YAMLError:
            return None

    def get_config(self):
        return self.config

    def get_mysql_conf(self):
        if self.config is None:
            return None
        return self.config['MYSQL_CONF']

    def get_uvicorn_conf(self):
        if self.config is None:
            return None
        return self.config['UVICORN_CONF']
    
    def get_cors_conf(self):
        if self.config is None:
            return None
        return self.config['CORS_CONF']
    
    def get_api_key(self):
        if self.config is None:
            return None
        return self.config['DASHSCOPE_API_KEY']
