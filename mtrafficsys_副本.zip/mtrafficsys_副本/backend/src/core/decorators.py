import time


# timing decorator to show exec time
def timing_decorator(func):
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        execution_time = end_time - start_time
        print("{} function exec time is {:.6f} second".format(func.__name__, execution_time))  # noqa E501
        return result
    return wrapper
