from logging.handlers import TimedRotatingFileHandler
from threading import Lock
import logging
import os


class LoggerProject(object):
    def __init__(self) -> None:
        self.mutex = Lock()
        self.formatter = '%(asctime)s -<>- %(filename)s -<>- [line]:%(lineno)d -<>- %(levelname)s -<>- %(message)s'  # noqa E501

    def __create_logger(self) -> logging.Logger:
        _logger = logging.getLogger(__name__)
        # set the level of logger
        _logger.setLevel(level=logging.WARNING)
        return _logger

    def __file_logger(self) -> TimedRotatingFileHandler:
        '''clear log files every week, and max size of log file is 5'''
        current_path = os.path.dirname(os.path.realpath(__file__))
        log_path = current_path + "/log/"
        if not os.path.exists(log_path):
            os.makedirs(log_path)
        log_name = log_path + 'access.log'
        time_rotate_file = TimedRotatingFileHandler(
            filename=log_name,
            when='D',
            interval=7,
            backupCount=5)
        time_rotate_file.setFormatter(logging.Formatter(self.formatter))
        time_rotate_file.setLevel(logging.INFO)
        return time_rotate_file

    def __console_logger(self) -> logging.StreamHandler:
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level=logging.INFO)
        console_handler.setFormatter(logging.Formatter(self.formatter))
        return console_handler

    def pub_logger(self) -> logging.Logger:
        logger = self.__create_logger()
        self.mutex.acquire()
        if not logger.handlers:
            logger.addHandler(self.__file_logger())
            # logger.addHandler(self.__console_logger())
        self.mutex.release()
        return logger
