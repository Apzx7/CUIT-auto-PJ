from fastapi import Depends
from .core import get_db_session


def get_db():
    """
    FastAPI 依赖注入函数
    """
    db = get_db_session()
    try:
        yield db
    finally:
        db.close()
