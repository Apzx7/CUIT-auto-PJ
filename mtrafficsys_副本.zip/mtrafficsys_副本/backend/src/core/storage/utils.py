from contextlib import contextmanager
from .core import get_db_session


@contextmanager
def db_transaction():
    """
    通用数据库事务上下文管理器
    适用于非 FastAPI 模块
    """
    db = get_db_session()
    try:
        yield db
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()
