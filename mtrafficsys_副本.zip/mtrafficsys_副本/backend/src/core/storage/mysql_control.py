from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from ..settings import MYSQL_URL
from typing import Any


class MysqlSimClass:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(MysqlSimClass, cls).__new__(cls, *args, **kwargs)  # noqa
        return cls._instance

    def __init__(self):
        if not hasattr(self, 'engine'):
            # 创建数据库引擎
            self.engine = create_engine(MYSQL_URL,
                                        pool_size=10,
                                        max_overflow=20,
                                        pool_timeout=30,
                                        pool_pre_ping=True,
                                        pool_recycle=3600)

            self.Session = sessionmaker(bind=self.engine, autoflush=False,
                                        autocommit=False)

    def get_engine(self) -> Any:
        '''
        get engine
        return: engine
        '''
        return self.engine

    def get_session(self) -> Any:
        '''
        get session
        return: session
        '''
        return self.Session()
