from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from ..settings import MYSQL_URL

# 创建全局引擎（单例）
engine = create_engine(
    MYSQL_URL,
    pool_size=10,
    max_overflow=20,
    pool_timeout=30,
    pool_pre_ping=True,
    pool_recycle=3600,
)

# 全局 Session 工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def get_db_session():
    """
    获取数据库会话 - 通用方法，适用于所有场景
    """
    return SessionLocal()
