rule mysql_file : usernames plain_passwords passwords
{
    meta:
        author = "DiabloHorn https://diablohorn.com"
        description = "find mysql config file with plaintext passwords"
        category = "Misc"
        malware_type = "Generic"
        security_level = "medium"
    strings:
        $section_header = "[client]\n" nocase
        $section_header2 = "[mysqld]\n" nocase
        $content_data = /port.{,10}?=/ nocase
        $content_data2 = /socket.{,10}?=/ nocase
        $content_data3 = /max_connections.{,10}?=/ nocase 
        $creds_user = /user.{,10}?=/ nocase
        $creds_password = /password.{,10}?=/ nocase
    condition:
        all of them
}

rule unencrypted_private_key : plain_privatekey privatekey
{
    meta:
        author = "DiabloHorn https://diablohorn.com"
        description = "find unencrypted private keys"
        category = "Misc"
        malware_type = "Generic"
        security_level = "medium"
    strings:
        $content = "-----BEGIN RSA PRIVATE KEY-----" nocase
        $content2 = "encrypted" nocase
    condition:
        $content at 0 and not $content2
}

rule encrypted_private_key : encrypted_privatekey privatekey keycontainer
{
    meta:
        author = "DiabloHorn https://diablohorn.com"
        description = "find encrypted private keys"
        category = "Misc"
        malware_type = "Generic"
        security_level = "medium"
    strings:
        $content = "-----BEGIN RSA PRIVATE KEY-----" nocase
        $content2 = "encrypted" nocase
    condition:
        $content at 0 and $content2
}

rule gpp_file : passwords plain_password
{
    meta:
        author = "DiabloHorn https://diablohorn.com"
        description = "find gpp files"
        category = "Misc"
        malware_type = "Generic"
        security_level = "medium"
    strings:
        $content1 = "<?xml" nocase
        $content2 = "<user" nocase
        $content3 = "cpassword=" nocase
        $content4 = "username=" nocase
        $content5 = "clsid=" nocase
        $content6 = "</user>" nocase
    condition:
        all of them
}

rule sql_dump : passwords dbdump {
    meta:
        author = "ydklijnsma https://blog.0x3a.com"
        description = "Looks at sql dump file pattern"
        category = "Misc"
        malware_type = "Generic"
        security_level = "medium"

    strings:
        $dump_header_regex = /-- [a-zA-Z0-9]+\s?SQL\s?[Dd]ump\s?/i

        $dump_string_createtableifexists = "CREATE TABLE IF NOT EXISTS"
        $dump_string_droptableifexists = "DROP TABLE IF EXISTS "
        $dump_string_createtable = "CREATE TABLE "

        $insert_into = "INSERT INTO "

    condition:
        $dump_header_regex at 0 and
            (2 of ($dump_string_*)) and
                #insert_into >= 1
}
