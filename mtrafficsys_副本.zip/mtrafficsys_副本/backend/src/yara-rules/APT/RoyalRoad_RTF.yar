rule RoyalRoad_RTF
{
    meta:
        id = "p1XW7z3B1sdN89zXF7Nel"
        fingerprint = "52be45a991322fa96f4e806cf6fa7a77886f63799c1f67723484bc3796363a4e"
        version = "1.0"
        creation_date = "2020-01-01"
        first_imported = "2021-12-30"
        last_modified = "2025-03-10"
        status = "RELEASED"
        sharing = "TLP:CLEAR"
        source = "BARTBLAZE"
        author = "@bartblaze"
        description = "Identifies RoyalRoad RTF, used by multiple China-nexus APT groups."
        category = "APT"
        malware_type = "Exploit Kit"
        security_level = "High"
        malware = "ROYALROAD"
        reference = "https://nao-sec.org/2020/01/an-overhead-view-of-the-royal-road.html"


    strings:
        $rtf = "{\\rt"
        $RR1 = "5C746D705C382E74" nocase
        $RR2 = "5C417070446174615C4C6F63616C5C54656D705C382E74" nocase

    condition:
        $rtf at 0 and any of ($RR*)
}
