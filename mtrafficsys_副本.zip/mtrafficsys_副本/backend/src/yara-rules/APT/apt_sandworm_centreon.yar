/*
    Reworked YARA rules as provided by FR/ANSSI/SDO in report on Sandworm activity 
    https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf

    - simplified structure (removed private rules)
    - performance / memory tuning by removal of unnecessary regular expressions
    - removal of overapping rules (rules that contained the specific socket path '/tmp/.applocktx')
*/

rule WEBSHELL_PAS_webshell {
   meta:
      author = "FR/ANSSI/SDO (modified by Florian Roth)"
      description = "Detects P.A.S. PHP webshell - Based on DHS/FBI JAR-16-2029 (Grizzly  Steppe)"
      reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
      date = "2021-02-15"
      score = 70
      id = "862aab77-936e-524c-8669-4f48730f4ed5"
      category = "apt"
      malware_type = "webshell"
      security_level = "critical"
   strings:
      $php = "<?php"
      $strreplace = "(str_replace("
      $md5 = ".substr(md5(strrev($"
      $gzinflate = "gzinflate"
      $cookie = "_COOKIE"
      $isset = "isset"
   condition:
      all of them
}

rule WEBSHELL_PAS_webshell_ZIPArchiveFile {
   meta:
      author = "FR/ANSSI/SDO (modified by Florian Roth)"
      description = "Detects an archive file created by P.A.S. for download operation"
      reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
      date = "2021-02-15"
      score = 80
      id = "081cc65b-e51c-59fc-a518-cd986e8ee2f7"
      category = "apt"
      malware_type = "webshell"
      security_level = "critical"
   strings:
      $s1 = "Archive created by P.A.S. v."
   condition:
      $s1
}

rule WEBSHELL_PAS_webshell_PerlNetworkScript {
   meta:
      author = "FR/ANSSI/SDO"
      description = "Detects PERL scripts created by P.A.S. webshell"
      reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
      date = "2021-02-15"
      score = 90
      id = "1625b63f-ead7-5712-92b4-0ce6ecc49fd4"
      category = "apt"
      malware_type = "webshell"
      security_level = "critical"
   strings:
      $pl_start = "#!/usr/bin/perl\n$SIG{'CHLD'}='IGNORE'; use IO::Socket; use FileHandle;"
      $pl_status = "$o=\" [OK]\";$e=\" Error: \""
      $pl_socket = "socket(SOCKET, PF_INET, SOCK_STREAM,$tcp) or die print \"$l$e$!$l"
      $msg1 = "print \"$l OK! I\\'m successful connected.$l\""
      $msg2 = "print \"$l OK! I\\'m accept connection.$l\""
   condition:
      ( $pl_start at 0 and all of ($pl*) ) or
      any of ($msg*)
}

rule WEBSHELL_PAS_webshell_SQLDumpFile {
   meta:
      author = "FR/ANSSI/SDO"
      description = "Detects SQL dump file created by P.A.S. webshell"
      reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
      date = "2021-02-15"
      score = 90
      id = "4c26feeb-3031-5c91-9eeb-4b5fe9702e39"
      category = "apt"
      malware_type = "webshell"
      security_level = "critical"
   strings:
      $ = "-- [ SQL Dump created by P.A.S. ] --"
   condition:
      1 of them
}

rule APT_MAL_Sandworm_Exaramel_Configuration_Key {
   meta:
      author = "FR/ANSSI/SDO"
      description = "Detects the encryption key for the configuration file used by Exaramel malware as seen in sample e1ff72[...]"
      reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
      date = "2021-02-15"
      score = 80
      id = "8078de62-3dd2-5ee0-8bda-f508e4013144"
      category = "apt"
      malware_type = "exaramel"
      security_level = "critical"
   strings:
      $ = "odhyrfjcnfkdtslt"
   condition:
      all of them
}

rule APT_MAL_Sandworm_Exaramel_Configuration_File_Plaintext {
   meta:
      author = "FR/ANSSI/SDO"
      description = "Detects contents of the configuration file used by Exaramel (plaintext)"
      reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
      date = "2021-02-15"
      score = 80
      id = "6f0d834b-e6c8-59e6-bf9a-b4fd9c0b2297"
      category = "apt"
      malware_type = "exaramel"
      security_level = "critical"
   strings:
      $ = /\{"Hosts":\[".{10,512}"\],"Proxy":".{0,512}","Version":".{1,32}","Guid":"/
   condition:
      all of them
}

rule APT_MAL_Sandworm_Exaramel_Configuration_File_Ciphertext {
   meta:
      author = "FR/ANSSI/SDO"
      description = "Detects contents of the configuration file used by Exaramel (encrypted with key odhyrfjcnfkdtslt, sample e1ff72[...]"
      reference = "https://www.cert.ssi.gouv.fr/uploads/CERTFR-2021-CTI-005.pdf"
      date = "2021-02-15"
      score = 80
      id = "763dbb17-2bad-5b40-8a7b-b71bc5849cd9"
      category = "apt"
      malware_type = "exaramel"
      security_level = "critical"
   strings:
      $ = { 6F B6 08 E9 A3 0C 8D 5E DD BE D4 } // encrypted with key odhyrfjcnfkdtslt
   condition:
      all of them
}
