rule MAL_G_Dropper_BRICKSTEAL_1 {
   meta:
      description = "Detects backdoor BRICKSTEAL dropper used by APT group UNC5221 (China Nexus)"
      author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
      date = "2025-09-25"
      score = 75
      reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
      category = "APT"
      malware_type = "BRICKSTEAL"
      security_level = "high"
   strings:
      $str1 = "Base64.getDecoder().decode"
      $str2 = "Thread.currentThread().getContextClassLoader()"
      $str3 = ".class.getDeclaredMethod"
      $str4 = "byte[].class"
      $str5 = "method.invoke"
      $str6 = "filterClass.newInstance()"
      $str7 = "/websso/SAML2/SSO/*"
   condition:
      all of them
}

rule MAL_G_Dropper_BRICKSTEAL_2 {
   meta:
      description = "Detects backdoor BRICKSTEAL dropper used by APT group UNC5221 (China Nexus)"
      author = "Google Threat Intelligence Group (GTIG) (modified by Florian Roth)"
      date = "2025-09-25"
      score = 75
      reference = "https://cloud.google.com/blog/topics/threat-intelligence/brickstorm-espionage-campaign"
      category = "APT"
      malware_type = "BRICKSTEAL"
      security_level = "high"
   strings:
      // $str1 = /\(Class<\?>\)\smethod\.invoke\(\w{1,20},\s\w{1,20},\s0,\s\w{1,20}\.length\);/i ascii wide
      $str1_alt = "(Class<?>) method.invoke(" ascii wide
      $str2 = "(\"yv66vg" ascii wide
      $str3 = "request.getSession().getServletContext" ascii wide
      $str4 = ".getClass().getDeclaredField(" ascii wide
      $str5 = "new FilterDef();" ascii wide
      $str6 = "new FilterMap();" ascii wide
   condition:
      all of them
}
