import "pe"

/*
   Yara Rule Set
   Author: Florian Roth
   Date: 2017-10-18
   Identifier: HKDoor
   Reference: https://www.cylance.com/en_us/blog/threat-spotlight-opening-hackers-door.html
*/

rule hkdoor_backdoor_dll {
   meta:
      description = "Hacker's Door Backdoor DLL"
      author = "Cylance Inc."
      reference = "https://www.cylance.com/en_us/blog/threat-spotlight-opening-hackers-door.html"
      id = "470e5d37-8a5a-500f-b9b9-245b8dc2c4d7"
      category = "APT"
      malware_type = "Backdoor"
      security_level = "High"
   strings:
      $s1 = "The version of personal hacker's door server is" fullword ascii
      $s2 = "The connect back interval is %d (minutes)" fullword ascii
      $s3 = "I'mhackeryythac1977" fullword ascii
      $s4 = "Welcome to http://www.yythac.com" fullword ascii
      $s5 = "SeLoadDriverPrivilege" fullword ascii
   condition:
      uint16(0) == 0x5a4d and
      filesize < 400KB and
      ( 3 of ($s*) ) and
      pe.characteristics & pe.DLL and
      pe.imports("ws2_32.dll", "WSAStartup") and
      pe.imports("ws2_32.dll", "sendto")
}

rule hkdoor_backdoor {
   meta:
      description = "Hacker's Door Backdoor"
      author = "Cylance Inc."
      reference = "https://www.cylance.com/en_us/blog/threat-spotlight-opening-hackers-door.html"
      id = "470e5d37-8a5a-500f-b9b9-245b8dc2c4d7"
      category = "APT"
      malware_type = "Backdoor"
      security_level = "High"
   strings:
      $s1 = "http://www.yythac.com" fullword ascii
      $s2 = "Example:%s 192.168.1.100 139 -p yyt_hac -t 1" fullword ascii
      $s3 = "password-----------The hacker's door's password" fullword ascii
      $s4 = "It is the client of hacker's door %d.%d public version" fullword ascii
      $s5 = "hkdoordll.dll" fullword ascii
      $s6 = "http://www.yythac.com/images/mm.jpg" fullword ascii
      $s7 = "I'mhackeryythac1977" fullword ascii
      $s8 = "yythac.yeah.net" fullword ascii
   condition:
      uint16(0) == 0x5a4d and
      filesize < 400KB and
      ( 4 of ($s*) )
}

rule hkdoor_dropper {
   meta:
      description = "Hacker's Door Dropper"
      author = "Cylance Inc."
      date = "2018-01-01"
      modified = "2023-01-07"
      reference = "https://www.cylance.com/en_us/blog/threat-spotlight-opening-hackers-door.html"
      id = "8c8171b9-6256-591a-8f74-abac1cb9a50b"
      category = "APT"
      malware_type = "Dropper"
      security_level = "High"
   strings:
      $s1 = "The version of personal hacker's door server is" fullword ascii
      $s2 = "The connect back interval is %d (minutes)" fullword ascii
      $s3 = "I'mhackeryythac1977" fullword ascii
      $s4 = "Welcome to http://www.yythac.com" fullword ascii
      $s5 = "SeLoadDriverPrivilege" fullword ascii
      $s6 = "\\drivers\\ntfs.sys" ascii
      $s7 = "kifes" fullword ascii
   condition:
      uint16(0) == 0x5a4d and
      filesize < 1000KB and
      ( 4 of ($s*) ) and
      pe.number_of_resources > 0 and
      for any i in (0..pe.number_of_resources - 1):
         (pe.resources[i].type_string == "B\x00I\x00N\x00" and
         uint16(pe.resources[i].offset) == 0x5A4D) and
      pe.imports("KERNEL32.dll", "FindResourceW") and
      pe.imports("KERNEL32.dll", "LoadResource")
}
