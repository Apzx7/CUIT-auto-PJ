import "math"
import "pe"

/* 
    YARA Rules by Volexity
    Reference: https://www.volexity.com/blog/2021/05/27/suspected-apt29-operation-launches-election-fraud-themed-phishing-campaigns/
*/

rule APT_APT29_Win_FlipFlop_LDR : APT29 {
   meta:
      author = "threatintel@volexity.com"
      date = "2021-05-25"
      description = "A loader for the CobaltStrike malware family, which ultimately takes the first and second bytes of an embedded file, and flips them prior to executing the resulting payload."
      hash = "ee42ddacbd202008bcc1312e548e1d9ac670dd3d86c999606a3a01d464a2a330"
      reference = "https://www.volexity.com/blog/2021/05/27/suspected-apt29-operation-launches-election-fraud-themed-phishing-campaigns/"
      id = "58696a6f-55a9-5212-9372-a539cc327e6b"
      category = "APT"
      malware_type = "Loader"
      security_level = "high"
   strings:
      $s1 = "irnjadle"
      $s2 = "BADCFEHGJILKNMPORQTSVUXWZY"
      $s3 = "iMrcsofo taBesC yrtpgoarhpciP orived r1v0."
   condition:
      all of ($s*)
}

rule APT_APT28_Win_FreshFire : APT29 {
   meta:
      author = "threatintel@volexity.com"
      date = "2021-05-27"
      description = "The FRESHFIRE malware family. The malware acts as a downloader, pulling down an encrypted snippet of code from a remote source, executing it, and deleting it from the remote server."
      hash = "ad67aaa50fd60d02f1378b4155f69cffa9591eaeb80523489a2355512cc30e8c"
      reference = "https://www.volexity.com/blog/2021/05/27/suspected-apt29-operation-launches-election-fraud-themed-phishing-campaigns/"
      id = "050b8e61-139a-5ff5-998a-7de67c9975bf"
      category = "APT"
      malware_type = "Downloader"
      security_level = "high"
   strings:
      $uniq1 = "UlswcXJJWhtHIHrVqWJJ"
      $uniq2 = "gyibvmt\x00"

      $path1 = "root/time/%d/%s.json"
      $path2 = "C:\\dell.sdr"
      $path3 = "root/data/%d/%s.json"
   condition:
      (
         pe.number_of_exports == 1 and pe.exports("WaitPrompt")
      ) or
      any of ($uniq*) or
      2 of ($path*)
}

/* 
    YARA Rules by Florian
    Mostly based on MSTICs report 
    https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/
    Not shared publicly: rules for CobaltStrike loader samples, ISOs, specifc msiexec method found in some samples
    only available in THOR and VALHALLA
*/

rule APT_APT29_NOBELIUM_JS_EnvyScout_May21_1 {
   meta:
      description = "Detects EnvyScout deobfuscator code as used by NOBELIUM group"
      author = "Florian Roth (Nextron Systems)"
      reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
      date = "2021-05-29"
      id = "42739aad-a88a-545b-8256-1f727c79c4f8"
      category = "APT"
      malware_type = "Deobfuscator"
      security_level = "high"
   strings:
      $x1 = "[i].charCodeAt(0) ^ 2);}"
   condition:
      filesize < 5000KB and 1 of them
}

rule APT_APT29_NOBELIUM_JS_EnvyScout_May21_2 {
   meta:
      description = "Detects EnvyScout deobfuscator code as used by NOBELIUM group"
      author = "Florian Roth (Nextron Systems)"
      reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
      date = "2021-05-29"
      id = "d5cf3365-fe24-533a-a678-b5b6d4d99997"
      category = "APT"
      malware_type = "Deobfuscator"
      security_level = "high"
   strings:
      $s1 = "saveAs(blob, " ascii
      $s2 = ".iso\");" ascii
      $s3 = "application/x-cd-image" ascii
      $s4 = ".indexOf(\"Win\")!=-1" ascii
   condition:
      filesize < 5000KB and all of them
}

rule APT_APT29_NOBELIUM_LNK_NV_Link_May21_2 {
   meta:
      description = "Detects NV Link as used by NOBELIUM group"
      author = "Florian Roth (Nextron Systems)"
      reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
      date = "2021-05-29"
      id = "52c2caf9-13df-5614-9c9e-afcd76ec77f9"
      category = "APT"
      malware_type = "LNK Loader"
      security_level = "high"
   strings:
      $s1 = "RegisterOCX BOOM" ascii wide
      $s2 = "cmd.exe /c start BOOM.exe" ascii wide
   condition:
      filesize < 5000KB and 1 of them
}

rule APT_APT29_NOBELIUM_LNK_Samples_May21_1 {
   meta:
      description = "Detects link file characteristics as described in APT29 NOBELIUM report"
      author = "Florian Roth (Nextron Systems)"
      reference = "https://www.microsoft.com/security/blog/2021/05/27/new-sophisticated-email-based-attack-from-nobelium/"
      date = "2021-05-27"
      score = 85
      hash1 = "24caf54e7c3fe308444093f7ac64d6d520c8f44ea4251e09e24931bdb72f5548"
      id = "c807ab5a-f66a-5622-81b1-6e69b6df8446"
      category = "APT"
      malware_type = "LNK Loader"
      security_level = "high"
   strings:
      $a1 = "rundll32.exe" wide

      $sa1 = "IMGMountingService.dll" wide
      $sa2 = "MountImgHelper" wide

      $sb1 = "diassvcs.dll" wide
      $sb2 = "InitializeComponent" wide

      $sc1 = "MsDiskMountService.dll" wide 
      $sc2 = "DiskDriveIni" wide

      $sd1 = "GraphicalComponent.dll" wide
      $sd2 = "VisualServiceComponent" wide

      $se1 = "data/mstu.dll,MicrosoftUpdateService" wide
   condition:
      uint16(0) == 0x004c and
      filesize < 4KB and $a1 and 
      ( all of ($sa*) or all of ($sb*) or all of ($sc*) or all of ($sd*) or all of ($se*) )
}

rule APT_APT29_NOBELIUM_BoomBox_May21_1 {
   meta:
      description = "Detects BoomBox malware as described in APT29 NOBELIUM report"
      author = "Florian Roth"
      reference = "https://www.microsoft.com/security/blog/2021/05/27/new-sophisticated-email-based-attack-from-nobelium/"
      date = "2021-05-27"
      modified = "2025-03-20"
      score = 85
      hash = "8199f309478e8ed3f03f75e7574a3e9bce09b4423bd7eb08bb5bff03af2b7c27"
      id = "1a14dcf7-81be-5a74-a530-caf6268d1976"
      category = "APT"
      malware_type = "Malware"
      security_level = "high"
   strings:
      // PowerShell tool - e1765eafb68fc6034575f126b014fcad6bb043c2961823b7cef5f711e9e01d1c
      $a1 = "]::FromBase64String($" ascii wide

      $xa1 = "123do3y4r378o5t34onf7t3o573tfo73" ascii wide fullword
      $xa2 = "1233t04p7jn3n4rg" ascii wide fullword

      $s1 = "\\Release\\BOOM.pdb" ascii
      $s2 = "/files/upload" ascii
      $s3 = "/tmp/readme.pdf" ascii fullword
      $s4 = "/new/{0}" ascii fullword
      $s5 = "(&(objectClass=user)(objectCategory=person))"
   condition:
      ( 
         uint16(0) == 0x5a4d 
         or 1 of ($a*) 
      )
      and (
         1 of ($x*)
         or 3 of ($s*)
      )
}

rule APT_APT29_NOBELIUM_BoomBox_May21_2 {
   meta:
      description = "Detects BoomBox malware used by APT29 / NOBELIUM"
      author = "Florian Roth (Nextron Systems)"
      reference = "https://www.microsoft.com/security/blog/2021/05/28/breaking-down-nobeliums-latest-early-stage-toolset/"
      date = "2021-05-29"
      hash1 = "0acb884f2f4cfa75b726cb8290b20328c8ddbcd49f95a1d761b7d131b95bafec"
      hash2 = "8199f309478e8ed3f03f75e7574a3e9bce09b4423bd7eb08bb5bff03af2b7c27"
      hash3 = "cf1d992f776421f72eabc31d5afc2f2067ae856f1c9c1d6dc643a67cb9349d8c"
      id = "a4144c00-48b2-5520-b773-5d0a5de95fb1"
      category = "APT"
      malware_type = "Malware"
      security_level = "high"
   strings:
      $x1 = "\\Microsoft\\NativeCache\\NativeCacheSvc.dll" wide
      $x2 = "\\NativeCacheSvc.dll _configNativeCache" wide
      
      $a1 = "/content.dropboxapi.com" wide fullword
      
      $s1 = "rundll32.exe {0} {1}" wide fullword
      $s2 = "\\\\CertPKIProvider.dll" wide
      $s3 = "/tmp/readme.pdf" wide
      $s4 = "temp/[^\"]*)\"" wide fullword

      $op1 = { 00 78 00 2d 00 41 00 50 00 49 00 2d 00 41 00 72 00 67 00 01 2f 4f 00 72 00 }
      $op2 = { 25 72 98 01 00 70 6f 34 00 00 0a 25 6f 35 00 00 0a 72 71 02 00 70 72 }
      $op3 = { 4d 05 20 00 12 80 91 04 20 01 08 0e 04 20 00 12 }
   condition:
      uint16(0) == 0x5a4d and
      filesize < 40KB and
      3 of them or 4 of them
}
