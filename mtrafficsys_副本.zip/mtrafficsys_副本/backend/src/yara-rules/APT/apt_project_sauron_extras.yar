rule APT_Project_Sauron_Scripts {
	meta:
		description = "Detects scripts (mostly LUA) from Project Sauron report by Kaspersky"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		author = "Florian Roth (Nextron Systems)"
		reference = "https://goo.gl/eFoP4A"
		date = "2016-08-08"
		id = "575a6f1b-5a4d-5f81-b44a-b7025dbec2a5"
		category = "apt"
		malware_type = "spyware"
		security_level = "high"
	strings:
		$x1 = "local t = w.exec2str(\"regedit "
		$x2 = "local r = w.exec2str(\"cat"
		$x3 = "ap*.txt link*.txt node*.tun VirtualEncryptedNetwork.licence"
		$x4 = "move O FakeVirtualEncryptedNetwork.dll"
		$x5 = "sinfo | basex b 32url | dext l 30"
		$x6 = "w.exec2str(execStr)"
		$x7 = "netnfo irc | basex b 32url"
		$x8 = "w.exec(\"wfw status\")"
		$x9 = "exec(\"samdump\")"
		$x10 = "cat VirtualEncryptedNetwork.ini|grep"
		$x11 = "if string.lower(k) == \"securityproviders\" then"
		$x12 = "exec2str(\"plist b | grep netsvcs\")"
		$x14 = "SAURON_KBLOG_KEY ="
	condition:
		1 of them
}

rule HKTL_Dsniff {
   meta:
      description = "Detects Dsniff hack tool"
      author = "Florian Roth (Nextron Systems)"
      score = 55
      reference = "https://goo.gl/eFoP4A"
      date = "2019-02-19"
      id = "eb39185b-330f-5b93-ac58-0465e5767919"
	  category = "apt"
	  malware_type = "spyware"
	  security_level = "high"
   strings:
      $x1 = ".*account.*|.*acct.*|.*domain.*|.*login.*|.*member.*"
   condition:
      1 of them
}

rule APT_Project_Sauron_arping_module {
	meta:
		description = "Detects strings from arping module - Project Sauron report by Kaspersky"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		author = "Florian Roth (Nextron Systems)"
		reference = "https://goo.gl/eFoP4A"
		date = "2016-08-08"
		id = "42389511-de92-57cb-9dee-9f829fd5e55a"
		category = "apt"
		malware_type = "spyware"
		security_level = "high"
	strings:
		$s1 = "Resolve hosts that answer"
		$s2 = "Print only replying Ips"
		$s3 = "Do not display MAC addresses"
	condition:
		all of them
}

rule APT_Project_Sauron_kblogi_module {
	meta:
		description = "Detects strings from kblogi module - Project Sauron report by Kaspersky"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		author = "Florian Roth (Nextron Systems)"
		reference = "https://goo.gl/eFoP4A"
		date = "2016-08-08"
		id = "e1dd4d1a-1089-5897-8f4a-52c7068802fa"
		category = "apt"
		malware_type = "spyware"
		security_level = "high"
	strings:
		$x1 = "Inject using process name or pid. Default"
		$s2 = "Convert mode: Read log from file and convert to text"
		$s3 = "Maximum running time in seconds"
	condition:
		$x1 or 2 of them
}

rule APT_Project_Sauron_basex_module {
	meta:
		description = "Detects strings from basex module - Project Sauron report by Kaspersky"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		author = "Florian Roth (Nextron Systems)"
		reference = "https://goo.gl/eFoP4A"
		date = "2016-08-08"
		id = "51ef3826-af5c-562b-a1f8-3bf11532ac2d"
		category = "apt"
		malware_type = "spyware"
		security_level = "high"
	strings:
		$x1 = "64, 64url, 32, 32url or 16."
		$s2 = "Force decoding when input is invalid/corrupt"
		$s3 = "This cruft"
	condition:
		$x1 or 2 of them
}

rule APT_Project_Sauron_dext_module {
	meta:
		description = "Detects strings from dext module - Project Sauron report by Kaspersky"
		license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
		author = "Florian Roth (Nextron Systems)"
		reference = "https://goo.gl/eFoP4A"
		date = "2016-08-08"
		id = "d69373e0-d6ad-5475-8766-06e865620ed8"
		category = "apt"
		malware_type = "spyware"
		security_level = "high"
	strings:
		$x1 = "Assemble rows of DNS names back to a single string of data"
		$x2 = "removes checks of DNS names and lengths (during split)"
		$x3 = "Randomize data lengths (length/2 to length)"
		$x4 = "This cruft"
	condition:
		2 of them
}

/*
	Yara Rule Set
	Author: FLorian Roth
	Date: 2016-08-09
	Identifier: Project Sauron - my own ruleset
*/