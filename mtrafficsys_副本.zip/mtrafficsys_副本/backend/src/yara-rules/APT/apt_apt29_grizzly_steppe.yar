/*
   Yara Rule Set
   Author: Florian Roth
   Date: 2016-12-29
   Identifier: GRIZZLY STEPPE
*/

/* Rule Set ----------------------------------------------------------------- */

rule PAS_TOOL_PHP_WEB_KIT_mod {
   meta:
      description = "Detects PAS Tool PHP Web Kit"
      reference = "https://www.us-cert.gov/security-publications/GRIZZLY-STEPPE-Russian-Malicious-Cyber-Activity"
      author = "US CERT - modified by Florian Roth due to performance reasons"
      date = "2016/12/29"
      id = "6bc75e44-7784-5e48-9bbc-052d84ebee83"
      category = "APT"
      malware_type = "WebShell"
      security_level = "high"
   strings:
      $php = "<?php"
      $base64decode1 = "='base'.("
      $strreplace = "str_replace(\"\\n\", ''"
      $md5 = ".substr(md5(strrev("
      $gzinflate = "gzinflate"
      $cookie = "_COOKIE"
      $isset = "isset"
   condition:
      uint32(0) == 0x68703f3c and
      $php at 0 and
      (filesize > 10KB and filesize < 30KB) and
      #cookie == 2 and
      #isset == 3 and
      all of them
}

rule WebShell_PHP_Web_Kit_v3 {
   meta:
      description = "Detects PAS Tool PHP Web Kit"
      reference = "https://github.com/wordfence/grizzly"
      license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
      author = "Florian Roth (Nextron Systems)"
      date = "2016/01/01"
      id = "dc5fa2c9-3e1e-594d-be4f-141e1f4915f1"
      category = "APT"
      malware_type = "WebShell"
      security_level = "high"
   strings:
      $php = "<?php $"
      $php2 = "@assert(base64_decode($_REQUEST["

      $s1 = "(str_replace(\"\\n\", '', '"
      $s2 = "(strrev($" ascii
      $s3 = "de'.'code';" ascii
   condition:
      ( ( uint32(0) == 0x68703f3c and $php at 0 ) or $php2 ) and
      filesize > 8KB and filesize < 100KB and
      all of ($s*)
}

rule WebShell_PHP_Web_Kit_v4 {
   meta:
      description = "Detects PAS Tool PHP Web Kit"
      reference = "https://github.com/wordfence/grizzly"
      license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
      author = "Florian Roth (Nextron Systems)"
      date = "2016/01/01"
      id = "a5f915cd-b9c5-5cd3-b0a2-c15f6124737a"
      category = "APT"
      malware_type = "WebShell"
      security_level = "high"
   strings:
      $php = "<?php $"

      $s1 = "(StR_ReplAcE(\"\\n\",'',"
      $s2 = ";if(PHP_VERSION<'5'){" ascii
      $s3 = "=SuBstr_rePlACe(" ascii
   condition:
      uint32(0) == 0x68703f3c and 
      $php at 0 and
      filesize > 8KB and filesize < 100KB and
      2 of ($s*)
}



rule APT_APT29_wellmess_dotnet_unique_strings {
   meta:
      description = "Rule to detect WellMess .NET samples based on unique strings and function/variable names"
      author = "NCSC"
      reference = "https://www.ncsc.gov.uk/news/advisory-apt29-targets-covid-19-vaccine-development"
      hash = "2285a264ffab59ab5a1eb4e2b9bcab9baf26750b6c551ee3094af56a4442ac41"
      id = "7a058ec7-f795-5226-b511-ff469a969ee6"
      category = "APT"
      malware_type = "Malware"
      security_level = "high"
   strings:
      $s1 = "HealthInterval" wide
      $s2 = "Hello from Proxy" wide 
      $s3 = "Start bot:" wide
      $s4 = "FromNormalToBase64" ascii 
      $s5 = "FromBase64ToNormal" ascii 
      $s6 = "WellMess" ascii
   condition:
      uint16(0) == 0x5a4d and uint16(uint16(0x3c)) == 0x4550 and 3 of them
}

rule APT_APT29_sorefang_command_elem_cookie_ga_boundary_string { 
   meta:
      description = "Rule to detect SoreFang based on scheduled task element and Cookie header/boundary strings"
      author = "NCSC"
      reference = "https://www.ncsc.gov.uk/news/advisory-apt29-targets-covid-19-vaccine-development"
      hash = "58d8e65976b53b77645c248bfa18c3b87a6ecfb02f306fe6ba4944db96a5ede2"
      id = "3c6ffbad-9b39-5518-aa66-d76531ddb9ea"
      category = "APT"
      malware_type = "Malware"
      security_level = "high"
   strings:
      $ = "<Command>" wide
      $ = "Cookie:_ga="
      $ = "------974767299852498929531610575"
   condition:
      (uint16(0) == 0x5A4D and uint16(uint32(0x3c)) == 0x4550) 
      and 2 of them 
}
