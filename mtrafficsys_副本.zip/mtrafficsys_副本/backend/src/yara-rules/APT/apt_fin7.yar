/*
   Yara Rule Set
   Author: Florian Roth
   Date: 2018-08-01
   Identifier: FIN7
   Reference: https://www.fireeye.com/blog/threat-research/2018/08/fin7-pursuing-an-enigmatic-and-evasive-global-criminal-operation.html
*/

import "pe"

/* Rule Set ----------------------------------------------------------------- */

rule APT_FIN7_MalDoc_Aug18_1 {
   meta:
      description = "Detects malicious Doc from FIN7 campaign"
      license = "Detection Rule License 1.1 https://github.com/Neo23x0/signature-base/blob/master/LICENSE"
      author = "Florian Roth (Nextron Systems)"
      reference = "https://www.fireeye.com/blog/threat-research/2018/08/fin7-pursuing-an-enigmatic-and-evasive-global-criminal-operation.html"
      date = "2018-08-01"
      hash1 = "9c12591c850a2d5355be0ed9b3891ccb3f42e37eaf979ae545f2f008b5d124d6"
      id = "f3c430e0-be9a-5c3f-9378-a20ef0492afb"
      category = "APT"
      malware_type = "FIN7"
      security_level = "high"
   strings:
      $s1 = "<photoshop:LayerText>If this document was downloaded from your email, please click  \"Enable editing\" from the yellow bar above" ascii
   condition:
      filesize < 800KB and 1 of them
}
rule SUSP_OBFUSC_JS_Sept21_2 {
   meta:
      description = "Detects JavaScript obfuscation as used in MalDocs by FIN7 group"
      author = "Florian Roth (Nextron Systems)"
      reference = "https://www.anomali.com/blog/cybercrime-group-fin7-using-windows-11-alpha-themed-docs-to-drop-javascript-backdoor"
      date = "2021-09-07"
      score = 65
      id = "5ab9cd60-077c-5066-bd2f-8da261aae1e0"
      category = "APT"
      malware_type = "FIN7"
      security_level = "high"
   strings:
      $s1 = "=new RegExp(String.fromCharCode(" ascii
      $s2 = ".charCodeAt(" ascii
      $s3 = ".substr(0, " ascii
      $s4 = "var shell = new ActiveXObject(" ascii
      $s5 = "= new Date().getUTCMilliseconds();" ascii
      $s6 = ".deleteFile(WScript.ScriptFullName);" ascii
   condition:
      filesize < 6000KB
      and ( 
         4 of them
      )
}
