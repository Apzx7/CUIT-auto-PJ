rule golang_david_CSC846 {

	meta:
		description = "CSC-846 Golang"
		author = "David"
		date = "2024-12-09"
		yarahub_reference_md5 = "7facb5878484d8d9973a7fba2da84de7"
		yarahub_license = "CC0 1.0"
		yarahub_uuid = "721c76dd-8b06-49f7-90a6-a627590d65ca"
		yarahub_rule_matching_tlp = "TLP:WHITE"
		yarahub_rule_sharing_tlp = "TLP:WHITE"
	
	condition:
		/go\.buildid/ 
	
}