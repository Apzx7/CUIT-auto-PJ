/*
   Yara Rule Set
   Author: (see the author field in the rules)
   Date: 2017-10-20
   Sync Date: 2017-10-20
   Identifier: Binary Alert Rules
   Reference: https://github.com/airbnb/binaryalert

   Note: Applied some modifications to avoid false positives during full disk file system scans
*/

/* ./rules/public/hacktool/macos */

rule hacktool_macos_manwhoami_icloudcontacts
{
    meta:
        description = "Pulls iCloud Contacts for an account. No dependencies. No user notification."
        reference = "https://github.com/manwhoami/iCloudContacts"
        author = "@mimeframe"
        category = "hacktool"
        malware_type = "macos"
        security_level = "high"
    strings:
        $a1 = "https://setup.icloud.com/setup/authenticate/" wide ascii
        $a2 = "https://p04-contacts.icloud.com/" wide ascii
        $a3 = "HTTP Error 401: Unauthorized. Are you sure the credentials are correct?" wide ascii
        $a4 = "HTTP Error 404: URL not found. Did you enter a username?" wide ascii
    condition:
        3 of ($a*)
}

rule hacktool_multi_jtesta_ssh_mitm
{
    meta:
        description = "intercepts ssh connections to capture credentials"
        reference = "https://github.com/jtesta/ssh-mitm"
        author = "@fusionrace"
        category = "hacktool"
        malware_type = "ssh-mitm"
        security_level = "high"
    strings:
        $a1 = "INTERCEPTED PASSWORD:" wide ascii
        $a2 = "more sshbuf problems." wide ascii
    condition:
        all of ($a*)
}

rule hacktool_multi_ncc_ABPTTS
{
    meta:
        description = "Allows for TCP tunneling over HTTP"
        reference = "https://github.com/nccgroup/ABPTTS"
        author = "@mimeframe"
        category = "hacktool"
        malware_type = "tcp-tunneling"
        security_level = "high"
    strings:
        $s1 = "---===[[[ A Black Path Toward The Sun ]]]===---" ascii wide
        $s2 = "https://vulnerableserver/EStatus/" ascii wide
        $s3 = "Error: no ABPTTS forwarding URL was specified. This utility will now exit." ascii wide
        // access key
        $s4 = "tQgGur6TFdW9YMbiyuaj9g6yBJb2tCbcgrEq" fullword ascii wide
        // encryption key
        $s5 = "63688c4f211155c76f2948ba21ebaf83" fullword ascii wide
        // log file
        $s6 = "ABPTTSClient-log.txt" fullword ascii wide
    condition:
        any of them
}

rule hacktool_multi_pyrasite_py
{
    meta:
        description = "A tool for injecting arbitrary code into running Python processes."
        reference = "https://github.com/lmacken/pyrasite"
        author = "@fusionrace"
        category = "hacktool"
        malware_type = "python-injector"
        security_level = "high"
    strings:
        $s1 = "WARNING: ptrace is disabled. Injection will not work." fullword ascii wide
        $s2 = "A payload that connects to a given host:port and receives commands" fullword ascii wide
        $s3 = "A reverse Python connection payload." fullword ascii wide
        $s4 = "pyrasite - inject code into a running python process" fullword ascii wide
        $s5 = "The ID of the process to inject code into" fullword ascii wide
        $s6 = "This file is part of pyrasite." fullword ascii wide
        $s7 = "https://github.com/lmacken/pyrasite" fullword ascii wide
        $s8 = "Setup a communication socket with the process by injecting" fullword ascii wide
        $s9 = "a reverse subshell and having it connect back to us." fullword ascii wide
        $s10 = "Write out a reverse python connection payload with a custom port" fullword ascii wide
        $s11 = "Wait for the injected payload to connect back to us" fullword ascii wide
        $s12 = "PyrasiteIPC" fullword ascii wide
        $s13 = "A reverse Python shell that behaves like Python interactive interpreter." fullword ascii wide
        $s14 = "pyrasite cannot establish reverse" fullword ascii wide
    condition:
        any of them
}

/* ./rules/public/hacktool/windows */

rule hacktool_windows_mimikatz_copywrite
{
    meta:
        description = "Mimikatz credential dump tool: Author copywrite"
        reference = "https://github.com/gentilkiwi/mimikatz"
        author = "@fusionrace"
        md5_1 = "0c87c0ca04f0ab626b5137409dded15ac66c058be6df09e22a636cc2bcb021b8"
        md5_2 = "0c91f4ca25aedf306d68edaea63b84efec0385321eacf25419a3050f2394ee3b"
        md5_3 = "0fee62bae204cf89d954d2cbf82a76b771744b981aef4c651caab43436b5a143"
        md5_4 = "004c07dcd04b4e81f73aacd99c7351337f894e4dac6c91dcfaadb4a1510a967c"
        md5_5 = "09c542ff784bf98b2c4899900d4e699c5b2e2619a4c5eff68f6add14c74444ca"
        md5_6 = "09054be3cc568f57321be32e769ae3ccaf21653e5d1e3db85b5af4421c200669"
        category = "hacktool"
        malware_type = "mimikatz"
        security_level = "high"
    strings:
        $s1 = "Kiwi en C" fullword ascii wide
        $s2 = "Benjamin DELPY `gentilkiwi`" fullword ascii wide
        $s3 = "http://blog.gentilkiwi.com/mimikatz" fullword ascii wide
        $s4 = "Build with love for POC only" fullword ascii wide
        $s5 = "gentilkiwi (Benjamin DELPY)" fullword wide
        $s6 = "KiwiSSP" fullword wide
        $s7 = "Kiwi Security Support Provider" fullword wide
        $s8 = "kiwi flavor !" fullword wide
    condition:
        uint16(0) == 0x5a4d and filesize < 800KB and /* Added by Florian Roth to avoid false positives */
        any of them
}
