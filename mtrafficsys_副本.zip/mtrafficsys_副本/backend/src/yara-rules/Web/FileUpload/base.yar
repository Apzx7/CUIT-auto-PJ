rule web_malicious_file_upload {
    meta:
        description = "Detects suspicious file upload content"
        severity_level = "high"
        category = "web"
		malware_type = "webshell"
        protocol = "HTTP"
    strings:
        // PHP webshell markers
        $php1 = /<\?php\s+(eval|system|exec|shell_exec|passthru)/
        $php2 = /@error_reporting\(0\);/
        $php3a = /base64_decode\(/
        $php3b = /eval\(/

        // JSP shell
        $jsp1 = /<%@ page import="java.io.*"%>/
        $jsp2 = /Runtime\.getRuntime\(\)\.exec\(/ 

        // ASPX
        $aspx1a = /<%@ Page Language="C#"%>/
        $aspx1b = /System\.Diagnostics\.Process\.Start\(/
    condition:
        any of ($php1, $php2, $jsp1, $jsp2)
        or (
            #php3a > 0 and #php3b > 0 and
            for any i in (1..#php3a) : (
                for any j in (1..#php3b) : (
                    @php3b[j] >= @php3a[i] and (@php3b[j] - @php3a[i]) <= 50
                )
            )
        )
        or (
            #aspx1a > 0 and #aspx1b > 0 and
            for any i in (1..#aspx1a) : (
                for any j in (1..#aspx1b) : (
                    @aspx1b[j] >= @aspx1a[i] and (@aspx1b[j] - @aspx1a[i]) <= 100
                )
            )
        )
}