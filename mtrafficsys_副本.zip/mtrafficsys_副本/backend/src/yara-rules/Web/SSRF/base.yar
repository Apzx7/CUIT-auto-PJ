rule web_ssrf_indicators {
    meta:
        description = "Detects SSRF attempts via URL parameters"
        severity_level = "high"
        category = "web"
        malware_type = "ssrf"
        protocol = "HTTP"
    strings:
        $s4 = /url=dict:\/\//i
        $s5 = /url=gopher:\/\//i
    condition:
        any of them
}