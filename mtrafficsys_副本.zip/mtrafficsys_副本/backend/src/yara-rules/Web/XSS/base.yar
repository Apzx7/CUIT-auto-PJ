rule web_xss_reflected {
    meta:
        description = "Detects reflected XSS payloads"
        severity_level = "medium"
        category = "web"
        protocol = "HTTP"
		malware_type = "xss"
    strings:
        $s1 = /<script>.*<\/script>/i
        $s2 = /javascript:/i
        $s3 = /onerror\s*=/i
        $s4 = /<img.*onload=/i
        $s5 = /<svg.*onload=/i
        $s6 = /%3Cscript%3E/  // URL-encoded
    condition:
        any of them
}