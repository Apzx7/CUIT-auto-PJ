rule web_sql_injection_union_based {
    meta:
        description = "Detects UNION-based SQL injection patterns"
        severity_level = "high"
        category = "web"
		malware_type = "sql_injection"
        protocol = "HTTP"
    strings:
        $s1 = /UNION\s+SELECT/i
        $s2 = /SELECT\s+\*\s+FROM/i
        $s3 = /UNION\s+ALL\s+SELECT/i
    condition:
        any of them
}

rule web_sql_injection_boolean_blind {
    meta:
        description = "Detects boolean-based blind SQL injection"
        severity_level = "medium"
        category = "web"
        protocol = "HTTP"
		malware_type = "sql_injection"
    strings:
        $s1 = /' OR '1'='1/
        $s2 = /" OR "1"="1/
        $s3 = /' OR 1=1--/
        $s4 = /admin'--/
        $s5 = /admin"--/
        $s6 = /admin' #/
        $s7 = /admin" #/ 
    condition:
        any of them
}

rule web_sql_injection_time_based {
    meta:
        description = "Detects time-based SQL injection patterns"
        severity_level = "high"
        category = "web"
        protocol = "HTTP"
        malware_type = "sql_injection"
    strings:
        $s1 = /SLEEP\(\d+\)/i
        $s2 = /WAITFOR\s+DELAY\s+'\d+:\d+:\d+'/i
    condition:
        any of them
}

rule web_sql_injection_error_based {
    meta:
        description = "Detects error-based SQL injection patterns"
        severity_level = "medium"
        category = "web"
        protocol = "HTTP"
        malware_type = "sql_injection"
    strings:
        $s1 = /' AND (SELECT|EXTRACTVALUE|UPDATEXML|BENCHMARK)\(/i
        $s2 = /" AND (SELECT|EXTRACTVALUE|UPDATEXML|BENCHMARK)\(/i
    condition:
        any of them
}

rule web_sql_injection_stacked_queries {
    meta:
        description = "Detects stacked query SQL injection patterns"
        severity_level = "high"
        category = "web"
        protocol = "HTTP"
        malware_type = "sql_injection"
    strings:
        $s1 = /;.*(SELECT|INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|EXEC|EXECUTE)\s/i
    condition:
        $s1
}

rule web_sql_injection_generic {
    meta:
        description = "Detects generic SQL injection patterns"
        severity_level = "medium"
        category = "web"
        protocol = "HTTP"
        malware_type = "sql_injection"
    strings:
        $s1 = /('|"|`)\s*(OR|AND)\s*('|"|`)?\s*\d+\s*=\s*\d+/i
        $s2 = /('|"|`)\s*(OR|AND)\s*('|"|`)?\s*['"]?[\w\s]+['"]?\s*=\s*['"]?[\w\s]+['"]?/i
    condition:
        any of them
}

rule web_sql_injection_function {
    meta:
        description = "Detects SQL injection patterns involving SQL functions"
        severity_level = "medium"
        category = "web"
        protocol = "HTTP"
        malware_type = "sql_injection"
    strings:
        $s1 = "database("
        $s2 = "version("
        $s3 = "user("
        $s4 = "concat("
        $s5 = "group_concat("
        $s6 = "load_file("
        $s7 = "benchmark("
        $s8 = "if("
        $s9 = "rand("
    condition:
        any of them
}

rule web_sql_injection_tables {
    meta:
        description = "Detects SQL injection patterns involving table enumeration"
        severity_level = "medium"
        category = "web"
        protocol = "HTTP"
        malware_type = "sql_injection"
    strings:
        $s1 = /\s+information_schema\.tables/i
        $s2 = /\s+sys\.objects/i
    condition:
        any of them
}