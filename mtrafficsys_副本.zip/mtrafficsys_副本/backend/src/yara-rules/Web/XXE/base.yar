rule web_xxe_injection {
    meta:
        description = "Detects XXE attack patterns in XML payloads"
        severity_level = "high"
        category = "web"
        malware_type = "xxe"
        protocol = "HTTP"
    strings:
        $s1 = /<!ENTITY\s+%?\s+\w+\s+SYSTEM\s+"file:\/\// 
        $s2 = /<!DOCTYPE.*\[<!ENTITY/
        $s3 = /<!ENTITY\s+\w+\s+PUBLIC\s+"-\/\/ETC\/PASSWD"/
        $s4 = /<\?xml version="1.0"\?>\s*<!DOCTYPE/
    condition:
        any of them
}