from contextlib import asynccontextmanager
from typing import AsyncIterator
from fastapi import FastAPI
from src.core.settings import Base, MYSQL_CONF
from src.core.storage.mysql_control import MysqlSimClass
from src.core.rules.init_rules import YaraRulesInitializer  # type: ignore
import pymysql


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    try:
        conn = pymysql.connect( 
            host=MYSQL_CONF['host'],  # type: ignore
            user=MYSQL_CONF['user'],  # type: ignore
            password=MYSQL_CONF['passwd'],  # type: ignore
            port=MYSQL_CONF['port']  # type: ignore
        )  # type: ignore
        try:
            with conn.cursor() as cursor:
                cursor.execute(
                    f"CREATE DATABASE IF NOT EXISTS `{MYSQL_CONF['db']}`"
                )
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass

    engine = MysqlSimClass().get_engine()
    Base.metadata.create_all(bind=engine)
    YaraRulesInitializer().init_rules()
    yield
    try:
        engine.dispose()
    except Exception:
        pass