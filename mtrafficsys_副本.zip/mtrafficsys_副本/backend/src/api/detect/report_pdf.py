from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from src.core.report import ReportGenerator  # type: ignore
from src.core.logger.log_manager import LogManager

router = APIRouter(tags=["detect"])
logger = LogManager()


class ResponseModel(BaseModel):
	status: str
	code: int
	file_path: Optional[str] = None
	message: str


@router.get('/report/pdf/{file_id}', response_model=ResponseModel)
def export_report_pdf(file_id: str):
	actor = 'ReportExport'
	try:
		report_path = ReportGenerator().generate_report(file_id)
		if not report_path:
			logger.add_business_log(
				category='report export',
				actor=actor,
				action='export report pdf',
				result='failed',
				detail=f'report generation failed for file_id: {file_id}'
			)
			return ResponseModel(status='failed', code=1,
								 file_path=None,
								 message='report generation failed')

		logger.add_business_log(
			category='report export',
			actor=actor,
			action='export report pdf',
			result='success',
			detail=f'report generated: {report_path}'
		)
		return ResponseModel(status='success', code=0,
							 file_path=report_path,
							 message='report generated')
	except Exception as e:
		logger.add_business_log(
			category='report export',
			actor=actor,
			action='export report pdf',
			result='failed',
			detail=f'report generation failed: {e}'
		)
		return ResponseModel(status='failed', code=1,
							 file_path=None,
							 message=f'report generation failed: {e}')
