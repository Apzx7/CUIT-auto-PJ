from fastapi import APIRouter
from typing import Optional
from src.core.detection.scaner import FileDetecter
from src.core.filter.detect_file_filter import FileSizeHandler  # type: ignore
from src.core.logger.log_manager import LogManager
from src.core.data.manager.shower import ShowUploadFile
from src.core.detection.save_detection import SaveDetection
from src.core.detection.ai_detect import AiDetect
from pydantic import BaseModel
from datetime import datetime

router = APIRouter(tags=["detect"])
logger = LogManager()


class ResponseModel(BaseModel):
    status: str
    code: int
    message: Optional[str] = None



@router.get('/detect/file/{file_id}', response_model=ResponseModel)
def detect_file(file_id: str):
    '''
    user can detect file by this api
    return: match_infos(a list of dict which contains
    rule_name, match, description)
    '''
    actor = "FileDetectEndpoint"
    shower = ShowUploadFile()
    file_path = shower._get_file_path_by_fid(file_id)
    file_name = shower._get_file_name_by_fid(file_id)
    if not file_path:
        logger.add_business_log(
            category='file detect',
            actor=actor,
            action='detect file by yara rules',
            result='failed',
            detail=f'file not found by file_id: {file_id}'
        )
        return ResponseModel(status='failed', code=1,
                             message='file not found')
    filter = FileSizeHandler()
    if not filter.filter_file_size(file_path):
        max_size = filter.show_max_size_for_human()
        logger.add_business_log(
            category='file detect',
            actor=actor,
            action='detect file by yara rules',
            result='failed',
            detail=f'file size over limit({max_size})'
        )
        return ResponseModel(status='failed', code=1,
                             message=f'file size over limit({max_size})')
    if shower._check_file_is_detected(file_id):
        logger.add_business_log(
            category='file detect',
            actor=actor,
            action='detect file by yara rules',
            result='failed',
            detail=f'{file_name} has been detected before'
        )
        return ResponseModel(status='failed', code=1,
                             message=f'{file_name} has been detected before, no need to detect again')  # noqa
    try:
        t_start = datetime.now()
        match_infos = FileDetecter().parse_scan_results(file_path)
        t_end = datetime.now()
        try:
            t_cost = (t_end - t_start).total_seconds()
            match_count = len(match_infos)
            ai_result = None
            try:
                ai_payload = {
                    "file_id": file_id,
                    "yara_matches": match_infos,
                    "match_count": match_count,
                }
                ai_prompt = AiDetect().payload_to_prompt(ai_payload)
                print("ai_prompt:", ai_prompt)
                ai_result = AiDetect().detect(ai_payload)
            except Exception as e:
                logger.add_business_log(
                    category='file detect',
                    actor=actor,
                    action='ai analysis on yara matches',
                    result='failed',
                    detail=f'ai detect failed: {str(e)}'
                )
            # save result to database
            result_payload = {
                "yara_matches": match_infos,
                "ai_detection": ai_result,
            }
            SaveDetection().save_result(file_id=file_id,
                                        result=result_payload,
                                        cost_time=t_cost,
                                        matched_count=match_count)
            # update the file record status
            shower._update_file_is_detected(file_id)
            detected_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            shower._update_file_detected_at(file_id, detected_date)
        except Exception as e:
            logger.add_business_log(
                category='file detect',
                actor=actor,
                action='detect file by yara rules',
                result='failed',
                detail=f'error saving detection result: {str(e)}'
            )
        return ResponseModel(status='success', code=0,
                             message='file detected successfully')
    except Exception as e:
        logger.add_business_log(
            category='file detect',
            actor=actor,
            action='detect file by yara rules',
            result='failed',
            detail=f'detect file failed: {str(e)}'
        )
        return ResponseModel(status='failed', code=1,
                             message='detect file failed')
