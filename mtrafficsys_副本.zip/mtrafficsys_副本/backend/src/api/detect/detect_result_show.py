from fastapi import APIRouter
from typing import Optional
from pydantic import BaseModel

from src.core.feature.search_scan_result import SearchScanResultFeature
from src.core.logger.log_manager import LogManager
from typing import Any

router = APIRouter(tags=["detect"])
logger = LogManager()
actor = "DetectResultShowAPI"


class ResultQueryParams(BaseModel):
    file_id: Optional[str]
    start_time: Optional[str]
    end_time: Optional[str]


class ResponseModel(BaseModel):
    status: str
    code: int
    data: Any


def _parse_iso_optional(s: Optional[str]) -> Optional[str]:
    if not s:
        return None
    return s


@router.get("/detect/result/search/{file_id}", response_model=ResponseModel)
def query_detection_results(file_id: str):
    """Query DetectionResult by optional time range and file id."""
    feature = SearchScanResultFeature()
    try:
        data = feature.query_detection_results_by_fid(
            file_id=file_id,
        )
        logger.add_business_log(
            category="DetectResultShowAPI",
            actor=actor,
            action="Query detection results by fid",
            detail=f"Queried results for file_id={file_id}",
            result="Success",
        )
        return ResponseModel(status="success", code=0, data=data)
    except Exception as e:
        logger.add_business_log(
            category="DetectResultShowAPI",
            actor=actor,
            action="Query detection results by fid",
            detail=f"Query failed: {e}",
            result="Failure",
        )
        return ResponseModel(status="failed", code=1, data=None)
