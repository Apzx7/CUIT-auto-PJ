from fastapi import APIRouter
from fastapi.encoders import jsonable_encoder
from src.core.feature import query_traffic_feature  # type: ignore
from src.core.filter import protocol_filter  # type: ignore
from pydantic import BaseModel

router = APIRouter(tags=["extract"])


class TrafficPacket(BaseModel):
    protocol: str = 'dns'
    type: str = 'request'
    file_id: str | None = None


class ResponseModel(BaseModel):
    status: str
    code: int
    data: list | None = None
    message: str


@router.post('/traffic/feature/show/')
def read_traffic_feature(item: TrafficPacket):
    '''
    read traffic feature(dns, tcp/udp, icmp etc) from mysql
    :return query result from mysql
    '''
    p_filter = protocol_filter.ProtocolHandler()
    protocol = item.protocol
    packet_type = item.type
    type_for_protocol = p_filter.protocol_type_map.get(protocol.lower(), [])
    error_detail = f"{item.protocol} only support type: {type_for_protocol}"
    if not p_filter.filter_protocol_type(protocol, packet_type):
        return ResponseModel(status='failed', code=1,
                             data=None,
                             message=error_detail)
    q_feature = query_traffic_feature.QueryFeature()
    if item.file_id:
        datas = q_feature.fetch_traffic_by_file(protocol, packet_type,
                                                item.file_id)
        payload = jsonable_encoder(datas, sqlalchemy_safe=True)
        return ResponseModel(status='success', code=0,
                             data=payload,
                             message=f'query {item.file_id} {protocol} {packet_type} success')
    datas = q_feature.fetch_traffic(protocol, packet_type)
    payload = jsonable_encoder(datas, sqlalchemy_safe=True)
    return ResponseModel(status='success', code=0,
                         data=payload,
                         message=f'query {protocol} {packet_type} success')