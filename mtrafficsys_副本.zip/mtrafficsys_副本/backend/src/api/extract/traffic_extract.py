from fastapi import APIRouter
from src.core.data.preprocessor.saver import FeatureSaver  # type: ignore
from src.core.data.manager.shower import ShowUploadFile
from src.core.logger.log_manager import LogManager
from pydantic import BaseModel
from datetime import datetime

router = APIRouter(tags=["extract"])
logger = LogManager()


class ResponseModel(BaseModel):
    status: str
    code: int
    message: str


@router.get('/traffic/feature/extract/{file_id}', response_model=ResponseModel)
def extract_feature_from_pcap(file_id: str):
    '''
    extract pcap file features and insert them into database
    '''
    actor = "TrafficFeatureExtractEndpoint"
    shower = ShowUploadFile()
    file_path = shower._get_file_path_by_fid(file_id)
    file_name = shower._get_file_name_by_fid(file_id)
    if not file_path:
        logger.add_business_log(
            category='extract traffic',
            actor=actor,
            action='extract traffic feature from pcap',
            result='failed',
            detail=f'file not found by file_id: {file_id}'
        )
        return ResponseModel(status='failed', code=1,
                             message='file not found')
    if shower._check_file_is_extracted(file_id):
        logger.add_business_log(
            category='extract traffic',
            actor=actor,
            action='extract traffic feature from pcap',
            result='failed',
            detail='file has been extracted before, no need to extract again'
        )
        return ResponseModel(status='failed', code=1,
                             message='file has been extracted before, no need to extract again')  # noqa
    try:
        FeatureSaver(pcap_file_path=file_path,
                 uploaded_file_fid=file_id).insert_traffic()
        # update the file record status
        shower._update_file_is_extracted(file_id)
        extracted_date = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        shower._update_file_extracted_at(file_id, extracted_date)
        logger.add_business_log(
            category='extract traffic',
            actor=actor,
            action='extract traffic feature from pcap',
            result='success',
            detail=f'{file_name} traffic feature extraction successfully!'
        )
        return ResponseModel(status='success', code=0,
                             message='traffic feature extraction successfully')
    except Exception as e:
        logger.add_business_log(
            category='extract traffic',
            actor=actor,
            action='extract traffic feature from pcap',
            result='failed',
            detail=f'traffic feature extraction failed: {str(e)}'
        )
        return ResponseModel(status='failed', code=1,
                             message='traffic feature extraction failed')
