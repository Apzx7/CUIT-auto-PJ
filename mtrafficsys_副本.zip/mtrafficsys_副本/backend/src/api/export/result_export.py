from fastapi import APIRouter
from pydantic import BaseModel

from src.core.feature.export_scan_result import ExportScanResult
from src.core.logger.log_manager import LogManager


router = APIRouter(tags=["export"])
logger = LogManager()


class ResponseModel(BaseModel):
    status: str
    status_code: int
    message: str


@router.get("/result/export/{file_id}", response_model=ResponseModel)
def export_scan_result(file_id: str):
    """Export detection result of a given file_id to CSV."""
    if not file_id:
        return ResponseModel(
            status="failed",
            status_code=1,
            message="file_id is required",
        )

    exporter = ExportScanResult()
    export_ret = exporter.export_result_to_json(file_id=file_id)
    if not export_ret:
        return ResponseModel(
            status="failed",
            status_code=1,
            message="export failed",
        )

    file_name, file_uuid = export_ret
    logger.add_business_log(
        category="DetectionResultExport",
        actor="ResultExportAPI",
        action="export detection result",
        detail=f"Exported detection result for {file_id} to {file_name}.",
        result="success",
    )
    return ResponseModel(
        status="success",
        status_code=0,
        message=f"exported {file_name} successfully, file_id: {file_uuid}",
    )
