from src.core.export.shower import ShowExportedFile
from fastapi import APIRouter
from src.core.logger.log_manager import LogManager
from pydantic import BaseModel
from typing import Optional, List, Dict


router = APIRouter(tags=["export"])
logger = LogManager()


class ResponseModel(BaseModel):
    status: str
    code: int
    data: Optional[List[Dict]] = None
    message: Optional[str] = None


@router.get('/exported/files/show/', response_model=ResponseModel)
def show_exported_files():
    '''
    show all exported file records
    '''
    shower = ShowExportedFile()
    actor = "ShowExportedFilesEndpoint"
    records = shower.get_all_records()
    if records is None:
        logger.add_business_log(
            category='show exported files',
            actor=actor,
            action='show exported files',
            result='failed',
            detail='no exported files found'
        )
        return ResponseModel(status='failed',
                             code=1,
                             data=None,
                             message='no exported files found')
    return ResponseModel(status='success',
                         code=0,
                         data=records,
                         message='exported files retrieved successfully')
