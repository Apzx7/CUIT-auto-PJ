from fastapi import APIRouter
from src.core.feature.traffic_export import Pcap2Others  # type: ignore
from src.core.filter import protocol_filter  # type:ignore
from src.core.logger.log_manager import LogManager
from pydantic import BaseModel

router = APIRouter(tags=["export"])
logger = LogManager()


class TrafficPacketExport(BaseModel):
    protocol: str
    type: str = 'request'
    file_id: str | None = None


class ResponseModel(BaseModel):
    status: str
    status_code: int
    message: str


@router.post('/traffic/feature/export/', response_model=ResponseModel)
def traffic_export(item: TrafficPacketExport):
    '''
    export special protocol traffic to csv/xlsx file
    '''
    actor = 'TrafficFeatureExport'
    p_filter = protocol_filter.ProtocolHandler()
    packet_type = item.type
    protocol = item.protocol
    error_detail = f"{item.protocol} only support type: {p_filter.protocol_type_map.get(protocol.lower(), [])}"  # noqa
    if not p_filter.filter_protocol_type(protocol, packet_type):
        return ResponseModel(status='failed', status_code=1,
                             message=error_detail)
    p2o = Pcap2Others()
    file_info = p2o.export_traffic(protocol, packet_type, item.file_id)
    if not file_info:
        return ResponseModel(status='failed', status_code=1,
                             message='export failed')
    file_name = file_info[0]
    file_id = file_info[1]
    logger.add_business_log(
        category='traffic feature export',
        actor=actor,
        action='export traffic feature',
        detail=f'export {protocol} {packet_type} to {file_name}.csv successfully!',  # noqa
        result='success'
    )
    return ResponseModel(status='success',
                         status_code=0,
                         message=f'exported {file_name} successfully, file_id: {file_id}')  # noqa