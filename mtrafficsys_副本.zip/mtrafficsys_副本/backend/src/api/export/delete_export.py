from src.core.export.deleter import DeleteExportedFile
from fastapi import APIRouter
from src.core.logger.log_manager import LogManager
from pydantic import BaseModel
from typing import Optional

router = APIRouter(tags=["export"])
logger = LogManager()


class ResponseModel(BaseModel):
    status: str
    code: int
    message: Optional[str] = None


@router.get('/exported/file/delete/{fid}', response_model=ResponseModel)
def delete_exported_file(fid: str):
    '''
    delete exported file by file id
    '''
    deleter = DeleteExportedFile()
    actor = "DeleteExportedFileEndpoint"
    if not deleter.delete_file_by_fid(fid):
        logger.add_business_log(
            category='delete exported file',
            actor=actor,
            action='delete exported file on disk',
            result='failed',
            detail=f'failed to delete exported file with fid: {fid}'
        )
        return ResponseModel(status='failed',
                             code=1,
                             message='failed to delete exported file')
    if not deleter.delete_record_by_fid(fid):
        logger.add_business_log(
            category='delete exported file',
            actor=actor,
            action='delete exported file record from database',
            result='failed',
            detail=f'failed to delete exported file with fid: {fid}'
        )
        return ResponseModel(status='failed',
                             code=1,
                             message='failed to delete exported file')
    return ResponseModel(status='success',
                         code=0,
                         message='exported file deleted successfully')