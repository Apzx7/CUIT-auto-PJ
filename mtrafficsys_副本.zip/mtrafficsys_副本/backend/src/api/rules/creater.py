from fastapi import APIRouter, UploadFile, File
from pydantic import BaseModel
from typing import Optional
from src.core.logger.log_manager import LogManager
from src.core.filter.upload_filter import UploadFileHandler  # type: ignore
from src.core.detection.convert_ip2yara import ConvertIP2Yara  # type: ignore
from src.core.detection.convert_domain2yara import ConvertDomain2Yara  # type: ignore

router = APIRouter(tags=["rules"])
logger = LogManager()


class ResponseModel(BaseModel):
	status: str
	code: int
	message: str
	output_name: Optional[str] = None
	rule_count: int = 0


@router.post('/rules/convert/ip-file', response_model=ResponseModel)
def convert_ip_rules_from_file(file: UploadFile = File(...)):
	actor = 'ConvertIP2YaraAPI'
	if not file:
		return ResponseModel(status='failed', code=1,
                             message='no file uploaded')
	if not file.filename:
		return ResponseModel(status='failed', code=1,
                             message='file has no filename')
	upload_handler = UploadFileHandler(file.filename)
	if not upload_handler.filter_ascii_file_extension():
		return ResponseModel(status='failed', code=1,
							 message='invalid file extension')

	try:
		content = file.file.read()
		text = content.decode('utf-8', errors='ignore')
		items = [line.strip() for line in text.splitlines() if line.strip()]
	except Exception as e:
		logger.add_business_log(
			category='rules convert',
			actor=actor,
			action='read ip file',
			result='failed',
			detail=f'failed to read file: {e}'
		)
		return ResponseModel(status='failed', code=1,
							 message='failed to read file')

	converter = ConvertIP2Yara()
	out_path, count = converter.convert_from_list(items, file.filename)
	out_name = out_path.split('\\')[-1] if out_path else None
	if count <= 0 or not out_path:
		logger.add_business_log(
			category='rules convert',
			actor=actor,
			action='convert ip file to yara',
			result='failed',
			detail='no valid ip rules generated'
		)
		return ResponseModel(status='failed', code=1,
							 message='no valid ip rules generated',
							 output_name=out_name, rule_count=count)
	logger.add_business_log(
		category='rules convert',
		actor=actor,
		action='convert ip file to yara',
		result='success',
		detail=f'generated {count} rules: {out_path}'
	)
	return ResponseModel(status='success', code=0,
						 message='ip rules generated',
						 output_name=out_name, rule_count=count)


@router.post('/rules/convert/domain-file', response_model=ResponseModel)
def convert_domain_rules_from_file(file: UploadFile = File(...)):
	actor = 'ConvertDomain2YaraAPI'
	if not file:
		return ResponseModel(status='failed', code=1,
                             message='no file uploaded')
	if not file.filename:
		return ResponseModel(status='failed', code=1,
                             message='file has no filename')
	upload_handler = UploadFileHandler(file.filename)
	if not upload_handler.filter_ascii_file_extension():
		return ResponseModel(status='failed', code=1,
                             message='invalid file extension')
	try:
		content = file.file.read()
		text = content.decode('utf-8', errors='ignore')
		items = [line.strip() for line in text.splitlines() if line.strip()]
	except Exception as e:
		logger.add_business_log(
			category='rules convert',
			actor=actor,
			action='read domain file',
			result='failed',
			detail=f'failed to read file: {e}'
		)
		return ResponseModel(status='failed', code=1,
							 message='failed to read file')

	converter = ConvertDomain2Yara()
	out_path, count = converter.convert_from_list(items, file.filename)
	out_name = out_path.split('\\')[-1] if out_path else None
	if count <= 0 or not out_path:
		logger.add_business_log(
			category='rules convert',
			actor=actor,
			action='convert domain file to yara',
			result='failed',
			detail='no valid domain rules generated'
		)
		return ResponseModel(status='failed', code=1,
							 message='no valid domain rules generated',
							 output_name=out_name, rule_count=count)
	logger.add_business_log(
		category='rules convert',
		actor=actor,
		action='convert domain file to yara',
		result='success',
		detail=f'generated {count} rules: {out_path}'
	)
	return ResponseModel(status='success', code=0,
						 message='domain rules generated',
						 output_name=out_name, rule_count=count)
