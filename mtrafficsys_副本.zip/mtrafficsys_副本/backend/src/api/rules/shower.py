from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional, Any

from src.core.rules.shower import ShowRules
from src.core.filter.rule_filter import RuleHandler  # type: ignore

router = APIRouter(tags=["rules"])


class RulesQueryParams(BaseModel):
	security_level: Optional[str] = None
	category: Optional[str] = None


class ResponseModel(BaseModel):
	status: str
	code: int
	data: Any = None
	message: Optional[str] = None


@router.get('/rules/show/', response_model=ResponseModel)
def show_rules():
	shower = ShowRules()
	records = shower.get_all_records()
	if records is None:
		return ResponseModel(status='failed', code=1,
							 data=None,
							 message='no rules found')
	return ResponseModel(status='success', code=0,
						 data=records,
						 message='rules retrieved successfully')


@router.post('/rules/search/', response_model=ResponseModel)
def search_rules(params: RulesQueryParams):
	if not RuleHandler().validate(params.security_level, params.category):
		return ResponseModel(status='failed', code=1,
							 data=None,
							 message='invalid security level or category')
	shower = ShowRules()
	records = shower.query_rules(
		security_level=params.security_level,
		category=params.category
	)
	if records is None:
		return ResponseModel(status='failed', code=1,
							 data=None,
							 message='rules query failed')
	return ResponseModel(status='success', code=0,
						 data=records,
						 message='rules query success')


@router.get('/rules/options/', response_model=ResponseModel)
def get_rules_options():
	rule_handler = RuleHandler()
	options = rule_handler.get_allow_options()
	return ResponseModel(status='success', code=0,
						 data=options,
						 message='allowed options retrieved successfully')
