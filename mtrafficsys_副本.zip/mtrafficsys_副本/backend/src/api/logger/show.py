from fastapi import APIRouter
from typing import Optional, Any
from pydantic import BaseModel
from src.core.logger.log_manager import LogManager
from src.core.filter.time_filter import TimeHandler  # type: ignore
from src.core.filter.logger_filter import LoggerHandler  # type: ignore


router = APIRouter(tags=["logger"], prefix="/logs")


class SysLogQueryParams(BaseModel):
    level: Optional[str]
    start_time: Optional[str]
    end_time: Optional[str]
    page: int = 1
    per_page: int = 50
    sort_by: str = "created_at"
    desc_order: bool = True


class BusLogQueryParams(BaseModel):
    task_status: Optional[str]
    start_time: Optional[str]
    end_time: Optional[str]
    page: int = 1
    per_page: int = 50
    sort_by: str = "created_at"
    desc_order: bool = True


class ResponseModel(BaseModel):
    status: str
    code: int
    data: Any = None
    message: Optional[str] = None


def _parse_iso_optional(s: Optional[str]) -> Optional[str]:
    if not s:
        return None
    return s


@router.post("/system/search/", response_model=ResponseModel)
def query_system_logs(params: SysLogQueryParams):
    if not TimeHandler().check_time(params.start_time, params.end_time):
        return ResponseModel(status="failed", code=1,
                             message="invalid time range")
    mgr = LogManager()
    lname = "SystemLogQueryEndpoint"
    try:
        res = mgr.query_system_logs(
            level=params.level,
            start_time=_parse_iso_optional(params.start_time),
            end_time=_parse_iso_optional(params.end_time),
            page=params.page,
            per_page=params.per_page,
            sort_by=params.sort_by,
            desc_order=params.desc_order,
        )
        mgr.add_system_log(
            level="INFO",
            logger_name=lname,
            action="query_system_logs",
            message="Query executed successfully"
        )
        return ResponseModel(status="success", code=0, data=res,
                             message="Query executed successfully")
    except Exception as e:
        mgr.add_system_log(
            level="ERROR",
            logger_name=lname,
            action="query_system_logs",
            message=f"Query failed: {str(e)}"
        )
        return ResponseModel(status="failed", code=1,
                             message="Query failed")


@router.post("/business/search/")
def query_business_logs(params: BusLogQueryParams):
    if not TimeHandler().check_time(params.start_time, params.end_time):
        return ResponseModel(status="failed", code=1,
                             message="invalid time range")
    if not LoggerHandler().validate_buslog_status(params.task_status):  # type: ignore
        return ResponseModel(status="failed", code=1,
                             message="invalid task status")
    mgr = LogManager()
    lname = "BusinessLogQueryEndpoint"
    try:
        res = mgr.query_business_logs(
            task_status=params.task_status,
            start_time=_parse_iso_optional(params.start_time),
            end_time=_parse_iso_optional(params.end_time),
            page=params.page,
            per_page=params.per_page,
            sort_by=params.sort_by,
            desc_order=params.desc_order,
        )
        mgr.add_system_log(
            level="INFO",
            logger_name=lname,
            action="query_business_logs",
            message="Query executed successfully"
        )
        return ResponseModel(status="success", code=0, data=res,
                             message="Query executed successfully")
    except Exception as e:
        mgr.add_system_log(
            level="ERROR",
            logger_name=lname,
            action="query_business_logs",
            message=f"Query failed: {str(e)}"
        )
        return ResponseModel(status="failed", code=1,
                             message="Query failed")
    

@router.get("/system/options/")
def get_system_log_options():
    return ResponseModel(
        status="success",
        code=0,
        data=LoggerHandler().get_allow_options()["syslog_levels"],
        message="Fetched system log options successfully"
    )


@router.get("/business/options/")
def get_business_log_options():
    return ResponseModel(
        status="success",
        code=0,
        data=LoggerHandler().get_allow_options()["buslog_status"],
        message="Fetched business log options successfully"
    )
