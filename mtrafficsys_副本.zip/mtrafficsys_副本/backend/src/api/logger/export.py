from fastapi import APIRouter
from pydantic import BaseModel

from src.core.logger.log_export import LogExporter  # type: ignore
from src.core.filter.time_filter import TimeHandler  # type: ignore

router = APIRouter(tags=["logger"])


class SysParamModel(BaseModel):
    start_time: str | None = None
    end_time: str | None = None
    level: str | None = None


class BusParamModel(BaseModel):
    start_time: str | None = None
    end_time: str | None = None
    result_filter: str | None = None


class ResponseModel(BaseModel):
    status: str
    code: int
    message: str
    file_name: str | None = None
    file_id: str | None = None


@router.post("/log/system/export/", response_model=ResponseModel)
def export_system_logs(sys_params: SysParamModel):
    if not TimeHandler().check_time(sys_params.start_time,
                                    sys_params.end_time):
        return ResponseModel(status="failed", code=1,
                             message="invalid time range",
                             file_name=None, file_id=None)
    exporter = LogExporter()
    result = exporter.export_system_logs(start_time=sys_params.start_time,
                                         end_time=sys_params.end_time,
                                         level=sys_params.level)
    if not result:
        return ResponseModel(status="failed", code=1,
                             message="export system logs failed",
                             file_name=None, file_id=None)
    file_name, file_id = result
    return ResponseModel(status="success", code=0,
                         message="export system logs success",
                         file_name=file_name, file_id=file_id)


@router.post("/log/business/export/", response_model=ResponseModel)
def export_business_logs(bus_params: BusParamModel):
    if not TimeHandler().check_time(bus_params.start_time,
                                    bus_params.end_time):
        return ResponseModel(status="failed", code=1,
                             message="invalid time range",
                             file_name=None, file_id=None)
    exporter = LogExporter()
    result = exporter.export_business_logs(start_time=bus_params.start_time,
                                           end_time=bus_params.end_time,
                                           result_filter=bus_params.result_filter)  # noqa
    if not result:
        return ResponseModel(status="failed", code=1,
                             message="export business logs failed",
                             file_name=None, file_id=None)
    file_name, file_id = result
    return ResponseModel(status="success", code=0,
                         message="export business logs success",
                         file_name=file_name, file_id=file_id)
