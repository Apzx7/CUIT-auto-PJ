from fastapi import APIRouter
from src.core.detection.ai_detect import AiDetect
from src.core.feature.search_scan_result import SearchScanResultFeature


router = APIRouter()


@router.post("/ai-detect")
async def detect(fid: str):
    feature = SearchScanResultFeature()
    result_json = feature.query_detection_results_by_fid(fid)
    ai_detect = AiDetect()
    result = ai_detect.detect(result_json)
    return {"content": result}
