from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse
from typing import Optional
from src.core.settings import ExportedFileInfo
from src.core.logger.log_manager import LogManager
from src.core.storage.mysql_control import MysqlSimClass
import os

router = APIRouter()


def _get_file_path_by_fid(file_id: str) -> Optional[str]:
    """
    Retrieve the file path for a given file ID from the database.
    """
    logger = LogManager()
    session = MysqlSimClass().get_session()
    try:
        result = session.query(ExportedFileInfo).filter_by(
            fid=file_id).first()
        if result:
            return result.path
        return None
    except Exception as e:
        logger.add_system_log(
            level="Error",
            logger_name="DownloadEndpoint",
            action="Get exported file path by fid",
            message=f"Query error: {e}.",
        )
        return None


@router.get("/download/{file_id}", response_class=FileResponse)
async def download_file(file_id: str):
    if not file_id:
        raise HTTPException(status_code=404, detail="File ID is empty")
    file_path = _get_file_path_by_fid(file_id)
    if file_path and os.path.exists(file_path):
        return FileResponse(path=file_path,
                            filename=os.path.basename(file_path))
    else:
        raise HTTPException(status_code=404, detail="File not found")
