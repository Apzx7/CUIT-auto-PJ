from src.core.data.manager.shower import ShowUploadFile
from fastapi import APIRouter
from src.core.logger.log_manager import LogManager
from pydantic import BaseModel
from typing import Optional, List, Dict

router = APIRouter(tags=["packet"])
logger = LogManager()


class FileQueryParams(BaseModel):
    filename: Optional[str] = None
    start_time: Optional[str] = None
    end_time: Optional[str] = None


class ResponseModel(BaseModel):
    status: str
    code: int
    data: Optional[List[Dict]] = None
    message: Optional[str] = None


@router.get('/upload/show/', response_model=ResponseModel)
def show_file_info():
    '''
    show uploaded file info
    '''
    shower = ShowUploadFile()
    actor = "ShowFileInfoEndpoint"
    records = shower.get_all_records()
    if records is None:
        logger.add_business_log(
            category='show file info',
            actor=actor,
            action='show file info',
            result='failed',
            detail='no files found'
        )
        return ResponseModel(status='failed',
                             code=1,
                             data=None,
                             message='no files found')
    return ResponseModel(status='success',
                         code=0,
                         data=records,
                         message='files retrieved successfully')


@router.post('/upload/search/', response_model=ResponseModel)
def search_file_info(params: FileQueryParams):
    '''
    search uploaded file info by filename and upload time range
    '''
    shower = ShowUploadFile()
    actor = "SearchFileInfoEndpoint"
    records = shower._get_file_info_by_name_and_time(
        fname=params.filename,
        start_time=params.start_time,
        end_time=params.end_time
    )
    if records is None:
        logger.add_business_log(
            category='search file info',
            actor=actor,
            action='search file info',
            result='failed',
            detail=f'no files found for query params: {params}'
        )
        return ResponseModel(status='failed',
                             code=1,
                             data=None,
                             message='no files found for given query parameters')
    return ResponseModel(status='success',
                         code=0,
                         data=records,
                         message='files retrieved successfully')
