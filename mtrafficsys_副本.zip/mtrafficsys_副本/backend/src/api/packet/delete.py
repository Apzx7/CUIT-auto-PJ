from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional

from src.core.data.manager.deleter import DeleteUploadFile
from src.core.logger.log_manager import LogManager

router = APIRouter(tags=["packet"])
logger = LogManager()


class ResponseModel(BaseModel):
	status: str
	code: int
	message: Optional[str] = None


@router.get('/upload/delete/{fid}', response_model=ResponseModel)
def delete_uploaded_file(fid: str):
	actor = "DeleteUploadFileEndpoint"
	deleter = DeleteUploadFile()
	result = deleter.delete_record_by_fid(fid)
	if not result:
		logger.add_business_log(
			category='delete uploaded file',
			actor=actor,
			action='delete uploaded file',
			result='failed',
			detail=f'failed to delete uploaded file with fid: {fid}'
		)
		return ResponseModel(status='failed', code=1,
						 message='failed to delete uploaded file')
	logger.add_business_log(
		category='delete uploaded file',
		actor=actor,
		action='delete uploaded file',
		result='success',
		detail=f'deleted uploaded file with fid: {fid}'
	)
	return ResponseModel(status='success', code=0,
					 message='uploaded file deleted successfully')
