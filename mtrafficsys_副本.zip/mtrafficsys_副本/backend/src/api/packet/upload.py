from fastapi import APIRouter, UploadFile
from src.core.filter.upload_filter import UploadFileHandler
from src.core.data.manager.adder import SaveUploadFile
from src.core.logger.log_manager import LogManager
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import uuid
import os

router = APIRouter(tags=["packet"])
logger = LogManager()


class ResponseModel(BaseModel):
    status: str
    code: int
    file_id: Optional[str] = None
    message: Optional[str] = None


@router.post('/upload/', response_model=ResponseModel)
async def upload_file(file: UploadFile):
    '''
    upload file
    '''
    if not file or not file.filename:
        logger.add_business_log(
            category='upload file',
            actor="UploadFileEndpoint",
            action='upload file',
            result='failed',
            detail='file not found'
        )
        return ResponseModel(status='failed',
                             code=1,
                             file_id=None,
                             message='file not found')
    default_header_chunk_size = 4096

    upload_handler = UploadFileHandler(file.filename)
    file_extension = upload_handler.get_file_extension()
    if not upload_handler.filter_traffic_file_extension():
        white_list = upload_handler.allowed_traffic_extensions
        logger.add_business_log(
            category='upload file',
            actor="UploadFileEndpoint",
            action='upload file',
            result='failed',
            detail=f'not support format, support format: {white_list}'
        )
        return ResponseModel(status='failed',
                             code=1,
                             file_id=None,
                             message=f'not support format, support format: {white_list}')  # noqa
    rname = upload_handler.get_renamed_file()
    upload_time = datetime.now().strftime('%Y%m%d%H%M%S')
    save_dir = 'upload/'
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    new_file_name = rname + '.' + file_extension
    save_path = save_dir + new_file_name
    file_id = str(uuid.uuid4())
    current_path = os.getcwd()
    # get absolute path
    abs_file_path = os.path.join(current_path, 'upload', new_file_name)
    contents = await file.read()
    header_bytes = contents[:default_header_chunk_size]
    file_hash = upload_handler.get_pcap_header_hash(header_bytes)
    # save file
    with open(save_path, 'wb') as f:
        f.write(contents)
    file_size = upload_handler.get_file_size(abs_file_path)
    # save file info to mysql
    try:
        SaveUploadFile().save_file_info(fid=file_id, fname=file.filename,
                                        rname=new_file_name,
                                        fpath=abs_file_path, udate=upload_time,
                                        hashcode=file_hash, fsize=file_size)
    except Exception as e:
        logger.add_business_log(
            category='upload file',
            actor="UploadFileEndpoint",
            action='upload file',
            result='failed',
            detail=f'upload file failed: {str(e)}'
        )
        return ResponseModel(status='failed', code=1,
                             message='upload file failed')
    detail = f'file {file.filename} saved to {save_path} with id {file_id}'  # noqa
    logger.add_business_log(
        category='upload file',
        actor="UploadFileEndpoint",
        action='upload file',
        result='success',
        detail=detail
    )

    # close the uploaded file
    await file.close()

    return ResponseModel(status='success', code=0,
                         file_id=file_id,
                         message='upload file successfully!')
