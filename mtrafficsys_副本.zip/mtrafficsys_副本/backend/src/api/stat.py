from fastapi import APIRouter
from pydantic import BaseModel
from typing import Any, Dict
from src.core.statistics import TrafficStatistics  # type: ignore

router = APIRouter()


class ResponseModel(BaseModel):
	status: str
	code: int
	data: Dict[str, Any] | None = None
	message: str


@router.get('/statistics/overview', response_model=ResponseModel)
def get_statistics_overview():
	try:
		stats = TrafficStatistics().get_overview()
		return ResponseModel(status='success', code=0,
							 data=stats,
							 message='statistics overview success')
	except Exception as e:
		return ResponseModel(status='failed', code=1,
							 data=None,
							 message=f'statistics overview failed: {e}')
