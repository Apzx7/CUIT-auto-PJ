from src.core.conf.load import YamlLoader
from typing import Union

conf_class = YamlLoader()

# 配置Fastapi服务端
UVICORN_CONF: dict[str, Union[str, int]] = {}

# cors config
CORS_CONF: dict[str, Union[str, list]] = {}

for d in conf_class.get_uvicorn_conf():  # type: ignore
    # d is a dict
    UVICORN_CONF = {**UVICORN_CONF, **d}

for d in conf_class.get_cors_conf():  # type: ignore
    # d is a dict
    CORS_CONF = {**CORS_CONF, **d}
