from fastapi import FastAPI  # type: ignore
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from typing import Any
from settings import UVICORN_CONF, CORS_CONF
from src.api.startup import lifespan
from src.api.extract import traffic_extract
from src.api.extract import traffic_show
from src.api.export import pcap_export
from src.api.detect import file_detect
from src.api.detect import detect_result_show
from src.api.logger import show as logger_show
from src.api.logger import export as log_export
from src.api.packet import upload as packet_upload
from src.api import download
from src.api.export import show_export as exported_file_show
from src.api.export import delete_export as exported_file_delete
from src.api.export import result_export
from src.api.packet import show as packet_show
from src.api.rules import creater as rules_creater
from src.api import stat
from src.api.detect import report_pdf
from src.api.packet import delete as packet_delete
from src.api.rules import shower as rules_shower

# testapi
from src.api import testapi as test_router


app = FastAPI(lifespan=lifespan)


app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_CONF.get("allow_origins", []),
    allow_credentials=True,
    allow_methods=CORS_CONF.get("allow_methods", []),
    allow_headers=CORS_CONF.get("allow_headers", []),
)

app.include_router(traffic_extract.router)
app.include_router(traffic_show.router)
app.include_router(pcap_export.router)
app.include_router(file_detect.router)
app.include_router(detect_result_show.router)
app.include_router(packet_upload.router)
app.include_router(download.router)
app.include_router(exported_file_show.router)
app.include_router(exported_file_delete.router)
app.include_router(logger_show.router)
app.include_router(log_export.router)
app.include_router(result_export.router)
app.include_router(packet_show.router)
app.include_router(rules_creater.router)
app.include_router(stat.router)
app.include_router(report_pdf.router)
app.include_router(packet_delete.router)
app.include_router(rules_shower.router)

# testapi
app.include_router(test_router.router)


if __name__ == "__main__":
    start_conf: dict[str, Any] = {
        'app': app,
        'host': UVICORN_CONF['host'],
        'port': UVICORN_CONF['port'],
        'reload': False
    }
    uvicorn.run(**start_conf)
